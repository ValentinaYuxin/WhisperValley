import mongoose from 'mongoose';
const { Schema } = mongoose;

const notificationSchema = new Schema({
  type: { 
    type: String, 
    enum: ['comment', 'like'], 
    required: true
  },
  //['comment', 'like']
  refId: { 
    type: Schema.Types.ObjectId, 
    required: true 
  }, 
  targetType: {
    type: String,
    enum: ['Post', 'Comment'],
    required: true
  },
  targetId: {
    type: Schema.Types.ObjectId,
    required: true,
    refPath: 'targetType'
  },
  // receiver
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  senderName: { 
    type: String, 
    required: true 
  }, 
  isRead: { 
    type: Boolean, 
    default: false 
  },
}, { timestamps: true });

export default mongoose.model('Notification', notificationSchema);
