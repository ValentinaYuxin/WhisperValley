import mongoose from 'mongoose';

const { Schema } = mongoose;

const invoiceSchema = new Schema({
    // '_id' created by default

    user: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true,
    },

    stripeInvoiceId: {
        type: String,
        unique: true,
        sparse: true,
        required: true,
    },

    amountPaid: {
        type: Number,
        required: true,
    },

    paidAt: {
        type: Date,
        required: true,
    },

    invoicePdf: {
        type: String,
    },
}, {
    // Mongoose automatically adds createdAt and updatedAt
    timestamps: true
});

export default mongoose.model('Invoice', invoiceSchema);