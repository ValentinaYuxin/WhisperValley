import mongoose from 'mongoose';
import bcryptjs from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import Post from './Post.js';


const { Schema } = mongoose;

const userSchema = new Schema({
        // Mongoose creates a unique '_id' with type ObjectId for each document as its primary key by default

        username: {
            type: String,
            required: [true, 'Please enter a username'],
            unique: true, 
            trim: true,  // remove leading/trailing whitespace
            minlength: 3,
            maxlength: [50, 'Username must be between 3 and 50 characters'],
        },

        email: {
            type: String,
            required: [true, 'Please enter an email address'],
            unique: true,
            lowercase: true,
            trim: true,
            validate: {
                validator: function (value) {
                    // Only allow certain domains
                    const allowedDomains = ['@mytum.de', '@tum.de', '@campus.lmu.de'];
                    return allowedDomains.some((domain) => value.toLowerCase().endsWith(domain));
                },
                message:
                    'Please use your student email (for example: @tum.de, @mytum.de or @campus.lmu.de).',
                },
            },

        password: {
            type: String,
            required: [true, 'Please enter a password'],
            minlength: [8, 'Password must be at least 8 characters'],
            select: false,  // passwords are not returned by default
        },

        resetPasswordToken: String,
        resetPasswordExpire: Date,

        stripeCustomerId: {
            type: String,
            sparse: true,  // could be null
            unique: true,  // TODO: check
        },

        avatar: {
            type: String,
            default: '',  
        },


        role: {
            type: String,
            enum: ['user', 'admin'],
            default: 'user',
        },

        point: {
            type: Number,
            default: 2,
        },

        isAnonymous: {
            type: Boolean,
            default: true,
        },

        // Keep track of tasks that the user has already completed and received points for
        completedTasks: {
            type: [String],  // Array of task identifiers, e.g., ['posts_10', 'likes_50']
            default: []
        },

        petName: {
            type: String,
            default: '',
      
        },

        favoriteWeather: {
            type: String,
            enum: ['sunny', 'cloudy', 'rainy', 'snowy'],
            default: null,
   
        },
    },
    {
        // Mongoose automatically adds createdAt and updatedAt
        timestamps: true
    }
);

// Mongoose pre-save hook: password hashing before saving the user document
userSchema.pre('save', async function (next) {
    // only hash the modified password when registration or password reset
    if (!this.isModified('password')) {
        return next();
    }

    const salt = await bcryptjs.genSalt(10);
    this.password = await bcryptjs.hash(this.password, salt);
    next();
});

// generate a signed JWT for the user
userSchema.methods.getSignedJwtToken = function () {
    return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRE,
    });
}

// compare the entered password with the stored hashed password when login
userSchema.methods.matchPassword = async function (enteredPassword) {
    return await bcryptjs.compare(enteredPassword, this.password);
};

// generate & hash a password reset token
userSchema.methods.getResetPasswordToken = function () {
    const resetToken = crypto.randomBytes(20).toString('hex');

    this.resetPasswordToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    this.resetPasswordExpire = Date.now() + 10 * 60 * 1000;  // expire in 10 min

    // store hashed token but send original token to client
    return resetToken;
}

//Yuxin: When deleting a user, all of their posts should also be deleted.
//There is no need to separately delete comments or likes, 
//because deleting a post with deleteOne will automatically remove all associated comments and likes.
//Add other related objects.
userSchema.pre('deleteOne', { document: true, query: false }, async function(next) {
  try {

    const posts = await Post.find({ user: this._id });
    for (const post of posts) {
      await post.deleteOne();
    }

    next();
  } catch (err) {
    next(err);
  }
});


export default mongoose.model('User', userSchema);