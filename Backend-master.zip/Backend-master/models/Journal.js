import mongoose from "mongoose";

const { Schema } = mongoose;

const validateQuestionaires = function (arr) {
  return (
    Array.isArray(arr) &&
    arr.length == 3 &&
    arr.every((score) => typeof score == "number" && score >= 1 && score <= 5)
  );
};

const journalSchema = new Schema(
  {
    // Mongoose creates a unique '_id' with type ObjectId for each journal
    userID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    // Use questionaireScore to store the results of each questionaire separeatly
    questionaireScore: {
      type: [Number],
      required: true,
      validate: {
        validator: validateQuestionaires,
        message: "Please fill all the questionaires",
      },
    },

    totalMoodScore: {
      type: Number,
      default: 0,
    },

    content: {
      type: String,
      default: "",
      trim: true,
    },

    emotionLabels: {
      type: String,
      required: [true, "Please select one emotional label"],
      enum: {
        values: [
          "Contempt",
          "Sadness",
          "Fear",
          "Anger",
          "Disgust",
          "Surprise",
          "Enjoyment",
        ],
        message: "Please select a valid emotional label",
      },
    },
  },
  {
    timestamps: true,
  }
);
//Calculate the totalscore before save
journalSchema.pre("save", function (next) {
  if (this.questionaireScore.length == 3) {
    this.totalMoodScore = this.questionaireScore.reduce(
      (sum, score) => sum + score,
      0
    );
  }
  next();
});
export default mongoose.model("Journal", journalSchema);
