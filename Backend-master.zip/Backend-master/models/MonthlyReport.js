import mongoose from 'mongoose';

const { Schema } = mongoose;

const monthlyReportSchema = new Schema({
    // '_id' created by default

    user: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true,
    },

    year: {
        type: Number,
        required: true,
    },

    month: {
        type: Number,
        required: true,
        min: 1,
        max: 12,
    },

    // TODO: add fields

    // personalization + weather + nlp?
    tips: {
        type: [String],
        default: [],
    },

    generateDate: {
        type: Date,
        default: Date.now,
    },

},{
    // Mongoose automatically adds createdAt and updatedAt
    timestamps: true
});

// a user only has one monthly report per month
monthlyReportSchema.index({ user: 1, year: 1, month: 1 }, { unique: true });

monthlyReportSchema.pre(/^find/, function(next) {
    this.populate({
        path: 'user',
        select: 'username email',
    });
    next();
});

export default mongoose.model('MonthlyReport', monthlyReportSchema);