import mongoose from 'mongoose';

const { Schema } = mongoose;

// Report schema supports reporting either a post or a comment
const reportSchema = new Schema({
  targetType: {
    type: String,
    enum: ['post', 'comment'], // What kind of content is being reported
    required: true
  },
  targetId: {
    type: Schema.Types.ObjectId, // ID of the reported post or comment
    required: true
  },
  reportedUser: {
    type: Schema.Types.ObjectId, // The author of the reported content
    ref: 'User',
    required: true
  },
  targetContent: {
    type: String, // Snapshot of the reported content itself
    required: true
  },
  reason: {
    type: String, // The user-provided reason for reporting
    required: [true, 'Reason for report is required'],
    maxlength: 1000
  },
  status: {
    type: String,
    enum: ['pending', 'reviewed', 'dismissed'],
    default: 'pending'
  },
  // Add a field for the reporting user (who submitted the report)
  reportingUser: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true // Automatically adds createdAt and updatedAt
});

export default mongoose.model('Report', reportSchema);
