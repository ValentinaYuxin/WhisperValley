import mongoose from 'mongoose';
import Notification from './Notification.js';

const { Schema } = mongoose;

const likeSchema = new Schema({
    // '_id' created by default

    user: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true,
        index: true,  // store sorted values/location to speed up, B-tree
    },

    targetType: {
        type: String,
        required: true,
        enum: ['Post', 'Comment'],
    },

    targetId: {
        type: mongoose.Schema.ObjectId,
        refPath: 'targetType',
        required: true,
        index: true,
    },

}, {
    // Mongoose automatically adds createdAt and updatedAt
    timestamps: true
});

// a user can only like/unlike the same specific type once
likeSchema.index({ user: 1, targetType: 1, targetId: 1 }, { unique: true });

//Yuxin:
likeSchema.pre('deleteOne', { document: true, query: false }, async function (next) {
  try {
    await Notification.deleteMany({ refId: this._id, type: 'like' });
    next();
  } catch (err) {
    next(err);
  }
});

export default mongoose.model('Like', likeSchema);