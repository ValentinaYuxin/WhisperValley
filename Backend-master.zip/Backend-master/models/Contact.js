import mongoose from 'mongoose';

const { Schema } = mongoose;

const contactSchema = new Schema({

    // User Email
    email: {
        type: String,
        required: [true, 'Please enter your email address'],
        lowercase: true,
        trim: true,
        validate: {
            validator: (email) => {
                return /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email);
            },
            message: 'Invalid email format',
        }
    },

    subject: {
        type: String,
        required: [true, 'Please enter a subject'],
        maxlength: [100, 'Subject can be up to 100 characters'],
        trim: true,
    },

    // Feedback
    message: {
        type: String,
        required: [true, 'Please enter a message'],
        maxlength: [2000, 'Message can be up to 2000 characters'],
    },

    status: {
        type: String,
        enum: ['new', 'read', 'resolved', 'archived'],
        default: 'new',
    }

}, {
    timestamps: true // add createdAt and updatedAt
});

export default mongoose.model('Contact', contactSchema);
