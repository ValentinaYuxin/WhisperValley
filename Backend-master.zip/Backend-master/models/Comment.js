import mongoose from 'mongoose';
import Notification from './Notification.js';
import Like from './Like.js';

const { Schema } = mongoose;

const commentSchema = new Schema({

  // Link to the parent post
  post: {
    type: Schema.Types.ObjectId,
    ref: 'Post',
    required: true
  },

  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },

  // If this is a reply to another comment (optional)
  parentComment: {
    type: Schema.Types.ObjectId,
    ref: 'Comment',
    default: null
  },

  // -text only-
  content: {
    type: String,
    required: [true, 'Comment cannot be empty'],
    maxlength: 1000
  },

  // Number of likes (for engagement)
  likeCount: {
    type: Number,
    default: 0,
    min: 0
  },

  // Number of replies (for engagement)
  repliesCount: {
    type: Number,
    default: 0,
    min: 0
  }

}, {
  timestamps: true // Adds createdAt and updatedAt
});

//  We do not auto-populate the user field to maintain full anonymity
// Anonymous label like "Anonymous01" is generated per-request in the controller


//Yuxin: This is a document middleware for the 'deleteOne' operation.
// It runs when calling deleteOne() on a document instance, e.g. doc.deleteOne()
commentSchema.pre('deleteOne', { document: true, query: false }, async function (next) {
  try {
    await Notification.deleteMany({ refId: this._id, type: 'comment' });

    const likes = await Like.find({ targetType: 'Comment', targetId: this._id });
        for (const l of likes) {
          await l.deleteOne(); 
        }
    next();
  } catch (err) {
    next(err);
  }
});


export default mongoose.model('Comment', commentSchema);
