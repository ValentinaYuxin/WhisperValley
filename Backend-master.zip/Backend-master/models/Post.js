import mongoose from 'mongoose';
import Comment from './Comment.js';
import Like from './Like.js';
import Notification from './Notification.js';

const { Schema } = mongoose;

const postSchema = new Schema({

  // Keeps user anonymous in the forum
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },

   // An anonymous display name (e.g., Anonymous-4K9xXq)
  author: {
    type: String,
    required: true
  },

  title: {
    type: String,
    required: [true, 'Please enter a title'],
    trim: true,
    minlength: 3,
    maxlength: 100
  },

  //  – text-only -
  content: {
    type: String,
    required: [true, 'Post content cannot be empty'],
    maxlength: 2000
  },

  // Emoji that visually represents how the user feels
  emoji: {
    type: String,
    default: '📝',
    validate: {
      validator: function(v) {
        // Regex for most single Unicode emoji (not perfect, but covers most cases)
        return /^\p{Emoji}$/u.test(v);
      },
      message: props => `${props.value} is not a valid emoji!`
    }
  },

   // Exactly one emotion label from Paul Ekman's theory
  emotionLabel: {
    type: String,
    required: [true, 'Please select one emotion label'],
    enum: {
      values: ['Contempt', 'Sadness', 'Fear', 'Anger', 'Disgust', 'Surprise', 'Enjoyment'],
      message: 'Invalid emotion label selected'
    }
  },

  // Optional: tags added by the user
  tags: [String],

  likeCount: {
    type: Number,
    min: 0
  },

  // Number of times the post has been viewed
  views: {
    type: Number,
  min : 0
  },
  viewedBy: [{
    type: Schema.Types.ObjectId,
    ref: 'User'
  }]

}, {
  // Automatically includes createdAt and updatedAt timestamps
  timestamps: true
});

// ❌ DO NOT auto-populate user data to protect anonymity
// The controller handles generating anonymous names per post

//Yuxin: Automatically remove all associated comments and likes when deleting a post
postSchema.pre('deleteOne', { document: true, query: false }, async function(next) {
  try {
    await Notification.deleteMany({ post: this._id });

    const comments = await Comment.find({ post: this._id });
    for (const c of comments) {
      await c.deleteOne(); 
    }

    const likes = await Like.find({ targetType: 'Post', targetId: this._id });
    for (const l of likes) {
      await l.deleteOne(); 
    }

    next();
  } catch (err) {
    next(err);
  }
});

export default mongoose.model('Post', postSchema);
