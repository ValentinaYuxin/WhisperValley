import mongoose from 'mongoose';

const { Schema } = mongoose;

const subscriptionSchema = new Schema({
    // '_id' created by default

    user: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true,
    },

    plan: {
        type: String,
        enum: ['free', 'premium'],
        default: 'free',
        required: true,
    },

    billingPeriod: {
        type: String,
        enum: ['monthly', 'yearly', 'N/A'],
        required: function() { return this.plan !== 'free'; },
    },

    startDate: {
        type: Date,
        default: Date.now,
    },

    // free sub is endless
    endDate: {
        type: Date,
        required: function() { return this.plan !== 'free'; },
    },

    status: {
        type: String,
        enum: ['pending', 'active', 'canceling', 'cancelled', 'trialing',],
        default: 'pending',
    },

    paymentMethod: {
        type: String,
        enum: ['stripe', 'N/A'],
    },

    paymentStatus: {
        type: String,
        enum: ['paid', 'pending', 'failed', 'N/A'],
        default: 'pending',
    },

    stripeSubscriptionId: {
        type: String,
        unique: true,
        sparse: true,
    }

}, {
    // Mongoose automatically adds createdAt and updatedAt
    timestamps: true
})

subscriptionSchema.pre(/^find/, function(next) {
    this.populate({
        path: 'user',
        select: 'username email',
    });
    next();
})

export default mongoose.model('Subscription', subscriptionSchema);