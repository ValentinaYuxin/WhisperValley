from flask import Flask, request, jsonify
import text2emotion as te

app = Flask(__name__)


@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()
    text = data.get("text", "")

    emotions = te.get_emotion(text)

    return jsonify(emotions)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
