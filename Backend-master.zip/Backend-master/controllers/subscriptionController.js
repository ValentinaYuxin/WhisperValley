import Subscription from '../models/Subscription.js';
import asyncHandler from '../utils/asyncHandler.js';
import Stripe from 'stripe';
import {
    createCheckoutSession,
    updateStripeSubscription,
    cancelStripeSubscription,
    cancelStripeSubscriptionImmediately,
} from '../utils/stripe.js';

const PREMIUM_MONTHLY_PRICE = process.env.STRIPE_PREMIUM_MONTHLY_PRICE_ID;
const PREMIUM_YEARLY_PRICE  = process.env.STRIPE_PREMIUM_YEARLY_PRICE_ID;

// 1. start a 7-day trial for free users via Checkout Session
export const startTrial = asyncHandler(async (req, res, next) => {
    // a user can only have a trial sub
    const hasHadPremium = await Subscription.findOne({ user: req.user._id, plan: 'premium' });

    if (hasHadPremium) {
        return res.status(400).json({ message: 'You have already had a trial or premium subscription.' });
    }

    // Use the monthly price for trial
    req.body.priceId = PREMIUM_MONTHLY_PRICE;
    req.body.trialDays = 7;

    return createCheckoutSession(req, res, next);
});

// 2. Upgrade from free directly to premium via Checkout Session (not for trial users)
export const upgradeToPremium = asyncHandler(async (req, res, next) => {
    const currentSub = await Subscription.findOne({ user: req.user._id });
    if (currentSub && currentSub.plan !== 'free') {
        return res.status(400).json({ message: 'Only free users can upgrade to premium.' });
    }

    const { billingCycle = 'monthly' } = req.body;
    req.body.priceId = billingCycle === 'yearly' ? PREMIUM_YEARLY_PRICE : PREMIUM_MONTHLY_PRICE;
    req.body.trialDays = 0;

    return createCheckoutSession(req, res, next);
});

// 3. Update billing cycle for premium users (trial users not allowed)
export const changePlan = asyncHandler(async (req, res, next) => {
    return updateStripeSubscription(req, res, next);
});

// 4. Cancel subscription at period end
export const cancelSubscription = asyncHandler(async (req, res, next) => {
    const local = await Subscription.findOne({ user: req.user._id, status: { $in: ['active', 'trialing'] } });
    if (!local) {
        return res.status(400).json({ message: 'No active or trialing premium subscription to cancel' });
    }

    console.log('Attempting to cancel subscription with Stripe ID:', local.stripeSubscriptionId);
    req.body.subscriptionId = local.stripeSubscriptionId;
    return cancelStripeSubscription(req, res, next);
});

// 5. Cancel subscription immediately and revert to free
export const cancelImmediately = asyncHandler(async (req, res, next) => {
    const local = await Subscription.findOne({ user: req.user._id, status: { $in: ['active', 'trialing'] } });
    if (!local) {
        return res.status(400).json({ message: 'No active or trialing premium subscription to cancel' });
    }

    req.body.subscriptionId = local.stripeSubscriptionId;
    return cancelStripeSubscriptionImmediately(req, res, next);
});

// 6. Get current active subscription for the user profile
export const getCurrent = asyncHandler(async (req, res) => {
    let current = await Subscription.findOne({ user: req.user._id, status: { $in: ['active', 'trialing'] } });

    if (!current) {
        current = await Subscription.findOne({ user: req.user._id, plan: 'free' });

        if (!current) {
            current = await Subscription.create({
                user: req.user._id,
                plan: 'free',
                status: 'active',
                startDate: new Date(),
                endDate: null
            });
        }
    }
    res.status(200).json({ success: true, subscription: current });
});

// 7. Get the user's full subscription history for the user profile
export const getHistory = asyncHandler(async (req, res) => {
    const history = await Subscription.find({ user: req.user._id }).sort({ startDate: -1 });
    res.status(200).json({ success: true, history });
});

// 8. Get a subscription by ID
export const getSubById = asyncHandler(async (req, res) => {
    const sub = await Subscription.findById(req.params.id);
    if (!sub) {
        return res.status(404).json({ message: 'Subscription not found' });
    }

    res.status(200).json({ success: true, subscription: sub });
});