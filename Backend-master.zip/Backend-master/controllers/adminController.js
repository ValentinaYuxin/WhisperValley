import asyncHandler from "../utils/asyncHandler.js";
import Report from "../models/Report.js";
import User from "../models/User.js";
import Subscription from "../models/Subscription.js";
import Post from "../models/Post.js";
import Comment from "../models/Comment.js";
import Contact from "../models/Contact.js";
import Journal from "../models/Journal.js";
import dayjs from "dayjs";
import mongoose from 'mongoose';

// 1. get aggregated statistics for the admin dashboard
export const getDashboardStats = asyncHandler(async (req, res) => {
    const [
        totalUsers,
        newUsersLast7Days,
        newUsersLast30DaysDaily,
        subscriptionStatsByStatus,
        subscriptionStatsByPlan,
        totalPosts,
        postsLast7Days,
        totalComments,
        totalReports,
        totalJournalEntries,
    ] = await Promise.all([
        User.countDocuments(),
        User.countDocuments({ createdAt: { $gte: dayjs().subtract(7, 'day').toDate() } }),
        User.aggregate([
            {
                $match: { createdAt: { $gte: dayjs().subtract(30, 'day').toDate() }}
            },
            {
                $group: {
                    _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
                    count: { $sum: 1 }
                }
            },
            { $sort: { _id: 1 } }
        ]),
        Subscription.aggregate([
            { $group: { _id: '$status', count: { $sum: 1 } }}
        ]),
        Subscription.aggregate([
            { $group: { _id: '$plan', count: { $sum: 1 } }}
        ]),
        Post.countDocuments(),
        Post.countDocuments({ createdAt: { $gte: dayjs().subtract(7, 'day').toDate() } }),
        Comment.countDocuments(),
        Report.countDocuments(),
        Journal.countDocuments(),
    ]);

    // initialize all possible statuses to 0
    const subByStatus = {
        account: 0,
        trialing: 0,
        canceling: 0,
        cancelled: 0,
        pending: 0,
    };

    // populate the object with actual counts from database
    subscriptionStatsByStatus.forEach(stat => {
        subByStatus[stat._id] = stat.count;
    });

    const subByPlan = {
        free: 0,
        premium: 0,
    };

    subscriptionStatsByPlan.forEach(stat => {
        subByPlan[stat._id] = stat.count;
    })

    // ensure all last 30 days have a count
    const dailyUserCounts = {};
    for (let i = 0; i < 30; i++) {
        const date = dayjs().subtract(29 - i, 'day').format('YYYY-MM-DD');
        dailyUserCounts[date] = 0;
    }

    newUsersLast30DaysDaily.forEach(data => {
        dailyUserCounts[data._id] = data.count;
    });

    const formattedDailyUserCounts = Object.keys(dailyUserCounts).map(date => ({
        date,
        count: dailyUserCounts[date]
    }));

    const averageJournalsPerUser = totalUsers > 0 ? (totalJournalEntries / totalUsers) : 0;

    res.status(200).json({
        success: true,
        data: {
            users: {
                total: totalUsers,
                newLast7Days: newUsersLast7Days,
                newLast30DaysDaily: formattedDailyUserCounts,
            },
            subscriptions: {
                byStatus: subByStatus,
                byPlan: subByPlan,
            },
            content: {
                totalPosts,
                postsLast7Days,
                totalComments,
                totalReports,
            },
            journals: {
                total: totalJournalEntries,
                averagePerUser: averageJournalsPerUser,
            }
        }
    });
});


// 2. fetch all users with their subscription details
export const getUsers = asyncHandler(async (req, res) => {
    const { page = 1, limit = 10, search, role, subscription: subFilter } = req.query;

    const pageNum = parseInt(page, 10);
    const limitNum = parseInt(limit, 10);
    const skip = (pageNum - 1) * limitNum;

    const initialMatch = {};

    if (search) {
        const searchRegex = { $regex: search, $options: 'i' };
        initialMatch.$or = [
            { username: searchRegex },
            { email: searchRegex },
        ];
    }

    if (role && role !== 'all') {
        initialMatch.role = role;
    }

    // base aggregation pipeline
    const pipeline = [
        { $match: initialMatch },
        { $sort: { createdAt: -1 } },
        {
            $lookup: {
                from: 'subscriptions',
                let: { userId: '$_id' },
                pipeline: [
                    { $match: { $expr: { $eq: ['$user', '$$userId'] } } },
                    { $sort: { createdAt: -1 } },
                    { $limit: 1 }
                ],
                as: 'subscription',
            }
        },
        // deconstruct the sub array and keep the first one
        {
            $unwind: {
                path: '$subscription',
                preserveNullAndEmptyArrays: true,
            }
        },
        // add a sub field to each user
        {
            $addFields: {
                'subscription': {
                    $ifNull: ['$subscription', { plan: 'free', status: 'active' }]
                }
            }
        }
    ];

    // sub filter based on plan
    if (subFilter && subFilter !== 'all') {
        if (subFilter === 'premium') {
            pipeline.push({
                $match: {
                    'subscription.plan': 'premium',
                    'subscription.status': { $in: ['active', 'canceling'] }
                }
            });
        } else if (subFilter === 'trialing') {
            pipeline.push({
                $match: {
                    'subscription.plan': 'premium',
                    'subscription.status': 'trialing',
                }
            });
        } else {
            pipeline.push({
                $match: {
                    'subscription.plan': subFilter,
                }
            });
        }
    }

    const countPipeline = [...pipeline, { $count: 'totalUsers' }];
    const countResult = await User.aggregate(countPipeline);
    const totalUsers = countResult[0] ? countResult[0].totalUsers : 0;

    // add pagination after counting
    pipeline.push({ $skip: skip });
    pipeline.push({ $limit: limitNum });

    const users = await User.aggregate(pipeline);

    res.status(200).json({
        success: true,
        totalUsers: totalUsers,
        data: users,
    });
});

// 3. delete a user by ID
export const deleteUser = asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id);

    if (!user) {
        res.status(404);
        throw new Error('User not found');
    }

    if (user.role === 'admin') {
        res.status(400);
        throw new Error('Cannot delete an admin user');
    }

    await user.deleteOne();

    res.status(200).json({
        success: true,
        message: 'User removed',
    });
});

// 4. get a user by ID
export const getUserById = asyncHandler(async (req, res) => {
    const userId = req.params.id;

    if (!mongoose.Types.ObjectId.isValid(userId)) {
        res.status(400);
        throw new Error('Invalid user ID format');
    }

    const users = await User.aggregate([
        {
            $match: { _id: new mongoose.Types.ObjectId(userId) }
        },
        {
            $lookup: {
                from: 'subscriptions',
                localField: '_id',
                foreignField: 'user',
                as: 'subscription',
            }
        },
        {
            $unwind: {
                path: '$subscription',
                preserveNullAndEmptyArrays: true,
            }
        },
        {
            $project: {
                username: 1,
                email: 1,
                role: 1,
                point: 1,
                completedTasks: 1,
                petName: 1,
                favoriteWeather: 1,
                createdAt: 1,
                updatedAt: 1,
                subscription: { $ifNull: ['$subscription', null] },
            }
        }
    ]);

    const user = users[0];

    if (!user) {
        res.status(404);
        throw new Error('User not found');
    }

    res.json(user);
});

// 5. get user subscriptions
export const getUserSubscriptions = asyncHandler(async (req, res) => {
    const userId = req.params.id;
    const subscriptions = await Subscription.find({ user: userId }).sort({ createdAt: -1 });

    if (!subscriptions) {
        res.status(404);
        throw new Error('Subscriptions not found for this user');
    }
    res.json(subscriptions);
});

// 6. update user details
export const updateUser = asyncHandler(async (req, res) => {
    const userId = req.params.id;
    const { username, email, role } = req.body;

    const user = await User.findById(userId);

    if (!user) {
        res.status(404);
        throw new Error('User not found');
    }

    user.username = username || user.username;
    user.email = email || user.email;
    user.role = role || user.role;

    const updatedUser = await user.save();

    res.status(200).json({
        success: true,
        message: 'User updated successfully',
        data: {
            _id: updatedUser._id,
            username: updatedUser.username,
            email: updatedUser.email,
            role: updatedUser.role,
            createdAt: updatedUser.createdAt,
            updatedAt: updatedUser.updatedAt,
        },
    });
});


// 7. get all user-submitted reports
export const getReports = asyncHandler(async (req, res) => {
    const { page = 1, limit = 20, status, targetType } = req.query;
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const filter = {};
    if (status) {
        filter.status = status;
    }
    if (targetType) {
        filter.targetType = targetType;
    }

    try {
        const totalReports = await Report.countDocuments(filter);

        const reports = await Report.find(filter)
            .populate('reportingUser', 'username email')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limitNum);

        res.status(200).json({
            success: true,
            data: reports,
            totalReports,
            page: pageNum,
            limit: limitNum,
            totalPages: Math.ceil(totalReports / limitNum),
        });
    } catch (error) {
        console.error("Error fetching reports:", error);
        res.status(500);
        throw new Error("Failed to fetch reports.");
    }
});

// 8. update the status of a report
export const updateReportStatus = asyncHandler(async (req, res) => {
    const { status } = req.body;

    const report = await Report.findById(req.params.id);

    if (!report) {
        res.status(404);
        throw new Error('Report not found');
    }

    report.status = status;
    const updatedReport = await report.save();

    await updatedReport.populate('reportingUser', 'username email');

    res.status(200).json({
        success: true,
        message: 'Report status updated successfully',
        data: updatedReport,
    });
});

// 9. get details of a specific reported item (post or comment)
export const getReportedItem = asyncHandler(async (req, res) => {
    const report = await Report.findById(req.params.id).populate('reportingUser', 'username');

    if (!report) {
        res.status(404);
        throw new Error('Report not found');
    }

    let reportedItem = null;
    if (reportedItem === 'post'){
        reportedItem = await Post.findById(report.targetId).populate('user', 'username').lean();
    } else if (reportedItem === 'comment'){
        reportedItem = await Comment.findById(report.targetId).populate('user', 'username').lean();
    }

    if (!reportedItem) {
        return res.status(200).json({
            success: true,
            data: {
                _id: report.targetId,
                content: report.targetContent,
                user: report.reportedUser,
                createdAt: report.createdAt,
                isDeleted: true,
            },
            type: report.targetType,
        });
    }

    res.status(200).json({
        success: true,
        data: reportedItem,
        type: report.post ? 'post' : 'comment',
    });
});

// 10. get count of pending reports
export const getPendingReportsCount = asyncHandler(async (req, res) => {
    try {
        const count = await Report.countDocuments({ status: 'pending' });
        console.log(`Fetched pending reports count: ${count}`);
        res.status(200).json({
            success: true,
            count: count,
        });
    } catch (error) {
        console.error("Error fetching pending reports count:", error);
        res.status(500);
        throw new Error("Failed to fetch pending reports count.");
    }
});

// 11. delete a report
export const deleteReport = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const report = await Report.findById(id);

    if (!report) {
        res.status(404);
        throw new Error('Report not found');
    }

    await report.deleteOne();
    res.status(200).json({
        success: true,
        message: 'Report removed',
    });
});

export const deletePostByAdmin = asyncHandler(async (req, res) => {
    const { id } = req.params;

    const post = await Post.findById(id);
    if (!post) {
        res.status(404);
        throw new Error('Post not found');
    }

    await Comment.deleteMany({ post: id });

    await post.deleteOne();

    await Report.updateMany(
        { targetType: 'post', targetId: id },
        { $set: { status: 'actioned', targetContent: '[Deleted Post]'} },
    );

    res.status(200).json({
        success: true,
        message: 'Post and associated comments deleted successfully',
    });
});

export const deleteCommentByAdmin = asyncHandler(async (req, res) => {
    const { id } = req.params;

    const comment = await Post.findById(id);
    if (!comment) {
        res.status(404);
        throw new Error('Post not found');
    }

    await comment.deleteOne();

    await Report.updateMany(
        { targetType: 'comment', targetId: id },
        { $set: { status: 'actioned', targetContent: '[Deleted Comment]' } },
    );

    res.status(200).json({
        success: true,
        message: 'Comment deleted successfully',
    });
});


// 12. get all contact messages
export const getContactMessages = asyncHandler(async (req, res) => {
    // pagination
    const { page = 1, limit = 10, status, time } = req.query;

    const query = {};

    // filter
    if (status && status !== 'all') {
        query.status = status;
    }

    if (time && time !== 'all') {
        const now = dayjs();
        let startDate;

        switch (time) {
            case '24h':
                startDate = now.subtract(24, 'hour');
                break;
            case '7d':
                startDate = now.subtract(7, 'day');
                break;
            case '30d':
                startDate = now.subtract(30, 'day');
                break;
            default:
                break;
        }

        if (startDate) {
            query.createdAt = { $gte: startDate.toDate() };
        }
    }

    const numericPage = +page;
    const numericLimit = +limit;

    const messages = await Contact.find(query)
        .sort({ createdAt: -1 })
        .skip((numericPage - 1) * +numericLimit)
        .limit(numericLimit);

    const total = await Contact.countDocuments(query);

    res.status(200).json({
        success: true,
        data: messages,
        totalMessages: total,
    });
});

// 13. delete a contact message
export const deleteContactMessage = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const message = await Contact.findById(id);

    if (!message) {
        res.status(404);
        throw new Error('Contact message not found');
    }

    await message.deleteOne();
    res.status(200).json({
        success: true,
        message: 'Contact message removed',
    });
});

// 14. update contact message status
export const updateContactMessageStatus = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    const message = await Contact.findById(id);

    if (!message) {
        res.status(404);
        throw new Error('Contact message not found');
    }

    message.status = status;
    await message.save();

    res.status(200).json({
        success: true,
        message: 'Contact message updated successfully',
        data: message,
    });
});


