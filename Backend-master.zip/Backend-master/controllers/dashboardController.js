import mongoose from "mongoose";
import asyncHandler from "../utils/asyncHandler.js";
import Journal from "../models/Journal.js";
import { TOGETHER_API_KEY } from "../config.js";
import axios from "axios";
// get journals from each month
export const getAvailableMonths = asyncHandler(async (req, res) => {
  const { userID } = req.params;

  if (!mongoose.isValidObjectId(userID)) {
    return res.status(400).json({ error: "Invalid user ID" });
  }

  const data = await Journal.aggregate([
    {
      $match: {
        userID: new mongoose.Types.ObjectId(userID),
      },
    },
    {
      $project: {
        month: {
          $dateToString: {
            format: "%Y-%m",
            date: "$createdAt",
            timezone: "Europe/Berlin",
          },
        },
      },
    },
    {
      $group: {
        _id: "$month",
        count: { $sum: 1 },
      },
    },
    {
      $sort: { _id: -1 },
    },
  ]);
  res.json(data);
});

// emotion distribution -> pie chart

export const getEmotionDistribution = asyncHandler(async (req, res) => {
  const { userID } = req.params;
  const { month } = req.query;

  if (!mongoose.isValidObjectId(userID)) {
    return res.status(400).json({ error: "Invalid user ID" });
  }
  if (!month) {
    return res.status(400).json({ error: "Missing month parameter" });
  }

  const startDate = new Date(`${month}-01T00:00:00+01:00`);
  const endDate = new Date(
    new Date(startDate).setMonth(startDate.getMonth() + 1)
  );

  const data = await Journal.aggregate([
    {
      $match: {
        userID: new mongoose.Types.ObjectId(userID),
        createdAt: {
          $gte: startDate,
          $lt: endDate,
        },
      },
    },
    {
      $group: {
        _id: "$emotionLabels",
        count: { $sum: 1 },
      },
    },
  ]);

  const result = data.map((item) => ({
    name: item._id,
    value: item.count,
  }));
  res.json(result);
});

// average mood trend of the user -> line chart
export const getMoodTrend = asyncHandler(async (req, res) => {
  const { userID } = req.params;
  const { month } = req.query;

  if (!mongoose.isValidObjectId(userID)) {
    return res.status(400).json({ error: "Invalid user ID" });
  }
  if (!month) {
    return res.status(400).json({ error: "Missing month parameter" });
  }
  const startDate = new Date(`${month}-01`);
  const endDate = new Date(
    new Date(startDate).setMonth(startDate.getMonth() + 1)
  );

  const data = await Journal.aggregate([
    {
      $match: {
        userID: new mongoose.Types.ObjectId(userID),
        createdAt: {
          $gte: startDate,
          $lt: endDate,
        },
      },
    },
    {
      $project: {
        date: {
          $dateToString: {
            format: "%Y-%m-%d",
            date: "$createdAt",
            timezone: "Europe/Berlin",
          },
        },
        totalMoodScore: 1,
      },
    },
    {
      $group: {
        _id: "$date",
        averageScore: { $avg: "$totalMoodScore" },
      },
    },
    {
      $sort: { _id: 1 },
    },
  ]);

  const result = data.map((item) => ({
    date: item._id,
    averageScore: Number(item.averageScore?.toFixed(2)) || 0,
  }));

  res.json(result);
});

//get journal timeline

export const getJournalTimeline = asyncHandler(async (req, res) => {
  const { userID } = req.params;
  const { month } = req.query;

  if (!month) {
    return res.status(400).json({ error: "Missing month parameters" });
  }
  const startDate = new Date(`${month}-01T00:00:00+01:00`);
  const endDate = new Date(
    new Date(startDate).setMonth(startDate.getMonth() + 1)
  );

  const timelineData = await Journal.find({
    userID: new mongoose.Types.ObjectId(userID),
    createdAt: { $gte: startDate, $lt: endDate },
  }).select("createdAt");

  const result = timelineData.map((doc) => {
    const dateObj = new Date(doc.createdAt);
    return {
      date: dateObj.toISOString().slice(0, 10),
      time: dateObj.toISOString().slice(11, 16),
    };
  });
  return res.json({ data: result });
});

/**
 * Get monthly summary and generate natural language description via Together AI
 */
export const getMonthlySummary = asyncHandler(async (req, res) => {
  const userID = req.user._id;
  const month = req.query.month; // Expect format "YYYY-MM"

  if (!month || !/^\d{4}-\d{2}$/.test(month)) {
    return res.status(400).json({
      success: false,
      error:
        "Invalid or missing 'month' query parameter. Expected format: YYYY-MM",
    });
  }

  // Step 1: Define date range for query
  const [yearStr, monthStr] = month.split("-");
  const year = parseInt(yearStr, 10);
  const monthNum = parseInt(monthStr, 10); // 1-based

  const startDate = new Date(`${year}-${monthStr}-01T00:00:00.000Z`);
  const endDate =
    monthNum === 12
      ? new Date(`${year + 1}-01-01T00:00:00.000Z`)
      : new Date(
          `${year}-${String(monthNum + 1).padStart(2, "0")}-01T00:00:00.000Z`
        );

  // Step 2: Fetch journals in the given month for user
  const journals = await Journal.find({
    userID,
    createdAt: { $gte: startDate, $lt: endDate },
  });

  // If no journals found, return empty summary with empty text
  if (!journals.length) {
    return res.status(200).json({
      success: true,
      summary: {
        totalJournals: 0,
        mostFrequentLabel: null,
        highestAvgScoreDay: null,
        lowestAvgScoreDay: null,
        peakWritingHour: null,
        summaryText: "You did not write any journal this month.",
      },
    });
  }

  // Step 3: Calculate statistics (same as previous)
  const totalJournals = journals.length;

  const labelCountMap = {};
  journals.forEach(({ emotionLabels }) => {
    if (Array.isArray(emotionLabels)) {
      emotionLabels.forEach((label) => {
        labelCountMap[label] = (labelCountMap[label] || 0) + 1;
      });
    } else if (emotionLabels) {
      labelCountMap[emotionLabels] = (labelCountMap[emotionLabels] || 0) + 1;
    }
  });

  let mostFrequentLabel = null;
  let maxCount = 0;
  for (const [label, count] of Object.entries(labelCountMap)) {
    if (count > maxCount) {
      mostFrequentLabel = label;
      maxCount = count;
    }
  }

  // Use totalMoodScore to calculate daily average score
  const dailyScores = {};

  journals.forEach(({ createdAt, totalMoodScore }) => {
    const dayStr = createdAt.toISOString().slice(0, 10); // e.g., "2025-07-04"

    if (!dailyScores[dayStr]) {
      dailyScores[dayStr] = { sumScore: 0, count: 0 };
    }

    dailyScores[dayStr].sumScore += totalMoodScore;
    dailyScores[dayStr].count++;
  });

  // Calculate average totalMoodScore for each day
  const dailyAvgScores = Object.entries(dailyScores).map(
    ([day, { sumScore, count }]) => ({
      day,
      avg: sumScore / count,
    })
  );

  // Find the day with the highest and lowest average mood score
  let highestAvgScoreDay = null;
  let lowestAvgScoreDay = null;

  dailyAvgScores.forEach((entry) => {
    if (!highestAvgScoreDay || entry.avg > highestAvgScoreDay.avg) {
      highestAvgScoreDay = entry;
    }
    if (!lowestAvgScoreDay || entry.avg < lowestAvgScoreDay.avg) {
      lowestAvgScoreDay = entry;
    }
  });
  // Calculate peak writing hour
  const hourCountMap = {};
  journals.forEach(({ createdAt }) => {
    const hour = createdAt.getUTCHours();
    hourCountMap[hour] = (hourCountMap[hour] || 0) + 1;
  });

  let peakWritingHour = null;
  let maxHourCount = 0;
  for (const [hourStr, count] of Object.entries(hourCountMap)) {
    if (count > maxHourCount) {
      peakWritingHour = Number(hourStr);
      maxHourCount = count;
    }
  }

  // Step 4: Prepare prompt for Together AI
  const promptMessages = [
    {
      role: "system",
      content:
        "You are an assistant that summarizes a user's monthly journaling activity in a warm, empathetic, and encouraging tone. Provide only the final summary without explanations or reasoning.",
    },
    {
      role: "user",
      content: `Here is the user's journaling summary for the month ${month}:

- Total journals written: ${totalJournals}
- Most frequent emotional label: ${mostFrequentLabel || "None"}
- Day with highest average score: ${
        highestAvgScoreDay
          ? `${
              highestAvgScoreDay.day
            } (average score: ${highestAvgScoreDay.avg.toFixed(2)})`
          : "N/A"
      }
- Day with lowest average score: ${
        lowestAvgScoreDay
          ? `${
              lowestAvgScoreDay.day
            } (average score: ${lowestAvgScoreDay.avg.toFixed(2)})`
          : "N/A"
      }
- Peak journaling hour (UTC): ${
        peakWritingHour !== null ? `${peakWritingHour}:00` : "N/A"
      }

Please generate a brief and encouraging summary message in under 100 words that reflects these insights.`,
    },
  ];

  // Step 5: Call Together AI API to get summary text
  let summaryText = "";
  try {
    const togetherResponse = await axios.post(
      "https://api.together.xyz/v1/chat/completions",
      {
        model: "deepseek-ai/DeepSeek-R1-Distill-Llama-70B-Free",
        messages: promptMessages,
      },
      {
        headers: {
          Authorization: `Bearer ${TOGETHER_API_KEY}`,
        },
      }
    );
    // After calling Together AI API, process the response to remove any <think> parts
    summaryText = togetherResponse.data.choices[0].message.content.trim();

    // Check if response contains "<think>" tag
    if (summaryText.includes("<think>")) {
      // Split by lines and take the last line as the real message
      const parts = summaryText.split("\n");
      summaryText = parts[parts.length - 1].trim();
    }
  } catch (err) {
    console.error("Together AI summary generation error:", err);
    summaryText = "Keep up the good work journaling this month!";
  }

  // Step 6: Return summary with AI-generated text
  return res.status(200).json({
    success: true,
    summary: {
      totalJournals,
      mostFrequentLabel,
      highestAvgScoreDay,
      lowestAvgScoreDay,
      peakWritingHour,
      summaryText,
    },
  });
});
