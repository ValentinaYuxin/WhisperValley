import axios from "axios";
import asyncHandler from "../utils/asyncHandler.js";
import Journal from "../models/Journal.js";
import { TOGETHER_API_KEY } from "../config.js";
import { getWeatherInformation } from "./weatherController.js";
import User from "../models/User.js";
import { T2E_SERVICE_URL } from "../config.js";

// Helper function to capitalize first letter
const capitalize = (word) => {
  if (!word || typeof word !== "string") return "";
  return word.charAt(0).toUpperCase() + word.slice(1);
};

// Semester lecture period dates based on TUM schedule (hardcoded)
const summerLectureStart = new Date("2025-04-23");
const summerLectureEnd = new Date("2025-07-25");
const winterLectureStart = new Date("2025-10-13");
const winterLectureEnd = new Date("2026-02-06");

// Calculate exam season ranges:
// 1. 15 days before and after summer lecture end
const summerExamStart = new Date(summerLectureEnd);
summerExamStart.setDate(summerExamStart.getDate() - 15);

const summerExamEnd = new Date(summerLectureEnd);
summerExamEnd.setDate(summerExamEnd.getDate() + 15);

// 2. 15 days before winter lecture start until winter lecture start
const winterExamStart = new Date(winterLectureStart);
winterExamStart.setDate(winterExamStart.getDate() - 15);

const winterExamEnd = new Date(winterLectureStart);

// Function to check if a date is in either exam season range
function isExamSeason(date) {
  return (
    (date >= summerExamStart && date <= summerExamEnd) ||
    (date >= winterExamStart && date <= winterExamEnd)
  );
}

/**
 * Check if today is a public holiday in Munich (Bavaria, DE-BY),
 * and return holiday name if yes.
 * Uses Nager.Date API: https://date.nager.at/Api
 * Note: Nager.Date API only supports country-level holidays for DE,
 * so this approximates Bavaria by using all Germany holidays.
 * @param {Date} today - The date to check (usually current date)
 * @returns {Promise<{isHoliday: boolean, holidayName: string|null}>}
 *          Object with boolean and holiday name or null if none.
 */
async function isHoliday(today = new Date()) {
  try {
    const year = today.getFullYear();
    const dateStr = today.toISOString().slice(0, 10); // Format YYYY-MM-DD

    // Fetch all German public holidays for the year
    const response = await axios.get(
      `https://date.nager.at/api/v3/PublicHolidays/${year}/DE`
    );

    const holidays = response.data;

    // Find if today matches any holiday date
    const holidayToday = holidays.find((holiday) => holiday.date === dateStr);

    if (holidayToday) {
      return {
        isHoliday: true,
        holidayName: holidayToday.localName || holidayToday.name || null,
      };
    } else {
      return {
        isHoliday: false,
        holidayName: null,
      };
    }
  } catch (error) {
    console.error("[HolidayCheck] Failed to fetch holidays:", error.message);
    return {
      isHoliday: false,
      holidayName: null,
    };
  }
}

/**
 * Create feedback for a journal entry using emotion analysis and AI
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
export const createFeedback = asyncHandler(async (req, res) => {
  const { journalId } = req.body;

  // Step 0: Validate input presence of journalId
  if (!journalId) {
    return res.status(400).json({
      success: false,
      error: "Journal ID is required.",
    });
  }

  // Step 1: Fetch journal from database
  let journalEntry;
  try {
    journalEntry = await Journal.findById(journalId);
    if (!journalEntry) {
      return res.status(404).json({
        success: false,
        error: "Journal entry not found.",
      });
    }
  } catch (error) {
    console.error("[Feedback] Error fetching journal from DB:", error.message);
    return res.status(500).json({
      success: false,
      error: "Failed to fetch journal entry.",
    });
  }

  // Step 1.5: Fetch user's petName and favoriteWeather from User collection
  let petName = null;
  let favoriteWeather = null;
  try {
    const user = await User.findById(req.user._id).select({
      petName: 1,
      favoriteWeather: 1,
    });
    console.log("[Feedback] Fetched user for petName and weather:", user);
    if (user) {
      petName = user.petName || null;
      favoriteWeather = user.favoriteWeather || null;
    }
  } catch (error) {
    console.error("[Feedback] Error fetching user info:", error.message);
    // Not a blocking error, continue without petName and favoriteWeather
  }

  // Step 2: Extract content and emotion label from journal
  const journalText = journalEntry.content || "No content provided.";
  const emotionLabel =
    journalEntry.emotionLabels && journalEntry.emotionLabels.length > 0
      ? journalEntry.emotionLabels[0]
      : "Neutral";

  // Step 3: Call Python microservice for emotion analysis
  let emotionScores;
  let dominantEmotion;
  try {
    const pythonResponse = await axios.post(T2E_SERVICE_URL, {
      text: journalText,
    });

    emotionScores = pythonResponse.data;

    if (!emotionScores || Object.keys(emotionScores).length === 0) {
      dominantEmotion = "Neutral";
    } else {
      dominantEmotion = Object.entries(emotionScores).reduce(
        (max, curr) => (curr[1] > max[1] ? curr : max),
        ["", 0]
      )[0];
    }
  } catch (error) {
    console.error(
      "[Feedback] Error calling Python microservice:",
      error.message
    );
    return res.status(500).json({
      success: false,
      error: "Failed to analyze emotions.",
    });
  }

  // Step 4: Get current weather information
  let weatherData;
  try {
    const weatherResult = await getWeatherInformation();
    if (!weatherResult || !weatherResult.weatherinfo) {
      return res.status(400).json({
        success: false,
        error: "Weather data unavailable.",
      });
    }
    weatherData = weatherResult.weatherinfo;
  } catch (error) {
    console.error("[Feedback] Failed to fetch weather:", error.message);
    return res.status(500).json({
      success: false,
      error: "Failed to fetch weather data.",
    });
  }

  // Step 5: Determine if today is exam season
  const today = new Date();
  const examSeasonFlag = isExamSeason(today);

  // Step 6: Determine if today is a public holiday and get holiday name
  const holidayInfo = await isHoliday(today);
  const petNameToUse = petName && petName.trim() !== "" ? petName : "there";

  console.log("PetName for prompt:", petName);

  // Step 7: Compose the prompt message including petName, weather info, journal, emotion, exam season, holiday info
  const promptMessages = [
    {
      role: "system",
      content:
        "You are a friendly assistant who creates short, empathetic, and positive encouragement messages for users who write journals. Use their pet name if provided. Provide only the final encouragement message without explanations or reasoning.",
    },
    {
      role: "user",
      content: `Please address the user as "${petNameToUse}" in your message.

User wrote this journal:
"${journalText}"

Detected emotion from text analysis: ${capitalize(dominantEmotion)}
User's selected emotion label: ${capitalize(emotionLabel)}
User's favorite weather: ${
        favoriteWeather ? capitalize(favoriteWeather) : "N/A"
      }
Actual weather today: ${weatherData ? capitalize(weatherData) : "N/A"}

${
  examSeasonFlag
    ? "Important note: It is currently exam season, which can be stressful. Please remember to take breaks and be kind to yourself."
    : "It is not exam season."
}

${
  holidayInfo.isHoliday
    ? `Today is a public holiday: ${holidayInfo.holidayName}.`
    : "Today is not a public holiday."
}

Please generate a concise, empathetic, and positive encouragement message between 50 and 120 words, incorporating pet name and weather comparison. Make sure to mention the exam season if it is currently ongoing.`,
    },
  ];

  // Step 8: Call Together AI to generate feedback
  try {
    const togetherResponse = await axios.post(
      "https://api.together.xyz/v1/chat/completions",
      {
        model: "deepseek-ai/DeepSeek-R1-Distill-Llama-70B-Free",
        messages: promptMessages,
      },
      {
        headers: {
          Authorization: `Bearer ${TOGETHER_API_KEY}`,
        },
      }
    );

    let fullResponse = togetherResponse.data.choices[0].message.content;
    let feedbackMessage;

    // Parse out any internal thoughts if present
    if (fullResponse.includes("<think>")) {
      const parts = fullResponse.trim().split("\n");
      feedbackMessage = parts[parts.length - 1].trim();
    } else {
      feedbackMessage = fullResponse.trim();
    }

    // Step 9: Return the feedback message as API response
    return res.status(200).json({
      success: true,
      feedback: feedbackMessage,
    });
  } catch (error) {
    console.error(
      "[Feedback] Error calling Together AI:",
      error?.response?.data || error.message
    );
    return res.status(500).json({
      success: false,
      error: "Failed to generate feedback.",
      details: error?.response?.data || error.message,
    });
  }
});
