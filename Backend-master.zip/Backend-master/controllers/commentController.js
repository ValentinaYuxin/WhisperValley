import asyncHandler from '../utils/asyncHandler.js';
import Comment from '../models/Comment.js';
import Notification from '../models/Notification.js'; 
import Post from '../models/Post.js';       
import User from '../models/User.js';

import { anonymousCache, generateAnonymousName } from '../utils/anonymousUtils.js';
import { getIsLiked } from '../utils/likeUtils.js';
import { checkAndRewardTasks } from './userController.js';

export const createComment = asyncHandler(async (req, res) => {
  try {
    const { content, parentComment } = req.body;
    const postId = req.params.postId;
    if (!postId || !content) {
      return res.status(400).json({ error: 'Post ID and content are required' });
    }

    // If parentComment is provided, validate existence and post match
    if (parentComment) {
      const parent = await Comment.findById(parentComment);
      if (!parent) {
        return res.status(400).json({ error: 'Parent comment not found' });
      }
      if (parent.post.toString() !== postId) {
        return res.status(400).json({ error: 'Parent comment does not belong to this post' });
      }
    }

    // One anonymous name per user per post
    let displayName;
    if (req.user.isAnonymous) {
      const key = `${req.user._id}-${postId}`;
      let cached = anonymousCache.get(key);
      if (!cached) {
        cached = generateAnonymousName();
        anonymousCache.set(key, cached);
      }
      displayName = cached;
    } else {
      displayName = req.user.username;
    }

    const newComment = await Comment.create({
      post: postId,
      user: req.user._id,
      parentComment: parentComment || null,
      content
    });

    // If this is a reply to another comment, increment repliesCount on parent and notify parent comment owner
    let notifiedUsers = new Set();
    if (parentComment) {
      await Comment.findByIdAndUpdate(parentComment, { $inc: { repliesCount: 1 } });
      // Notify parent comment owner if not self
      const parent = await Comment.findById(parentComment);
      if (parent && parent.user.toString() !== req.user._id.toString()) {
        await Notification.create({
          targetType: 'Comment',
          targetId: parentComment,
          user: parent.user,
          senderName: displayName,
          type: 'comment',
          refId: newComment._id,
          isRead: false
        });
        notifiedUsers.add(parent.user.toString());
      }
    }

    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // If the commenter is not the post author, create a notification for the author (unless already notified)
    if (
      post.user.toString() !== req.user._id.toString() &&
      !notifiedUsers.has(post.user.toString())
    ) {
      await Notification.create({
        targetType: 'Post',
        targetId: postId,
        user: post.user,
        senderName: displayName,
        type: 'comment',
        refId: newComment._id,
        isRead: false
      });
    }

    const result = newComment.toObject();
    delete result.user; // Hide real user
    result.author = displayName;
    result.isOwner = req.user && newComment.user && newComment.user.equals(req.user._id);

    // Yuxin: Automatically reward points
    const user = await User.findById(post.user);
    await checkAndRewardTasks(user);

    res.status(201).json({
      comment: result
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create comment' });
  }
});

export const getCommentsForPost = asyncHandler(async (req, res) => {
  try {
    const postId = req.params.postId;
    const userId = req.user?._id;
    const comments = await Comment.find({ post: postId }).sort({ createdAt: 1 });

    // Map anonymous names
    const result = await Promise.all(comments.map(async (c) => {
      let displayName;
      const authorUser = await User.findById(c.user).select('username isAnonymous avatar');
      if (authorUser?.isAnonymous) {
        const key = `${c.user}-${c.post}`;
        let cached = anonymousCache.get(key);
        if (!cached) {
          cached = generateAnonymousName();
          anonymousCache.set(key, cached);
        }
        displayName = cached;
      } else {
        displayName = authorUser?.username || 'Unknown';
      }
      const commentObj = c.toObject();
      commentObj.author = displayName;
      delete commentObj.user;
      commentObj.isLiked = await getIsLiked(userId, 'Comment', c._id);
      commentObj.isOwner = userId && c.user && c.user.equals(userId);
      // Add avatar of the comment author
      const user = await User.findById(c.user).select('avatar');
      commentObj.avatar = user?.avatar || '';
      return commentObj;
   }));

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch comments' });
  }
});

// Get replies to a specific comment (nested)
export const getReplies = asyncHandler(async (req, res) => {
  try {
    const replies = await Comment.find({ parentComment: req.params.commentId })
      .sort({ createdAt: 1 }); // Oldest first, or -1 for newest first

    res.json(replies);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch replies' });
  }
});

export const updateComment = asyncHandler(async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.commentId);

    if (!comment) return res.status(404).json({ error: 'Comment not found' });
    const isOwner = comment.user.toString() === req.user._id.toString();
    if (!isOwner) {
      return res.status(403).json({ error: 'Not authorized to update' });
    }

    comment.content = req.body.content || comment.content;
    await comment.save();

    res.json({ message: 'Comment updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update comment' });
  }
});

export const deleteComment = asyncHandler(async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.commentId);

    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }

    const isOwner = comment.user.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ error: 'Not authorized to delete this comment' });
    }

    // If top-level comment, delete all its replies
    if (!comment.parentComment) {
      await Comment.deleteMany({ parentComment: comment._id });
    }

    await comment.deleteOne();

    res.json({ message: 'Comment deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to delete comment' });
  }
});

export const getCommentById = asyncHandler(async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.commentId);
    if (!comment) return res.status(404).json({ error: 'Comment not found' });
    const userId = req.user?._id;
    const authorUser = await User.findById(comment.user).select('username isAnonymous avatar');

    let displayName;
    if (authorUser?.isAnonymous) {
      const key = `${comment.user}-${comment.post}`;
      let cached = anonymousCache.get(key);
      if (!cached) {
        cached = generateAnonymousName();
        anonymousCache.set(key, cached);
      }
      displayName = cached;
    } else {
      displayName = authorUser?.username || 'Unknown';
    }

    const commentObj = comment.toObject();
    commentObj.author = displayName;
    delete commentObj.user;
    commentObj.isLiked = await getIsLiked(userId, 'Comment', comment._id);
    commentObj.isOwner = userId && comment.user && comment.user.equals(userId);
    res.json({ comment: commentObj });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch comment' });
  }
});