import User from '../models/User.js';
import asyncHandler from '../utils/asyncHandler.js';
import Post from '../models/Post.js';
import Like from '../models/Like.js';
import Comment from '../models/Comment.js';
import { getConsecutiveDays } from '../utils/dateUtils.js';

// 1. Get all users (admin only)
export const getAllUsers = asyncHandler(async (req, res) => {
  const users = await User.find().select('-password');
  return res.status(200).json({
    success: true,
    count: users.length,
    data: users,
  });
});

// 2. Get a single user by ID (self or admin)
export const getUserById = asyncHandler(async (req, res) => {
  const currentUser = req.user;

  if (!currentUser?.role) {
    return res.status(401).json({
      success: false,
      error: 'Unauthorized: User information is missing.',
    });
  }

  const user = await User.findById(req.params.id).select('-password');

  if (!user) {
    return res.status(404).json({
      success: false,
      error: `User with ID ${req.params.id} not found`,
    });
  }

  if (currentUser.id !== req.params.id && currentUser.role !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'Forbidden: Cannot access this user profile',
    });
  }

  return res.status(200).json({
    success: true,
    data: user,
  });
});

// 3. Update user profile (self or admin)
export const updateUser = asyncHandler(async (req, res) => {
  const currentUser = req.user;

  if (!currentUser?.role) {
    return res.status(401).json({
      success: false,
      error: 'Unauthorized: User information is missing.',
    });
  }

  const disallowedFields = [
    '_id',
    'password',
    'resetPasswordToken',
    'resetPasswordExpire',
    'createdAt',
    'updatedAt',
    '__v',
  ];

  const user = await User.findById(req.params.id);
  if (!user) {
    return res.status(404).json({
      success: false,
      error: `User with ID ${req.params.id} not found`,
    });
  }

  if (currentUser.id !== req.params.id && currentUser.role !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'Forbidden: Cannot update this user',
    });
  }

  // Safely update fields
  for (const key in req.body) {
    if (
      Object.prototype.hasOwnProperty.call(req.body, key) &&
      !disallowedFields.includes(key) &&
      key !== 'role' &&
      key !== 'isAnonymous' // handle isAnonymous separately
    ) {
      user[key] = req.body[key];
    }
  }

  // Handle isAnonymous explicitly (convert string to boolean)
  if (typeof req.body.isAnonymous !== 'undefined') {
    const raw = req.body.isAnonymous;
    const boolVal =
      raw === true ||
      raw === 'true' ||
      raw === 1 ||
      raw === '1';
    user.isAnonymous = boolVal;
  }

  // Handle avatar file (if uploaded)
  if (req.file) {
    user.avatar = `/uploads/${req.file.filename}`;
  }

  // Only admin can modify roles
  if (typeof req.body.role !== 'undefined') {
    if (currentUser.role === 'admin') {
      user.role = req.body.role;
    } else {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Only admin can modify user roles',
      });
    }
  }

  await user.save();

  const sanitizedUser = user.toObject();
  delete sanitizedUser.password;

  return res.status(200).json({
    success: true,
    data: sanitizedUser,
  });
});

// 4. Delete user (admin only)
export const deleteUser = asyncHandler(async (req, res) => {
  const currentUser = req.user;

  if (!currentUser?.role) {
    return res.status(401).json({
      success: false,
      error: 'Unauthorized: User information is missing.',
    });
  }

  const user = await User.findById(req.params.id);
  if (!user) {
    return res.status(404).json({
      success: false,
      error: `User with ID ${req.params.id} not found`,
    });
  }

  if (currentUser.id === user._id.toString()) {
    return res.status(403).json({
      success: false,
      error: 'Forbidden: Admin cannot delete their own account',
    });
  }

  if (currentUser.role === 'admin' && user.role === 'admin') {
    return res.status(403).json({
      success: false,
      error: 'Forbidden: Admin cannot delete another admin',
    });
  }

  await user.deleteOne();

  return res.status(200).json({
    success: true,
    data: {},
  });
});


const TASKS = {
  // Posts tasks
  posts_10: { goal: 10, points: 5 },
  posts_20: { goal: 20, points: 10 },
  posts_50: { goal: 50, points: 20 },
  posts_100: { goal: 100, points: 50 },
  posts_500: { goal: 500, points: 100 },
  posts_1000: { goal: 1000, points: 200 },
  posts_5000: { goal: 5000, points: 500 },

  // Likes tasks
  likes_10: { goal: 10, points: 5 },
  likes_20: { goal: 20, points: 10 },
  likes_50: { goal: 50, points: 20 },
  likes_100: { goal: 100, points: 50 },
  likes_500: { goal: 500, points: 100 },
  likes_1000: { goal: 1000, points: 200 },

  // Comments tasks
  comments_10: { goal: 10, points: 5 },
  comments_20: { goal: 20, points: 10 },
  comments_50: { goal: 50, points: 20 },
  comments_100: { goal: 100, points: 50 },
  comments_500: { goal: 500, points: 100 },
  comments_1000: { goal: 1000, points: 200 },

  // Consecutive posting days tasks
  days_10: { goal: 10, points: 10 },
  days_20: { goal: 20, points: 20 },
  days_30: { goal: 30, points: 30 },
  days_60: { goal: 60, points: 50 },
  days_90: { goal: 90, points: 70 },
  days_120: { goal: 120, points: 100 },
  days_300: { goal: 300, points: 200 },
  days_500: { goal: 500, points: 500 },
};

// Get the current user's points
export const getUserPoints = asyncHandler(async (req, res) => {
  const userId = req.user.id;

  const user = await User.findById(userId).select('point');
  if (!user) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }

  return res.status(200).json({
    success: true,
    data: { point: user.point || 0 },
  });
});

export async function checkAndRewardTasks(user) {
  const postIds = await Post.find({ user: user._id }).distinct('_id');
  const commentsCount = await Comment.countDocuments({ post: { $in: postIds } });
  const likesCount = await Like.countDocuments({ targetType: 'Post', targetId: { $in: postIds } });
  const postCount = postIds.length;

  // Calculate consecutive posting days
  const posts = await Post.find({ user: user._id }).select('createdAt');
  const postDates = posts.map(p => p.createdAt);
  const consecutiveDays = getConsecutiveDays(postDates);

  // Iterate over all tasks and reward the user if the goal is reached
  for (const [taskId, { goal, points }] of Object.entries(TASKS)) {
    if (user.completedTasks.includes(taskId)) continue; // Skip already completed tasks

    if (taskId.startsWith('posts_') && postCount >= goal) {
      user.point += points;
      user.completedTasks.push(taskId);
    } else if (taskId.startsWith('likes_') && likesCount >= goal) {
      user.point += points;
      user.completedTasks.push(taskId);
    } else if (taskId.startsWith('comments_') && commentsCount >= goal) {
      user.point += points;
      user.completedTasks.push(taskId);
    } else if (taskId.startsWith('days_') && consecutiveDays >= goal) {
      user.point += points;
      user.completedTasks.push(taskId);
    }
  }

  await user.save();
}


// Subtract points from the current user
export const subtractUserPoints = asyncHandler(async (req, res) => {
  const userId = req.user.id;
  const { pointsToSubtract } = req.body;

  // Validate pointsToSubtract: must be a positive number
  if (typeof pointsToSubtract !== 'number' || pointsToSubtract <= 0) {
    return res.status(400).json({ success: false, error: 'pointsToSubtract must be a positive number' });
  }

  const user = await User.findById(userId);
  if (!user) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }

  // Decrement the user's points but do not allow below zero
  user.point = Math.max(0, (user.point || 0) - pointsToSubtract);
  await user.save();

  return res.status(200).json({
    success: true,
    data: { point: user.point },
  });
});
