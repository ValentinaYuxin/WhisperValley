import asyncHandler from '../utils/asyncHandler.js';
import { stripe } from '../utils/stripe.js';

export const getInvoices = asyncHandler(async (req, res) => {
    if (!req.user.stripeCustomerId) {
        return res.status(200).json({ success: true, invoices: [] });
    }

    const invoices = await stripe.invoices.list({
        customer: req.user.stripeCustomerId,
        limit: 100,
    });

    const formattedInvoices = invoices.data.map(invoice => ({
        id: invoice.id,
        created: invoice.created,
        amountPaid: invoice.amount_paid,
        status: invoice.status,
        invoicePdf: invoice.invoice_pdf,
        description: invoice.lines.data[0]?.description || 'N/A',
    }));

    res.status(200).json({ success: true, invoices: formattedInvoices });
});