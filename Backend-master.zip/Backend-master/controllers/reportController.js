import asyncHandler from '../utils/asyncHandler.js'; // 
import Post from '../models/Post.js';
import Comment from '../models/Comment.js';
import Report from '../models/Report.js';

export const createReport = asyncHandler(async (req, res) => {
  const { targetType, targetId, reason } = req.body;
  const reporterId = req.user._id;

  if (!['post', 'comment'].includes(targetType)) {
    return res.status(400).json({ error: 'Invalid report type' });
  }

  if (!targetId || !reason) {
    return res.status(400).json({ error: 'Missing report fields' });
  }

  let reportedUser, targetContent;

  if (targetType === 'post') {
    const post = await Post.findById(targetId);
    if (!post) return res.status(404).json({ error: 'Post not found' });
    reportedUser = post.user;
    targetContent = post.content;
  } else {
    const comment = await Comment.findById(targetId);
    if (!comment) return res.status(404).json({ error: 'Comment not found' });
    reportedUser = comment.user;
    targetContent = comment.content; // Ensure targetContent is set for comments
  }

  const report = new Report({
    reporter: reporterId,
    targetType,
    targetId,
    reason,
    reportedUser,
    targetContent,
    reportingUser: req.user._id // Track who submitted the report
  });

  await report.save();
  res.status(201).json({ message: 'Report submitted successfully' });
});


export const getAllReports = asyncHandler(async (req, res) => {
  // Parse pagination parameters
  const page = Math.max(parseInt(req.query.page) || 1, 1);
  const limit = Math.max(parseInt(req.query.limit) || 20, 1);
  const skip = (page - 1) * limit;

  // Get total count of reports
  const total = await Report.countDocuments();

  // Fetch reports with pagination, excluding __v
  const reports = await Report.find()
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .select('-__v')
      .lean();

  // Respond with paginated result
  res.json({
    page,
    limit,
    totalPages: Math.ceil(total / limit),
    reports
  });
});
