import asyncHandler from "../utils/asyncHandler.js";
import Like from "../models/Like.js";
import Post from "../models/Post.js";
import Comment from "../models/Comment.js";
import User from '../models/User.js';
import Notification from '../models/Notification.js';
import { checkAndRewardTasks } from './userController.js';
import { anonymousCache, generateAnonymousName } from '../utils/anonymousUtils.js';

// TODO: connect with system notification later

// 1. manage like/unlike, update likeCount
const toggleLike = (targetType) => asyncHandler(async (req, res) => {
    const userID = req.user._id;
    // Only declare targetID once, using all possible param names
    const targetID = req.params.targetID || req.params.commentId || req.params.id;
    if (!targetID || !targetType) {
        return res.status(400).json({ success: false, error: 'Missing targetID or targetType' });
    }

    // Get the target ID from the appropriate parameter
    const targetModel = targetType === 'Post' ? Post : Comment;
    const target = await targetModel.findById(targetID);

    if (!target) {
        return res.status(404).json({
            success: false,
            error: `${targetType} not found`,
        });
    }

    // check if the user has already liked a post/comment
    const existingLike = await Like.findOne({ user: userID, targetType: targetType, targetId: targetID });

    if (existingLike) {
        // 1) already liked -> unlike -1
        await Like.deleteOne({ _id: existingLike._id });
        const updatedTarget = await targetModel.findByIdAndUpdate(
            targetID,
            { $inc: { likeCount: -1 } },
            { new: true }  // enable returning updated likeCount together
        );

        res.status(200).json({
            success: true,
            message: `${targetType} unliked successfully`,
            liked: false,
            likeCount: updatedTarget ? updatedTarget.likeCount : 0
        });
    } else {
        // 2) hasn't liked before -> like +1
        const newLike = await Like.create({ user: userID, targetType: targetType, targetId: targetID });
        const updatedTarget = await targetModel.findByIdAndUpdate(
            targetID,
            { $inc: { likeCount: 1 } },
            { new: true }
        );

        // Yuxin: 3. Automatically reward points to the owner of the liked content
        //    Find the user who owns this post or comment
        const ownerUser = await User.findById(target.user || target.userId);
            if (ownerUser) {
                await checkAndRewardTasks(ownerUser);
            }

        // Create notification for like (do not notify self-like)
        if (ownerUser && ownerUser._id.toString() !== userID.toString()) {
        let senderName;
        if (req.user.isAnonymous) {
          const key = `${req.user._id}-${targetID}`;
          let cached = anonymousCache.get(key);
          if (!cached) {
            cached = generateAnonymousName();
            anonymousCache.set(key, cached);
          }
          senderName = cached;
        } else {
          senderName =
            req.user.username || req.user.fullName || req.user.name || "Someone";
        }

        await Notification.create({
          targetType: targetType,
          targetId: targetID,
          user: ownerUser._id,
          senderName: senderName,
          type: "like",
          refId: newLike._id,
          isRead: false,
        });
      }

        res.status(201).json({
            success: true,
            message: `${targetType} liked successfully`,
            liked: true,
            likeCount: updatedTarget ? updatedTarget.likeCount : 0
        });
    }
});

// 2. get the like count of a post/comment
const getLikesCount = (targetType) => asyncHandler( async (req, res) => {
    const targetID = req.params.targetID;
    const targetModel = targetType === 'Post' ? Post : Comment;
    const target = await targetModel.findById(targetID).select('likeCount').lean();  // return a js object

    if (!target) {
        return res.status(404).json({
            success: false,
            error: `${targetType} not found`,
        });
    }

    res.status(200).json({
        success: true,
        data: { likesCount: target.likeCount}  // TODO: check, already same with field name in schemas
    });
});

// 3. check if the user has liked a post/comment
const checkUserLikedStatus = (targetType) => asyncHandler( async (req, res) => {
    const userID = req.user._id;
    const targetID = req.params.targetID;

    // find the liked record
    const liked = await Like.findOne({ user: userID, targetType: targetType, targetID: targetID });

    // convert to Boolean and return
    res.status(200).json({
        success: true,
        data: { liked: !!liked }
    });
});

export const toggleLikePost = toggleLike('Post');
export const toggleLikeComment = toggleLike('Comment');
export const getLikesCountPost = getLikesCount('Post');
export const getLikesCountComment = getLikesCount('Comment');
export const checkUserLikedStatusPost = checkUserLikedStatus('Post');
export const checkUserLikedStatusComment = checkUserLikedStatus('Comment');

// TODO: adjust post/comment routes later

// Notification format adjustment
