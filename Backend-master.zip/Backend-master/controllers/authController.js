import User from '../models/User.js';
import Subscription from '../models/Subscription.js';
import asyncHandler from '../utils/asyncHandler.js';
import jwt from 'jsonwebtoken';
import sendEmail from "../utils/sendEmail.js";
import crypto from 'crypto';

// 1. user registration -> POST
// To create an admin, you have to manually enter the MongoDB and modify the role
export const register = asyncHandler(async (req, res, next) => {
    const { username, email, password } = req.body;

    // console.log('Received registration request:');
    // console.log('Username:', username);
    // console.log('Email:', email);
    // console.log('Password (for dev only):', password);

    if (!username || !email || !password){
        return res.status(400).json({
            success: false,
            error: 'Please enter a username, email and password',
        });
    }

    if (password.length < 8){
        return res.status(400).json({
            success: false,
            error: 'Password must be at least 8 characters',
        });
    }

    const emailRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
        success: false,
        error: 'Please enter a valid email address',
        });
        }

    // allowed student email domains
    const allowedDomains = ["@mytum.de", "@tum.de", "@campus.lmu.de"];
    const hasValidDomain = allowedDomains.some((domain) =>
        email.toLowerCase().endsWith(domain)
    );
    if (!hasValidDomain) {
        return res.status(400).json({
            success: false,
            error: 'Please use your student email (e.g. @tum.de, @mytum.de or @campus.lmu.de)',
        });
    }

    const userExistsByEmail = await User.findOne({ email });
    if (userExistsByEmail){
        return res.status(400).json({
            success: false,
            error: 'A user with this email already exists',
        });
    }

    // create a new user
    const user = await User.create({
        username,
        email,
        password,
        role: 'user',
    });

    // start as a free sub user default
    const startDate = new Date();
    const endDate = new Date(startDate);
    endDate.setFullYear(endDate.getFullYear() + 100);

    await Subscription.create({
        user: user._id,
        plan: 'free',
        billingPeriod: 'N/A',
        startDate: startDate,
        endDate: endDate,
        isTrial: false,
        status: 'active',
        paymentMethod: 'N/A',
        paymentStatus: 'N/A',
    });

    // send JWT token in response
    sendToken(user, 201, res);
});

// 2. user login -> POST
export const login = asyncHandler(async (req, res, next) => {
    const { email, password } = req.body;

    // console.log('Received login request:');
    // console.log('Email:', email);
    // console.log('Password (for dev only):', password);

    if (!email || !password){
        return res.status(400).json({
            success: false,
            error: 'Please enter an email and password',
        });
    }

    // check if the user exists, contain password as well
    const user = await User.findOne({ email }).select('+password');

    if (!user){
        return res.status(401).json({
            success: false,
            error: 'Invalid credentials',
        });
    }

    // check if the password matches
    const isPassMatch = await user.matchPassword(password);

    if (!isPassMatch){
        return res.status(401).json({
            success: false,
            error: 'Invalid credentials',
        });
    }

    // send JWT token in response
    sendToken(user, 200, res);
});

// 3. get current logged in user -> GET
export const getMe = asyncHandler(async (req, res, next) => {
    //req.user is obtained through protect middleware
    const user = await User.findById(req.user.id);

    res.status(200).json({
        success: true,
        data: user,
    });
});

// 4. user logout -> GET
export const logout = asyncHandler(async (req, res, next) => {
    res.cookie('token', 'none', {
        expires: new Date(Date.now() + 10 * 1000),  // expire on 10s
        httpOnly: true,
    });

    res.status(200).json({
        success: true,
        data: {},
    });
});

// 5. forgot password -> POST
export const forgotPassword = asyncHandler(async (req, res, next) => {
    const user = await User.findOne({ email: req.body.email });

    // return generic success message for security reasons
    if (!user){
        return res.status(200).json({
            success: true,
            error: 'Email sent if user exists',
        });
    }

    // receive reset token (origin)
    const resetToken = user.getResetPasswordToken();

    // password still not defined
    await user.save({ validateBeforeSave: false });

    // create a reset url to send to the user via email
    const resetURL = `http://localhost:3000/resetpassword/${resetToken}`;

    const message =
        `You are receiving this email because you (or someone else) has requested the reset of a password. Please make a PUT request to: \\n\\n ${resetURL} \\n\\n If you did not request this, please ignore this email!`;

    try {
        await sendEmail({
            email: user.email,
            subject: 'Password Reset Token',
            message,
        });

        res.status(200).json({
            success: true,
            data: 'Password reset email sent successfully. Please check your email.',
        });
    } catch (e) {
        user.resetPasswordToken = undefined;
        user.resetPasswordExpire = undefined;

        await user.save({ validateBeforeSave: false });

        return res.status(500).json({
            success: false,
            error: 'Error sending email. Please try again later.',
        });
    }
});

// 6. reset password -> PUT
export const resetPassword = asyncHandler(async (req, res, next) => {
    // console.log('Received reset password request.');
    // console.log('Request parameters (req.params):', req.params);
    // console.log('Request body (req.body):', req.body);

    // get hashed token from url params
    const resetPasswordToken = crypto.createHash('sha256').update(req.params.resettoken).digest('hex');

    const user = await User.findOne({
        resetPasswordToken,
        resetPasswordExpire: { $gt: Date.now() },  // token must not be expired
    });

    if (!user) {
        // console.log('Invalid or expired reset token for:', resetPasswordToken);
        return res.status(400).json({
            success: false,
            error: 'Invalid or expired reset token',
        });
    }

    const password = req.body.password;

    // console.log('New password extracted:', password);
    // console.log('New password length:', password ? password.length : 'undefined/null');

    if (!password || password.length < 8){
        // console.log('New password failed length validation in backend.');
        return res.status(400).json({
            success: false,
            error: 'New password must be at least 8 characters',
        });
    }

    // set new password
    user.password = password;

    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;

    // pre-save hook: hash new password
    await user.save();

    // login immediately
    sendToken(user, 200, res);
    // console.log('Password reset successful for user:', user.email);
});


// 7. update password -> PUT
/**
 * @typedef {object} UpdatePasswordRequest
 * @property {string} currentPassword - The user's current password.
 * @property {string} newPassword - The new password to set.
 */
export const updatePassword = asyncHandler(async (req, res, next) => {
    const user = await User.findById(req.user.id).select('+password');

    // console.log('Received update password request:');
    // console.log('User ID:', req.user.id);
    // console.log('Current Password (for dev only):', req.body.currentPassword);
    // console.log('New Password (for dev only):', req.body.newPassword);

    // check if current password matches
    if (!(await user.matchPassword(req.body.currentPassword))) {
        return res.status(401).json({
            success: false,
            error: 'Current password is incorrect',
        });
    }

    const { newPassword } = req.body;
    if (!newPassword || newPassword.length < 8){
        return res.status(400).json({
            success: false,
            error: 'New password must be at least 8 characters',
        });
    }

    // set new password
    user.password = req.body.newPassword;
    await user.save();

    // send new token after password change for security
    sendToken(user, 200, res);
});

// private method: get the generated token from the User model and send response
const sendToken = (user, statusCode, res) => {
    const token = user.getSignedJwtToken();

    // configure cookie options, make cookies inaccessible to client-side
    const options = {
        expires: new Date(Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000),
        httpOnly: true,
    }

    // set the cookie with configured options and send json
    res.status(statusCode)
        .cookie('token', token, options)
        .json({
            success: true,
            token,
        });
}

