import Contact from '../models/Contact.js';
import asyncHandler from "../utils/asyncHandler.js";
import dayjs from "dayjs";

export const submitFeedback = asyncHandler(async (req, res) => {
  const { email, subject, message } = req.body;

  if (!email || !subject || !message) {
    return res.status(400).json({ success: false, message: 'All fields are required' });
  }

  try {
    const contact = await Contact.create({ email, subject, message });
    return res.status(201).json({ success: true, data: contact });
  } catch (err) {
    
    if (err.name === 'ValidationError') {
      const errors = {};
      for (let field in err.errors) {
        errors[field] = err.errors[field].message;
      }
      return res.status(400).json({ success: false, errors });
    }

    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});


export const getAllFeedback = asyncHandler(async (req, res) => {
  // pagination
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;

  // filter
  const status = req.query.status || 'all';
  const time = req.query.time || 'all';

  const query = {};

  if (status !== 'all') {
    query.status = status;
  }

  if (time !== 'all') {
    const now = dayjs();
    let dateFilter;
    switch (time) {
      case '24h':
        dateFilter = now.subtract(24, 'hour').toDate();
        break;
      case '7d':
        dateFilter = now.subtract(7, 'day').toDate();
        break;
      case '30d':
        dateFilter = now.subtract(30, 'day').toDate();
        break;
      default:
        break;
    }
    if (dateFilter) {
      query.createdAt = { $gte: dateFilter };
    }
  }

  const totalMessages = await Contact.countDocuments(query);

  const contacts = await Contact.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

  res.json({ success: true, data: contacts, totalMessages });
});

