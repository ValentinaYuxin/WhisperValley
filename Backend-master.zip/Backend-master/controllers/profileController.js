import asyncHandler from "../utils/asyncHandler.js";
import Post from "../models/Post.js";
import Comment from "../models/Comment.js";
import Like from "../models/Like.js";
import User from '../models/User.js';
import { getConsecutiveDays } from '../utils/dateUtils.js'; 

// 1. for all logged-in users
export const getMyPosts = asyncHandler( async (req, res) => {
    const posts = await Post.find({ user: req.user._id })
        .sort({ createdAt: -1 })
        .select('-user -__v');  // exclude userID and version

    res.status(200).json({
        success: true,
        count: posts.length,
        data: posts,
    });
});

export const getMyLikedPosts = asyncHandler( async (req, res) => {
    const userID = req.user._id;

    // find and sort all liked records of post according to like-createdAt
    const likedEntries = await Like.find({ user: userID, targetType: 'Post' })
        .select('targetId createdAt')
        .sort({ createdAt: -1 })
        .lean();  // return a js object

    const postIDs = likedEntries.map(entry => entry.targetId);

    if (postIDs.length === 0) {
        return res.status(200).json({
            success: true,
            count: 0,
            data: [],
        });
    }

    // use id to find posts, but orders not guaranteed
    const posts = await Post.find({ _id: { $in: postIDs } })
        .select('-user -__v -updatedAt')
        .lean();

    // create a new map for post id and posts for better iteration
    const postIDMap = new Map(posts.map(p => [p._id.toString(), p]));

    // combine
    const sortedLikedPosts = likedEntries.map(entry => {
        const post = postIDMap.get(entry.targetId.toString());

        if (post) {
            return { ...post, likedAt: entry.createdAt };
        }
        return null;
    }).filter(Boolean);  // prevent if a post is deleted but the likes remain

    return res.status(200).json({
        success: true,
        count: sortedLikedPosts.length,
        data: sortedLikedPosts,
    });
});

export const getMyComments = asyncHandler( async (req, res) => {
    const comments = await Comment.find({ user: req.user._id })
        .populate({
            path: 'post',
            select: 'title author content emoji emotionLabel',  // only show basic info about posts
        })
        .sort({ createdAt: -1 })
        .select('-user -__v');

    res.status(200).json({
        success: true,
        count: comments.length,
        data: comments,
    });
});


export const getOverview = asyncHandler(async (req, res) => {
  const userId = req.user._id;

  const user = await User.findById(userId);
  if (!user) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }

  // Fetch all posts created by the current user, only select createdAt and emoji
  const userPosts = await Post.find({ user: userId })
    .select("createdAt emoji")
    .lean();

  const postIds = userPosts.map((post) => post._id);

  let commentCount = 0;
  let postLikes = 0;

  // Count comments and likes only if user has posts
  if (postIds.length > 0) {
    [commentCount, postLikes] = await Promise.all([
      Comment.countDocuments({ post: { $in: postIds } }),
      Like.countDocuments({ targetType: "Post", targetId: { $in: postIds } }),
    ]);
  }

  const postCount = userPosts.length;

  // Extract all post creation dates in "YYYY-MM-DD" format
  const postDates = userPosts.map((post) =>
    post.createdAt.toISOString().split("T")[0]
  );

  
  const postCreatedAts = userPosts.map((post) => post.createdAt.toISOString());

  // Get emojis from posts created in the current month
  const now = new Date();
  const thisMonth = now.getMonth();
  const thisYear = now.getFullYear();

  const monthlyEmojis = userPosts
    .filter((post) => {
      const date = new Date(post.createdAt);
      return date.getMonth() === thisMonth && date.getFullYear() === thisYear;
    })
    .map((post) => post.emoji)
    .filter(Boolean); // remove null or undefined

  // Calculate how many days the user has been registered
  const joinedDate = new Date(req.user.createdAt);
  const startDate = new Date(joinedDate.getFullYear(), joinedDate.getMonth(), joinedDate.getDate());
  const currentDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const diffDays = Math.floor((currentDate - startDate) / (1000 * 60 * 60 * 24)) + 1;

  const consecutiveDays = getConsecutiveDays(postCreatedAts);

  // Send final overview response
  res.status(200).json({
    success: true,
    data: {
      day: diffDays,         
      posts: postCount,      
      comments: commentCount,
      likes: postLikes,      
      postDates,             
      postCreatedAts,        
      monthlyEmojis,         
      point: user?.point || 0,
      consecutiveDays,
    },
  });
});
