import Notification from '../models/Notification.js';
import Comment from '../models/Comment.js';
import Like from '../models/Like.js';
import asyncHandler from '../utils/asyncHandler.js';
import Post from '../models/Post.js';

/**
 * Get paginated notifications with related data populated dynamically.
 * Query params:
 *  - page: number (default 1)
 *  - limit: number (default 20)
 */
export const getNotifications = asyncHandler(async (req, res) => {
  // Parse pagination parameters from query, defaulting to page 1 and limit 20
  const page = Math.max(parseInt(req.query.page) || 1, 1);
  const limit = Math.max(parseInt(req.query.limit) || 20, 1);
  const skip = (page - 1) * limit;

  // Build query with type filter
  const query = { user: req.user._id };
  if (req.query.type) {
    query.type = req.query.type;
  }

  const notifications = await Notification.find(query)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .lean();

  let detailedNotifications = await Promise.all(
    notifications.map(async (notif) => {
      let postData = null;
      let commentContent = null;

      if (notif.type === 'comment') {
        const comment = await Comment.findById(notif.refId)
          .select('content post')
          .populate({ path: 'post', select: 'title content createdAt' })
          .lean();
        if (comment && comment.post) {
          postData = comment.post;
          commentContent = comment.content;
        }
      } else if (notif.type === 'like') {
        // For 'like' type notifications, find the like by refId and populate post/comment context
        const like = await Like.findById(notif.refId).lean();
        if (like) {
          if (like.targetType === 'Post') {
            postData = await Post.findById(like.targetId).select('title content createdAt').lean();
          } else if (like.targetType === 'Comment') {
            const comment = await Comment.findById(like.targetId)
              .populate({ path: 'post', select: 'title content createdAt' })
              .lean();
            if (comment && comment.post) {
              postData = comment.post;
              commentContent = comment.content; 
            }
          }
        }
      }

      if (!postData) return null;

      return {
        _id: notif._id,
        post: postData,
        targetType: notif.targetType, 
        type: notif.type,
        senderName: notif.senderName,
        content: commentContent,
        isRead: notif.isRead,
        createdAt: notif.createdAt,
      };
    })
  );

 // Filter out nulls (notifications with no post or comment context)
  detailedNotifications = detailedNotifications.filter((n) => n);

  const total = await Notification.countDocuments(query);

  res.json({
    success: true,
    user: req.user._id,
    data: detailedNotifications,
    pagination: {
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    },
  });
});

/**
 * Get the count of unread notifications for the authenticated user.
 * Query params:
 *  - type: string (optional) - filter by notification type ('comment' or 'like')
 */
export const getUnreadCount = asyncHandler(async (req, res) => {
  const filter = { user: req.user._id, isRead: false };
  
  // Add type filter if provided
  if (req.query.type) {
    filter.type = req.query.type;
  }

  const count = await Notification.countDocuments(filter);

  res.json({
    success: true,
    data: {
      unreadCount: count,
    },
  });
});

/**
 * Mark all notifications as read for the authenticated user.
 */
export const markAllRead = asyncHandler(async (req, res) => {
  const filter = { user: req.user._id, isRead: false };
  if (req.body.type) {
    filter.type = req.body.type;
  }

  await Notification.updateMany(filter, { isRead: true });

  res.json({
    success: true,
    message: 'Notifications marked as read',
  });
});
