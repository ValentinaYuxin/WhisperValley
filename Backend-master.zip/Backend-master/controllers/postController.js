import Post from '../models/Post.js';
import Comment from '../models/Comment.js';
import Like from '../models/Like.js';
import User from '../models/User.js';
import { getIsLiked } from '../utils/likeUtils.js';
import { checkAndRewardTasks } from './userController.js';
import { nanoid } from 'nanoid'; 

const generateAnonymousName = () => `Anonymous-${nanoid(6)}`;
const anonymousCache = new Map(); 

/**
 * Utility function to generate a random anonymous author name.
 * Example output: Anonymous-a9sB3D
 * - Uses nanoid(6) for ~56 billion combinations (very low collision risk).
 * - Protects user identity but keeps posts traceable anonymously.
 */

/**
 * @desc    Create a new anonymous post
 * @route   POST /api/posts
 * @access  Private (user role only)
 */
export const createPost = async (req, res) => {
  try {
    const { title, content, emoji, emotionLabel, tags } = req.body;
    const currentUser = req.user;
    let authorName = '';
    if (currentUser.isAnonymous) {
      authorName = generateAnonymousName();
    } else {
      authorName = currentUser.username;
    }
    const newPost = new Post({
      user: currentUser._id,
      author: authorName,
      title,
      content,
      emoji,
      emotionLabel,
      tags
    });

    await newPost.save();

     // Yuxin: Automatically reward points
    const user = await User.findById(req.user._id);
    await checkAndRewardTasks(user);

    const safePost = newPost.toObject();
    delete safePost.user;
    res.status(201).json(safePost);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

/**
 * @desc    Get a single post by ID and increment view count
 * @route   GET /api/posts/:id
 * @access  Private
 */
export const getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }
    // Only increment if user hasn't viewed before
    const userId = req.user?._id;
    if (userId && !post.viewedBy.includes(userId)) {
      post.views = (typeof post.views === 'number' ? post.views : 0) + 1;
      post.viewedBy.push(userId);
      await post.save();
    }
    // Strip user for anonymity
    const safePost = post.toObject();
    delete safePost.user;
    safePost.isLiked = await getIsLiked(req.user?._id, 'Post', post._id);
    safePost.isOwner = req.user && post.user && post.user.equals(req.user._id);
    res.json(safePost);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve post' });
  }
};

/**
 * @desc    Get all posts (latest first)
 * @route   GET /api/posts
 * @access  Private
 */
export const getPosts = async (req, res) => {
  try {
    // Extract query parameters
    const { tags, search, startDate, endDate, page = 1, limit = 10, emotionLabel } = req.query;
    const query = {};
    // Add this block for search filtering
    if (search) {
      const searchRegex = { $regex: search, $options: 'i' };
      query.$or = [
        { title: searchRegex },
        { content: searchRegex }
      ];
    }
    if (tags) {
      const tagsArray = Array.isArray(tags) ? tags : tags.split(',').map(t => t.trim()).filter(Boolean);
      if (tagsArray.length > 0) {
        query.tags = { $in: tagsArray };
      }
    }
    if (emotionLabel) {
      const emotionArray = Array.isArray(emotionLabel) ? emotionLabel : emotionLabel.split(',').map(e => e.trim()).filter(Boolean);
      if (emotionArray.length > 0) {
        query.emotionLabel = { $in: emotionArray };
      }
    }
    // Pagination
    const itemsPerPage = parseInt(limit);
    const currentPage = parseInt(page);
    const skip = (currentPage - 1) * itemsPerPage;
    // Query posts
    const posts = await Post.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(itemsPerPage)
      .lean();
    const postIds = posts.map(p => p._id);
    // Get comment counts for all posts
    const commentCounts = await Comment.aggregate([
      { $match: { post: { $in: postIds } } },
      { $group: { _id: "$post", count: { $sum: 1 } } }
    ]);
    const commentCountMap = Object.fromEntries(commentCounts.map(c => [c._id.toString(), c.count]));
    // Get like counts for all posts
    const likeCounts = await Like.aggregate([
      { $match: { targetType: "Post", targetId: { $in: postIds } } },
      { $group: { _id: "$targetId", count: { $sum: 1 } } }
    ]);
    const likeCountMap = Object.fromEntries(likeCounts.map(l => [l._id.toString(), l.count]));
    // Add counts to each post
    const postsWithCounts = posts.map(post => {
      const p = { ...post };
      p.commentCount = commentCountMap[post._id.toString()] || 0;
      p.likeCount = typeof post.likeCount === 'number' ? post.likeCount : (likeCountMap[post._id.toString()] || 0);
      p.views = typeof post.views === 'number' ? post.views : 0;
      delete p.user;
      return p;
    });
    // Get total count for pagination
    const totalItems = await Post.countDocuments(query);
    // Return posts with counts and pagination info
    res.json({
      posts: postsWithCounts,
      pagination: {
        totalItems,
        currentPage,
        itemsPerPage,
        totalPages: Math.ceil(totalItems / itemsPerPage)
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve post' });
  }
};

function isOwnerOrAdmin(post, user) {
  return post.user.toString() === user._id.toString() || user.role === 'admin';
}

/**
 * @desc    Update a post (only the creator can update)
 * @route   PUT /api/posts/:id
 * @access  Private
 */
export const updatePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }
    if (!isOwnerOrAdmin(post, req.user)) {
      return res.status(403).json({ error: 'Not authorized to update this post' });
    }
    // Update only the fields that were sent in the request
    const { title, content, emoji, emotionLabel, tags } = req.body;
    post.title = title ?? post.title;
    post.content = content ?? post.content;
    post.emoji = emoji ?? post.emoji;
    post.emotionLabel = emotionLabel ?? post.emotionLabel;
    post.tags = tags ?? post.tags;
    const updated = await post.save();
    // Hide internal user ID
    const safePost = updated.toObject();
    delete safePost.user;
    res.json(safePost);
  } catch (err) {
    console.error(err);
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(val => val.message);
      return res.status(400).json({ error: messages });
    }
    res.status(500).json({ error: 'Failed to update post' });
  }
};

/**
 * @desc    Get posts created by the current user
 * @route   GET /api/v1/posts/me
 * @access  Private
 */
export const getMyPosts = async (req, res) => {
  try {
    const posts = await Post.find({ user: req.user._id }).sort({ createdAt: -1 });

    const safePosts = posts.map(post => {
      const p = post.toObject();
     // delete p.user; // Preserve anonymity
      return p;
    });

    res.json(safePosts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch your posts' });
  }
};

/**
 * @desc    Delete a post
 * @route   DELETE /api/posts/:id
 * @access  Private (user = own post, admin = any post)
 */
export const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Allow deletion if user owns the post OR is an admin
    const isOwner = post.user.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ error: 'Not authorized to delete this post' });
    }

    await post.deleteOne();

    res.json({ message: 'Post deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to delete post' });
  }
};

/**
 * @desc    Get all unique tags used across posts
 * @route   GET /api/v1/posts/tags
 * @access  Private
 */
export const getAllTags = async (req, res) => {
  try {
    // Find all posts and extract tags
    const posts = await Post.find({}, 'tags');
    const allTags = posts
      .flatMap(post => post.tags || [])
      .filter(tag => tag && tag.trim() !== '');
    // Count tag occurrences
    const tagCounts = allTags.reduce((acc, tag) => {
      acc[tag] = (acc[tag] || 0) + 1;
      return acc;
    }, {});
    // Sort tags by count descending, then alphabetically
    const featuredTags = Object.entries(tagCounts)
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .slice(0, 5)
      .map(([tag]) => tag);
    res.json({ tags: featuredTags });
  } catch (err) {
    console.error('Error fetching tags:', err);
    res.status(500).json({ error: 'Failed to fetch tags' });
  }
};
