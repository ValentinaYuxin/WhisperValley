import axios from "axios";

export async function getWeatherInformation() {
  const username = "technischeuniversitaetmuenchen_gao_yuan";
  const password = "JC7X7p9Rpa";

  const date = new Date().toISOString().split(".")[0] + "Z";
  const lat = 48.12743;
  const lon = 11.57549;

  const url = `https://api.meteomatics.com/${date}/weather_symbol_1h:idx/${lat},${lon}/json`;

  try {
    const res = await axios.get(url, {
      auth: {
        username,
        password,
      },
    });
    let symbolId = res.data.data[0].coordinates[0].dates[0].value;
    if (symbolId >= 100) {
      symbolId -= 100;
    }
    const weatherMap = {
      0: "not determined",
      1: "clear sky",
      2: "light clouds",
      3: "partly cloudy",
      4: "cloudy",
      5: "rain",
      6: "sleet",
      7: "snow",
      8: "rain shower",
      9: "snow shower",
      10: "sleet shower",
      11: "light fog",
      12: "dense fog",
      13: "freezing rain",
      14: "thunderstroms",
      15: "drizzle",
      16: "sandstorm",
    };

    const weatherinfo = weatherMap[symbolId] || "unknown";

    return {
      weatherinfo,
    };
  } catch (error) {
    console.error("Failed to request weather data", error.message);
    return null;
  }
}
