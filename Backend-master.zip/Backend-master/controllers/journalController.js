// journalController.js
import mongoose from "mongoose";
import Journal from "../models/Journal.js";
import asyncHandler from "../utils/asyncHandler.js";

// @desc    Create a new journal entry
// @route   POST /api/v1/premium/journals
// @access  Private (requires authentication)
export const createJournalEntry = asyncHandler(async (req, res) => {
  const userID = req.user._id;
  const { questionaireScore, content, emotionLabels } = req.body;

  if (!questionaireScore || questionaireScore.length !== 3) {
    return res.status(400).json({ error: "Please fill all the questionnaire" });
  }

  if (!emotionLabels) {
    return res.status(400).json({ error: "Please select an emotion label" });
  }

  const journal = new Journal({
    userID,
    questionaireScore,
    content,
    emotionLabels,
  });

  await journal.save();

  res.status(201).json({
    success: true,
    message: "Journal saved.",
    journal,
    journalId: journal._id,
  });
});

// @desc    Get paginated journal entries for a user
// @route   GET /api/v1/premium/journals?page=1&limit=5
// @access  Private (requires authentication)
export const getJournals = asyncHandler(async (req, res) => {
  const userID = req.user._id;
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 5;
  const skip = (page - 1) * limit;

  const { start, end } = req.query;

  const query = { userID };

  if (start && end) {
    query.createdAt = {
      $gte: new Date(start),
      $lte: new Date(end),
    };
  }

  const total = await Journal.countDocuments(query);

  const journals = await Journal.find(query)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);

  res.status(200).json({
    success: true,
    data: journals,
    currentPage: page,
    totalPages: Math.ceil(total / limit),
    hasMore: skip + journals.length < total,
  });
});

// @desc    Delete a single journal entry
// @route   DELETE /api/v1/premium/journals/:id
// @access  Private (requires authentication)
export const deleteJournalEntry = asyncHandler(async (req, res) => {
  const userID = req.user._id;
  const journalID = req.params.id;

  if (!mongoose.Types.ObjectId.isValid(journalID)) {
    return res.status(400).json({ error: "Invalid journal ID" });
  }

  const journal = await Journal.findOne({ _id: journalID, userID });

  if (!journal) {
    return res.status(404).json({ error: "Journal not found" });
  }

  await Journal.deleteOne({ _id: journalID, userID });

  res.status(200).json({ message: "Journal deleted" });
});

// @desc    Get a single journal entry by ID
// @route   GET /api/v1/premium/journals/:id
// @access  Private (requires authentication)
export const getSingleJournal = asyncHandler(async (req, res) => {
  const userID = req.user._id;
  const journalID = req.params.id;

  if (!mongoose.Types.ObjectId.isValid(journalID)) {
    return res.status(400).json({ error: "Invalid journal ID" });
  }

  const journal = await Journal.findOne({ _id: journalID, userID });

  if (!journal) {
    return res.status(404).json({ error: "Journal not found" });
  }

  res.status(200).json({
    success: true,
    journal,
  });
});
