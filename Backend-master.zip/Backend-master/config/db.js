import mongoose from "mongoose";

const connectDB = async () => {
  try {
    // get the MONGO_URI from backend environment variables when processing
    const mongoURI = process.env.MONGO_URI;

    if (!mongoURI) {
      console.error(
        "Error: MONGO_URI environment variable is not set in Docker Compose."
      );
      process.exit(1);
    }

    const conn = await mongoose.connect(mongoURI);
    // , {
    //     useNewUrlParser: true,
    //     useUnifiedTopology: true,
    // })

    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error connecting to MongoDB: ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;
