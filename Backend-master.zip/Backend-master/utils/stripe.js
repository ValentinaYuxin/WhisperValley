import Stripe from 'stripe';
import Subscription from '../models/Subscription.js';
import asyncHandler from "./asyncHandler.js";
import Invoice from '../models/Invoice.js';
import User from "../models/User.js";

// Service layer only for all Stripe API interactions

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// 1. create a Checkout Session for trial or premium subscription
export const createCheckoutSession = asyncHandler(async (req, res) => {
    const { priceId, trialDays = 0 } = req.body;
    const user = req.user;

    let customerId = user.stripeCustomerId;
    if (!customerId) {
        const customer = await stripe.customers.create({
            email: user.email,
            name: user.name,
            metadata: { userId: user._id.toString() }
        });
        customerId = user.stripeCustomerId = customer.id;
        await user.save();
    }

    const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ['card'],
        mode: 'subscription',
        line_items: [{ price: priceId, quantity: 1 }],
        subscription_data: { trial_period_days: trialDays > 0 ? trialDays : undefined },
        success_url: process.env.FRONTEND_SUCCESS_URL,
        cancel_url: process.env.FRONTEND_CANCEL_URL,
    });

    res.status(201).json({ success: true, url: session.url, id: session.id });
});


// 2. update a Stripe subscription's plan (yearly/monthly)
export const updateStripeSubscription = asyncHandler(async (req, res, next) => {
    const { subId, newPriceId } = req.body;
    const stripeSub = await stripe.subscriptions.retrieve(subId);

    // trial users are not allowed to change plans
    if (stripeSub.status === 'trialing') {
        return res.status(400).json({ success: false, error: 'Cannot change plan during trial period' });
    }

    // update the subscription with the new price
    const updatedStripeSub = await stripe.subscriptions.update(subId, {
        items: [{ id: stripeSub.items.data[0].id, price: newPriceId }],
        proration_behavior: 'always_invoice', // prorate the change
    });

    // Sync local subscription
    const localSub = await Subscription.findOne({ stripeSubscriptionId: subId });
    if (localSub) {
        localSub.billingPeriod = updatedStripeSub.items.data[0].price.recurring.interval === 'year' ? 'yearly' : 'monthly';
        localSub.endDate = new Date(updatedStripeSub.billing_cycle_anchor * 1000);
        await localSub.save();
    }

    res.status(200).json({ success: true, subscription: localSub });
});

// 3. cancel a Stripe subscription at period end
export const cancelStripeSubscription = asyncHandler(async (req, res, next) => {
    const { subscriptionId } = req.body;
    if (!subscriptionId) {
        return res.status(400).json({ success: false, error: 'No subscriptionId provided' });
    }

    // const stripeSub = await stripe.subscriptions.retrieve(subscriptionId);

    let stripeSub;
    try {
        stripeSub = await stripe.subscriptions.retrieve(subscriptionId);
    } catch (error) {
        console.error(`Stripe API Error: Failed to retrieve subscription ${subscriptionId}:`, error.message);
        return res.status(500).json({ success: false, error: 'Failed to retrieve subscription from Stripe.' });
    }

    let newLocalStatus;
    try {
        if (stripeSub.status === 'trialing') {
            // trial sub cancels immediately
            await stripe.subscriptions.cancel(subscriptionId, {});  // TODO: check
            newLocalStatus = 'cancelled';
        } else {
            // regular premium cancels at the period end
            await stripe.subscriptions.update(subscriptionId, { cancel_at_period_end: true });
            newLocalStatus = 'canceling';
        }
    } catch (error) {
        console.error(`Stripe API Error: Failed to update subscription ${subscriptionId}:`, error.message);
        return res.status(500).json({ success: false, error: error.message || 'Failed to update subscription status on Stripe.' });
    }

    // Sync local subscription
    const localSub = await Subscription.findOne({ stripeSubscriptionId: subscriptionId });
    if (localSub) {
        localSub.status = newLocalStatus;
        await localSub.save();
    }

    res.status(200).json({ success: true, subscription: localSub });
});

// 4. immediately cancel a Stripe subscription
export const cancelStripeSubscriptionImmediately = asyncHandler(async (req, res, next) => {
    const { subscriptionId } = req.body;
    if (!subscriptionId) {
        return res.status(400).json({ success: false, error: 'No subscriptionId provided' });
    }

    const deletedStripeSub = await stripe.subscriptions.del(subscriptionId);

    // Sync local subscription and create free fallback
    const localSub = await Subscription.findOne({ stripeSubscriptionId: subscriptionId });
    if (localSub) {
        localSub.status = 'cancelled';
        localSub.endDate = new Date(deletedStripeSub.canceled_at * 1000);
        await localSub.save();
    }
    await Subscription.create({
        user: req.user._id,
        plan: 'free',
        status: 'active',
        startDate: new Date(),
        endDate: null
    });

    res.status(200).json({ success: true, subscription: localSub });
});


// * handle Stripe webhook events
export const handleStripeWebhook = asyncHandler(async (req, res) => {
    let event;

    try {
        event = stripe.webhooks.constructEvent(
            req.body,
            req.headers['stripe-signature'],
            process.env.STRIPE_WEBHOOK_SECRET
        );
        console.log(`Received Stripe webhook event: ${event.type}`);
    } catch (err) {
        console.error("Webhook signature verification failed:", err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    try {
        const stripeSub = event.data.object;
        const user = await User.findOne({ stripeCustomerId: stripeSub.customer });
        if (!user) {
            console.warn("No user found for Stripe customer ID:", stripeSub.customer);
            return res.status(404).json({ error: 'User not found' });
        }

        switch (event.type) {
            case 'checkout.session.completed': {
                const sessionWithSub = await stripe.checkout.sessions.retrieve(
                    stripeSub.id, { expand: ['subscription'] }
                );
                const fullSub = sessionWithSub.subscription;

                if (!fullSub) {
                    console.error("Critical: Subscription object not found in checkout.session.completed event.", sessionWithSub.id);
                    return res.status(400).json({
                        error: 'Subscription data not found in session.'
                    });
                }

                // cancel any existing active subscription
                await Subscription.updateMany(
                    { user: user._id, status: { $in: ['active', 'trialing'] } },
                    { $set: { status: 'cancelled', endDate: new Date() }}
                );

                const startDate = fullSub.status === 'trialing'
                    ? new Date(fullSub.trial_start * 1000)
                    : new Date(fullSub.start_date * 1000);

                const interval = fullSub.items.data[0].price.recurring.interval; // "month" or "year"
                const billingPeriod = interval === 'year' ? 'yearly' : 'monthly';

                let endDate;
                if (fullSub.status === 'trialing') {
                    endDate = new Date(fullSub.trial_end * 1000);
                } else {
                    endDate = new Date(startDate);
                    if (billingPeriod === 'monthly') {
                        endDate.setMonth(endDate.getMonth() + 1);
                    } else if (billingPeriod === 'yearly') {
                        endDate.setFullYear(endDate.getFullYear() + 1);
                    }
                }

                // create new subscription
                await Subscription.create({
                    user: user._id,
                    plan: 'premium',
                    billingPeriod,
                    status: fullSub.status,
                    startDate: startDate,
                    endDate: endDate,
                    stripeSubscriptionId: fullSub.id,
                    // paymentMethod: 'Stripe',
                    // paymentStatus: 'paid',
                });
                console.log('subscription created for user', stripeSub.id);
                break;
            }

            // only update existing on status changes, only for premium not for trial
            case 'customer.subscription.updated': {
                const existing = await Subscription.findOne({ stripeSubscriptionId: stripeSub.id });

                if (existing) {
                    console.log('stripeSub.current_period_end:', stripeSub.current_period_end);
                    console.log('stripeSub.status (from webhook):', stripeSub.status);
                    console.log('stripeSub.cancel_at_period_end (from webhook):', stripeSub.cancel_at_period_end);

                    if (stripeSub.status === 'cancelled') {
                        existing.status = 'cancelled';
                        existing.endDate = new Date(stripeSub.canceled_at * 1000 || Date.now());
                    } else {
                        existing.status = stripeSub.cancel_at_period_end ? 'canceling' : stripeSub.status;

                        if (typeof stripeSub.current_period_end === 'number' && !isNaN(stripeSub.current_period_end)) {
                            existing.endDate = new Date(stripeSub.current_period_end * 1000);
                        } else {
                            existing.endDate = new Date();
                        }
                    }

                    existing.billingPeriod = stripeSub.items.data[0].price.recurring.interval === 'year' ? 'yearly' : 'monthly';

                    await existing.save();
                    console.log(`Subscription updated for user ${user._id}. New local status: ${existing.status}, endDate: ${existing.endDate}`);
                }
                break;
            }

            case 'customer.subscription.deleted': {
                console.log('Received customer.subscription.deleted event. Stripe Subscription object:', stripeSub);
                const existing = await Subscription.findOne({ stripeSubscriptionId: stripeSub.id });
                if (existing) {
                    existing.status = 'cancelled';
                    existing.endDate = new Date(stripeSub.canceled_at * 1000);
                    await existing.save();
                }

                await Subscription.updateMany(
                    { user: user._id, plan: 'premium', status: { $in: ['active', 'trialing', 'canceling'] } },
                    { $set: { status: 'cancelled', endDate: new Date()} }
                )

                const newFreeSub = await Subscription.create({
                    user: user._id,
                    plan: 'free',
                    status: 'active',
                    startDate: new Date(),
                    endDate: null
                });
                console.log("New free subscription created:", newFreeSub);
                console.log("Reverted to free plan for user", user._id.toString());
                break;
            }

            case 'invoice.payment_succeeded': {
                const invoice = event.data.object;

                console.log('Received invoice.payment_succeeded event.Invoice object:', invoice);

                if (invoice.amount_paid > 0) {
                    await Invoice.create({
                        user: user._id,
                        stripeInvoiceId: invoice.id,
                        amountPaid: invoice.amount_paid / 100,
                        paidAt: new Date(invoice.status_transitions.paid_at * 1000),
                        invoicePdf: invoice.invoice_pdf
                    });
                } else {
                    console.log('Skipping invoice creation for zero-amount invoice:', invoice.id);
                }

                break;
            }
        }
    } catch (err) {
        console.error("Error handling webhook", event.type, err);
    }

    res.status(200).json({ received: true });
});