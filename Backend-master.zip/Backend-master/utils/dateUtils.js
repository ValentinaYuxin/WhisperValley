import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';
import timezone from 'dayjs/plugin/timezone.js';

dayjs.extend(utc);
dayjs.extend(timezone);

/**
 * Calculate the number of consecutive days the user has posted.
 * @param {Date[]} postDates - Array of Date objects representing post creation times.
 * @returns {number} Number of consecutive days posted up to today.
 */
export function getConsecutiveDays(postDates) {
  if (!postDates || postDates.length === 0) return 0;

  // Convert postDates to strings of format YYYY-MM-DD in Europe/Berlin timezone
  const localDates = postDates.map((d) =>
    dayjs.utc(d).tz('Europe/Berlin').format('YYYY-MM-DD')
  );

  // Get unique dates and sort descending (latest first)
  const uniqueDates = Array.from(new Set(localDates)).sort((a, b) =>
    dayjs(b).diff(dayjs(a))
  );

  let count = 0;
  let today = dayjs().tz('Europe/Berlin').startOf('day');
  const dateSet = new Set(uniqueDates);

  // Count consecutive days starting from today going backwards
  while (dateSet.has(today.format('YYYY-MM-DD'))) {
    count++;
    today = today.subtract(1, 'day');
  }

  return count;
}
