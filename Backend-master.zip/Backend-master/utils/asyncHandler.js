// a wrapper for async Express route handlers which avoids manual try-catch in every async route
const asyncHandler = (func) => (req, res, next) =>
    Promise.resolve(func(req, res, next)).catch(next);

export default asyncHandler;