import Like from "../models/Like.js";

/**
 * Checks if the user has liked the target (post or comment).
 * @param {string} userId - The user's ID.
 * @param {string} targetType - 'Post' or 'Comment'.
 * @param {string} targetId - The post or comment ID.
 * @returns {Promise<boolean>}
 */
export async function getIsLiked(userId, targetType, targetId) {
  if (!userId) return false;
  const like = await Like.findOne({ user: userId, targetType, targetId });
  return !!like;
}