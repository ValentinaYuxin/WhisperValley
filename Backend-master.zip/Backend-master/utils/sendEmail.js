import nodemailer from 'nodemailer';

// Mailtrap is only used for development environment and testing !

// TODO: replace in production env.

const sendEmail = async (options) => {
    const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: process.env.SMTP_PORT,
        secure: false,  // noy use SSL directly on port 2525
        auth: {
            user: process.env.SMTP_EMAIL,
            pass: process.env.SMTP_PASSWORD,
        }
    });

    const message = {
        from: '${process.env.SMTP_FROM_NAME || \'Whispering Valley Support\'} <${process.env.SMTP_EMAIL}>',
        to: options.email,
        subject: options.subject,
        html: options.message,
    }

    const info = await transporter.sendMail(message);

    console.log('Message sent: %s', info.messageId);
};

export default sendEmail;
