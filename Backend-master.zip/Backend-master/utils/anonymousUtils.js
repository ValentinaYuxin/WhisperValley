import { nanoid } from 'nanoid';

export const anonymousCache = new Map();

export const generateAnonymousName = () => `Anonymous-${nanoid(6)}`;