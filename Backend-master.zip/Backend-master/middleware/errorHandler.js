// global error handling middleware for Express, catch errors passed from route handlers via next
const errorHandler = (err, req, res, next) => {
    let error = { ...err };
    error.message = err.message;

    console.log(err.stack);

    // Mongoose bad ObjectId
    if (err.name === 'CastError') {
        const message = `Resource not found with id of ${err.value}`;
        error = { ...error, statusCode: 404, message };
    }

    // Mongoose duplicate key
    if (err.code === 11000) {
        // combine all duplicate elements of this array into a single string
        const duplicate = Object.keys(err.keyValue).join(', ');
        const message = `The ${duplicate} you entered is already in use. Please try a different one.`;
        error = { ...error, statusCode: 400, message };
    }

    // Mongoose validation error
    if (err.name === 'ValidationError') {
        const message = Object.values(err.errors).map(val => val.message).join('. ');
        error = { ...error, statusCode: 400, message };
    }

    // JWT malformed or expired error
    if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
        const message = 'Not authorized, token failed or expired.';
        error = { ...error, statusCode: 401, message };
    }

    res.status(error.statusCode || 500).json({
        success: false,
        error: error.message || 'Server error',
    });
}

export default errorHandler;