import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import asyncHandler from '../utils/asyncHandler.js';

// verify the authentication status of the current request, ensure user is logged in to protect routes
// req.user is obtained through protect method
export const protect = asyncHandler(async (req, res, next) => {
    let token;

    // check if Bearer token is in Authorization header
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        token = req.headers.authorization.split(' ')[1];
    } else if (req.cookies.token) {
        token = req.cookies.token;  // cookies are httpOnly
    }

    // check if token exists
    if (!token) {
        return res.status(401).json({
            success: false,
            error: 'Not authorized, please log in',
        });
    }

    // check if user exists
try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id);

    if (!req.user) {
        return res.status(401).json({
            success: false,
            error: 'User not found, please log in again',
        });
    }

    console.log('token:', token);
    console.log('decoded:', decoded);
    console.log('req.user:', req.user);

    next();
} catch (error) {
    console.error(error);
    return res.status(401).json({
        success: false,
        error: 'Not authorized, please log in',
    });
}

});

// role-based access control
export const authorize = (...roles) => {
    return (req, res, next) => {
        if (!req.user || !req.user.role || !roles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                error: `Unauthorized access for this role ${req.user && req.user.role ? req.user.role : 'unknown'}`,
            });
        }
        next();
    };
}