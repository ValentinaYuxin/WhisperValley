import Subscription from "../models/Subscription.js";
import asyncHandler from "../utils/asyncHandler.js";

// check if a user has an active and valid subscription for accessing premium features
export const checkSubStatus = (requiredPlan = []) =>
  asyncHandler(async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: "Please login to access this resource",
      });
    }

    // Admin can access to all protected routes directly!
    if (req.user.role === "admin") {
      return next();
    }

    try {
      // find the user's latest active or trial sub
      const sub = await Subscription.findOne({
        user: req.user._id,
        status: { $in: ["active", "trialing", "canceling"] },
        endDate: { $gt: new Date() }, // ensure end date not expire
      }).sort({ createdAt: -1 }); // descending

      if (!sub) {
        return res.status(403).json({
          success: false,
          error: "Access denied: no active subscription found.",
        });
      }

      // prevent required 'premium' but actually 'free' now
      if (requiredPlan.length > 0 && !requiredPlan.includes(sub.plan)) {
        return res.status(403).json({
          success: false,
          error:
            "Access denied: your subscription plan is not allowed to access this resource. Please upgrade.",
        });
      }
      req.sub = sub;
      next();
    } catch (error) {
      console.error("Error during subscription status check:", error);
      return res.status(500).json({
        success: false,
        error: "Server error during subscription check.",
      });
    }
  });
