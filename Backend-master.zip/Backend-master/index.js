import express from 'express';
import connectDB from './config/db.js';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import errorHandler from './middleware/errorHandler.js';

import bodyParser from 'body-parser';

import adminRoutes from './routes/adminRoutes.js';

import contactRoutes from './routes/contactRoutes.js';
import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';
import profileRoutes from './routes/profileRoutes.js';
import postRoutes from './routes/postRoutes.js';
import commentRoutes from './routes/commentRoutes.js';
import subscriptionRoutes from './routes/subscriptionRoutes.js';
import invoiceRoutes from './routes/invoiceRoutes.js';
import premiumRoutes from './routes/premiumRoutes.js';
import reportRoutes from './routes/reportRoutes.js';
import notificationRoutes from './routes/notificationRoutes.js';
import { handleStripeWebhook } from './utils/stripe.js';
import likeRoutes from './routes/likeRoutes.js';
import path from "path";
import { fileURLToPath } from 'url';

// Fix for __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// connect to DB before other operations that requires DB connections
connectDB();

const app = express();
const port = 8080; // must be the same as in docker file

// enable CORS for cross-origin requests
app.use(cors({
	origin: 'http://localhost:3000',
	credentials: true,
}));

// add stripe webhook route before express to get raw
app.post('/api/v1/stripe-webhook', bodyParser.raw({ type: 'application/json' }), handleStripeWebhook);

app.use(express.json());

app.use(cookieParser());


// Serve static files for uploaded avatars (e.g. /uploads/avatar-123.jpg)
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));

// route mounting
app.use('/api/v1/contact', contactRoutes);
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/users', userRoutes);
app.use('/api/v1/profiles', profileRoutes);
app.use('/api/v1/posts', postRoutes);
app.use('/api/v1/comments', commentRoutes); 
app.use('/api/v1/subscriptions', subscriptionRoutes);
app.use('/api/v1/invoices', invoiceRoutes);
app.use('/api/v1/premium', premiumRoutes);
app.use('/api/v1/reports', reportRoutes);
app.use('/api/v1/notifications', notificationRoutes);
app.use('/api/v1/likes', likeRoutes);

// Admin routes should be protected and require admin role
app.use('/api/v1/admin', adminRoutes);

app.use(errorHandler);

// only for testing
app.get('/', (req, res) => {
	res.send('Whispering Valley Backend API is running!');
});

app.listen(port, () => {
	console.log(`Server is running at http://localhost:${port}`);
});
