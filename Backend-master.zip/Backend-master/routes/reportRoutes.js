import express from 'express';
import { createReport, getAllReports } from '../controllers/reportController.js';
import { protect, authorize } from '../middleware/authMiddleware.js'; 

const router = express.Router();

// Submit a report (authenticated users only)
router.post('/', protect, createReport);

// Admin-only: Get all reports
router.get('/', protect, authorize('admin'), getAllReports);

export default router;
