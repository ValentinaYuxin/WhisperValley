import express from "express";
import { protect, authorize } from "../middleware/authMiddleware.js";
import { checkSubStatus } from "../middleware/subMiddleware.js";

import {
  createJournalEntry,
  getJournals,
  deleteJournalEntry,
  getSingleJournal,
} from "../controllers/journalController.js";

import {
  getAvailableMonths,
  getEmotionDistribution,
  getMoodTrend,
  getJournalTimeline,
  getMonthlySummary,
} from "../controllers/dashboardController.js";

import { createFeedback } from "../controllers/feedbackController.js";

// All premium services are managed and secured through this unified route.

const router = express.Router();

router.use(protect);
router.use(checkSubStatus(["premium", "trialing"]));

router.route("/journals").post(createJournalEntry).get(getJournals);

router.route("/journals/:id").get(getSingleJournal).delete(deleteJournalEntry);

router.get("/dashboard/:userID/months", getAvailableMonths);

router.get("/dashboard/:userID/emotion-distribution", getEmotionDistribution);

router.get("/dashboard/:userID/score-trend", getMoodTrend);

router.get("/dashboard/:userID/journal-timeline", getJournalTimeline);

router.post("/feedback", createFeedback);

router.get("/dashboard/:userID/monthly-summary", getMonthlySummary);

export default router;
