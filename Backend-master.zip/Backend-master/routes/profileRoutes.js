import express from 'express';
import { protect } from "../middleware/authMiddleware.js";
import { checkSubStatus } from "../middleware/subMiddleware.js";
import {
    getMyPosts,
    getMyLikedPosts,
    getMyComments,
    getOverview,
} from "../controllers/profileController.js";  // TODO: check later

const router = express.Router();

router.use(protect);


router.route('/posts').get(getMyPosts);
router.route('/liked-posts').get(getMyLikedPosts);
router.route('/comments').get(getMyComments);
router.route('/overview').get(getOverview);

export default router;