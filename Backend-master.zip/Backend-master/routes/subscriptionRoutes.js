import express from 'express';
import {
    startTrial,
    upgradeToPremium,
    cancelSubscription,
    cancelImmediately,
    getCurrent,
    getHistory,
    getSubById, changePlan,
} from "../controllers/subscriptionController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

router.use(protect);

router.route('/trial').post(startTrial);
router.route('/upgrade').post(upgradeToPremium);
router.route('/change-plan').post(changePlan);
router.route('/cancel').post(cancelSubscription);
router.route('/cancel-immediately').post(cancelImmediately);
router.route('/current').get(getCurrent);
router.route('/history').get(getHistory);
router.route('/:id').get(getSubById);

export default router;