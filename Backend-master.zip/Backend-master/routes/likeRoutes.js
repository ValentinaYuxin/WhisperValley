import express from 'express';
import {
  toggleLikePost,
  toggleLikeComment,
  getLikesCountPost,
  getLikesCountComment,
  checkUserLikedStatusPost,
  checkUserLikedStatusComment
} from '../controllers/likeController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes require authentication
router.use(protect);

// Post likes
router.post('/posts/:targetID/like', toggleLikePost);
router.get('/posts/:targetID/count', getLikesCountPost);
router.get('/posts/:targetID/status', checkUserLikedStatusPost);

// Comment likes
router.post('/comments/:targetID/like', toggleLikeComment);
router.get('/comments/:targetID/count', getLikesCountComment);
router.get('/comments/:targetID/status', checkUserLikedStatusComment);

export default router;