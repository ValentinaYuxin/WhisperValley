import express from 'express';
import {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getUserPoints,
  subtractUserPoints,
} from '../controllers/userController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';
import upload from '../middleware/uploadMiddleware.js'; // multer middleware

const router = express.Router();

// Protect all routes
router.use(protect);

// Admin-only route
router.route('/').get(authorize('admin'), getAllUsers);

router.get('/points', getUserPoints);
router.post('/points/subtract', subtractUserPoints);

// User-specific operations
router
  .route('/:id')
  .get(getUserById)
  .put(upload.single('avatar'), updateUser) // parse FormData
  .delete(authorize('admin'), deleteUser);

export default router;
