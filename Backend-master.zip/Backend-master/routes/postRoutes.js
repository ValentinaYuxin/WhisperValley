import express from 'express';
import {
  getPosts,
  getPostById,
  createPost,
  updatePost,
  getMyPosts,
  deletePost,
  getAllTags
} from '../controllers/postController.js';

import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

router
  .route('/')
  .get(protect, getPosts) // Any logged-in user can view posts
  .post(protect, authorize('user'), createPost);
 // .post(protect, authorize('user', 'admin'), createPost); // Users/admins can create posts

 //  Get posts created by the logged-in user
router
  .route('/me')
  .get(protect, getMyPosts);

// Route to get all unique tags
router
  .route('/tags')
  .get(protect, getAllTags);

router
  .route('/:id')
  .get(protect,getPostById)
  .put(protect,updatePost)
  .delete(protect, deletePost); // Anyone authenticated can attempt to delete

// Routes for updating and deleting posts by the owner only
router
  .route('/me/:id')
  .patch(protect, updatePost) // Only the owner can update
  .delete(protect, deletePost); // Only the owner can delete

export default router;