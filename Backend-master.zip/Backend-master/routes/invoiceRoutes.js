import express from 'express';
import { protect } from "../middleware/authMiddleware.js";
import { getInvoices } from '../controllers/invoiceController.js';

const router = express.Router();

router.use(protect);

router.get('/', getInvoices);

export default router;