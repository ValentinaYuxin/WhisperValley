import express from "express";
import { protect, authorize } from "../middleware/authMiddleware.js";
import {
    getDashboardStats,
    getUsers,
    deleteUser,
    getUserById,
    getUserSubscriptions,
    updateUser,
    getReports,
    updateReportStatus,
    getReportedItem,
    getPendingReportsCount,
    deleteReport,
    deletePostByAdmin,
    deleteCommentByAdmin,
    getContactMessages,
    deleteContactMessage,
    updateContactMessageStatus,
} from "../controllers/adminController.js";

const router = express.Router();

router.use(protect, authorize("admin"));

// dashboard stats
router.get("/dashboard-stats", getDashboardStats);

// user management
router.get("/users", getUsers);
router.route("/users/:id")
    .get(getUserById)
    .put(updateUser)
    .delete(deleteUser);
router.get("/users/:id/subscriptions", getUserSubscriptions)

// reports management
router.get("/reports", getReports);
router.get("/reports/pending-count", getPendingReportsCount);  // the order matters
router.put("/reports/:id/status", updateReportStatus);
router.get("/reports/:id", getReportedItem);
router.delete("/reports/:id", deleteReport);

router.delete("/posts/:id", deletePostByAdmin);
router.delete("/comments/:id", deleteCommentByAdmin);

// contact messages management
router.get("/contact-messages", getContactMessages);
router.delete("/contact-messages/:id", deleteContactMessage);
router.put("/contact-messages/:id/status", updateContactMessageStatus);

export default router;