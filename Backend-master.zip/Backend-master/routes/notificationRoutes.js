import express from 'express';
import { 
  getNotifications,
  getUnreadCount,
  markAllRead } from '../controllers/notificationController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// Apply authentication middleware to all routes in this router.
// This ensures only authenticated users can access the routes below.
router.use(protect);

// GET /notifications?page=1&limit=20
// Fetch paginated notifications for the authenticated user.
router.get('/', getNotifications);
router.get('/unread-count', getUnreadCount);
router.post('/mark-read', markAllRead);

export default router;