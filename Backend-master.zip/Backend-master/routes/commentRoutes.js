import express from 'express';
import {
  createComment,
  getCommentsForPost,
  getReplies,          
  updateComment,
  deleteComment,
  getCommentById
} from '../controllers/commentController.js';

import { toggleLikeComment } from '../controllers/likeController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// Create a comment under a post
router.post('/:postId', protect, createComment);

// Get all top-level comments for a post (no parentComment)
router.get('/post/:postId', protect, getCommentsForPost);

//  Get replies to a specific comment
router.get('/replies/:commentId', protect, getReplies);

// Update a comment by post and comment id
router.patch('/:postId/update/:commentId', protect, updateComment);

// Delete a comment by post and comment id
router.delete('/:postId/delete/:commentId', protect, deleteComment);

// Like and unlike a comment
router.route('/:commentId/like')
  .post(protect, toggleLikeComment);

// Get a single comment by its ID
router.get('/id/:commentId', protect, getCommentById);

export default router;
