import express from 'express';
import { submitFeedback, getAllFeedback } from '../controllers/contactController.js';

const router = express.Router();

router.post('/', submitFeedback);       // submit
router.get('/', getAllFeedback);        // only admin

export default router;
