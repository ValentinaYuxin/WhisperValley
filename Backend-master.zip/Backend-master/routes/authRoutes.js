import express from 'express';
import {
    register,
    login,
    getMe,
    logout,
    forgotPassword,
    resetPassword,
    updatePassword
} from '../controllers/authController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/register').post(register);
router.route('/login').post(login);
router.route('/forgotpassword').post(forgotPassword);
router.route('/resetpassword/:resettoken').put(resetPassword);

// private route and require authentication via protect middleware
router.route('/me').get(protect, getMe);
router.route('/updatepassword').put(protect, updatePassword);
router.route('/logout').get(protect, logout);

export default router;