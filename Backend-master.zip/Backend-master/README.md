# Whispering Valley Backend API Documentation

This document outlines the API endpoints for the Whispering Valley backend application. It serves as a comprehensive guide for frontend developers and other consumers of the API.

## Table of Contents

1.  [API Base URL](#2-api-base-url)
2.  [Authentication](#3-authentication)
3.  [Database Seeding](#4-database-seeding)
4.  [Error Handling](#5-error-handling)
5.  [API Endpoints](#6-api-endpoints)
6.  [Project Structure](#7-project-structure-optional)

---

## 1. API Base URL

The base URL for all API endpoints is:

`http://localhost:8080/api/v1` (for local development)

*Replace `localhost:8080` with the actual deployed API domain in production.*


## 2. Authentication

Authentication is handled using JSON Web Tokens (JWTs). Upon successful login or registration, a JWT is issued and stored as an **HTTP-only cookie** named `token`. This cookie will be automatically sent with subsequent requests to the API domain by browsers.

For direct API testing (e.g., with Postman/Insomnia) or when the cookie is not available (e.g., if consuming from a different subdomain/domain without proper CORS/credentials setup), you might include the token in the `Authorization` header as a **Bearer Token**:

`Authorization: Bearer <your_jwt_token>`


## 3. Database Seeding

To populate the database with test data:

```bash
npm run seed
```

This command will create sample users, posts, comments, and likes for testing and development purposes.

## 4. Error Handling

API errors are returned with appropriate HTTP status codes (e.g., 400, 401, 403, 404, 500) and a consistent JSON object containing a `success` flag and an `error` message.

## 5. API Endpoints

This section provides a concise overview of the available API endpoints. For detailed request/response examples and schemas, please refer to the [Postman Collection Documentation](link-to-your-postman-docs-here) or [Swagger/OpenAPI Documentation](link-to-your-swagger-docs-here) (if generated).

### 5.1. Auth Endpoints

These endpoints handle user authentication and password management.

* **`POST /api/v1/auth/register`**
    * **Description:** Register a new user account.
    * **Access:** Public
* **`POST /api/v1/auth/login`**
    * **Description:** Log in an existing user.
    * **Access:** Public
* **`GET /api/v1/auth/me`**
    * **Description:** Get details of the currently authenticated user.
    * **Access:** Authenticated
* **`GET /api/v1/auth/logout`**
  * **Description:** Log the user out by clearing the authentication cookie.
  * **Access:** Authenticated
* **`POST /api/v1/auth/forgotpassword`**
  * **Description:** Initiates the password reset process. Sends a password reset link (containing a unique token) to the user's registered email address.
  * **Access:** Public
* **`PUT /api/v1/auth/resetpassword/:resettoken`**
  * **Description:** Resets the user's password using a valid reset token received via email. Upon successful reset, the user is automatically logged in and a new authentication token is returned.
  * **Access:** Public
* **`PUT /api/v1/auth/updatepassword`**
  * **Description:** Allows an authenticated user to change their current password to a new one. Requires the user's current password for verification.
  * **Access:** Authenticated

### 5.2. User Endpoints

These endpoints provide operations for managing user accounts, often with admin privileges.

* **`GET /api/v1/users`**
  * **Description:** Retrieve a list of all user accounts.
  * **Access:** Admin
* **`GET /api/v1/users/:id`**
  * **Description:** Retrieve details of a specific user account by ID.
  * **Access:** Owner or Admin
* **`PUT /api/v1/users/:id`**
  * **Description:** Update details of a specific user account by ID.
  * **Access:** Owner or Admin
* **`DELETE /api/v1/users/:id`**
  * **Description:** Delete a specific user account by ID.
  * **Access:** Admin

### 5.3. User Profile Endpoints

These endpoints allow authenticated users to view their personal activities and specific data.

* **`GET /api/v1/profiles/posts`**
  * **Description:** Retrieve all posts created by the currently authenticated user.
  * **Access:** Authenticated
* **`GET /api/v1/profiles/comments`**
  * **Description:** Retrieve all comments made by the currently authenticated user.
  * **Access:** Authenticated
* **`GET /api/v1/profiles/liked-posts`**
  * **Description:** Retrieve all posts liked by the currently authenticated user.
  * **Access:** Authenticated

### 5.4. Subscription Endpoints

These endpoints manage user subscriptions.

* **`POST /api/v1/subscriptions/trial`**
  * **Description:** Initiate a 7-day free trial for a user on the `free` plan. Creates a Stripe Checkout session and returns a URL for the user to complete the process.
  * **Access:** Authenticated
* **`POST /api/v1/subscriptions/upgrade`**
  * **Description:** Upgrade a user directly from a `free` plan to a `premium` plan without a trial. Creates a Stripe Checkout session.
  * **Access:** Authenticated
* **`POST /api/v1/subscriptions/change-plan`**
  * **Description:** Change the billing cycle (e.g., from monthly to yearly) for an active `premium` subscription. This is not allowed for users on a `trialing` subscription.
  * **Access:** Authenticated
* **`POST /api/v1/subscriptions/cancel`**
  * **Description:** Schedule an `active` or `trialing` subscription to be canceled at the end of the current billing period. The subscription status will be set to `canceling`.
  * **Access:** Authenticated
* **`POST /api/v1/subscriptions/cancel-immediately`**
  * **Description:** Immediately cancel an `active` or `trialing` subscription. The user is reverted to a `free` plan.
  * **Access:** Authenticated
* **`GET /api/v1/subscriptions/current`**
  * **Description:** Retrieve the user's current subscription details (`active`, `trialing`, or `free`).
  * **Access:** Authenticated
* **`GET /api/v1/subscriptions/history`**
  * **Description:** Retrieve the user's entire subscription history.
  * **Access:** Authenticated
* **`GET /api/v1/subscriptions/:id`**
  * **Description:** Retrieve a specific subscription by its local database ID.
  * **Access:** Owner or Admin
    
### 5.5. Post Endpoints

These endpoints provide operations for managing user-generated posts or content.

* **`GET /api/v1/posts`**
  * **Description:** Fetches all posts, sorted by most recent first.
  * **Access:** Authenticated
* **`POST /api/v1/posts`**
  * **Description:** Create a new post for the authenticated user.
  * **Access:** Authenticated
* **`GET /api/v1/posts/me`**
  * **Description:** Get all posts belonging to the authenticated user.
  * **Access:** Authenticated
* **`GET /api/v1/posts/:id`**
  * **Description:** Get details of a single post by ID.
  * **Access:** Owner
* **`PUT /api/v1/posts/:id`**
  * **Description:** Update an existing post by ID.
  * **Access:** Owner
* **`DELETE /api/v1/posts/:id`**
  * **Description:** Delete a post by ID.
  * **Access:** Admin only

 ### 5.6. Comment Endpoints

These endpoints manage user subscriptions.

* **`POST /api/v1/comments/:postId`**
  * **Description:** Create a new comment on a specific post.
  * **Access:** Authenticated
* **`GET /api/v1/comments/post/:postId `**
  * **Description:** Get top-level comments for a post (i.e., comments that are not replies).
  * **Access:** Authenticated
* **`GET /api/v1/comments/replies/:commentId`**
  * **Description:** Get replies to a specific comment.
  * **Access:** Authenticated
* **`PUT /api/v1/comments/:commentId`**
  * **Description:** Update an existing comment.
  * **Access:** Owner
* **`DELETE /api/v1/comments/:commentId`**
  * **Description:** Delete a comment by ID.
  * **Access:** Owner or Admin

### 5.7. Premium Endpoints

These endpoints provide access to exclusive features requiring an active premium subscription.

* **`POST /api/v1/premium/journals`**
  * **Description:** Create a new journal entry for the authenticated user.
  * **Access:** Premium Subscription Required
* **`GET /api/v1/premium/journals`**
  * **Description:** Retrieve all journal entries belonging to the authenticated user.
  * **Access:** Premium Subscription Required


## 7. Project Structure

|                   | Description                                                    |
|-------------------|----------------------------------------------------------------|
| config/           | Database connection, environment config                        |
| models/           | Mongoose schemas/models                                        |
| controllers/      | Route handlers/business logic                                  |
| middleware/       | Custom Express middleware (e.g., auth, error handling)         |
| utils/            | Utility functions (e.g., asyncHandler, sendEmail)              |
| routes/           | API routes                                                     |
| Dockerfile        | Docker configuration for building the application image        |
| package.json      | Node.js project metadata and dependencies                      |
| package-lock.json | Records the exact dependency tree for consistent installations |
| index.js          | Main application entry point                                   |

