import dotenv from "dotenv";
dotenv.config();
/**
 * Central configuration file for Whispering Valley backend
 * Contains all environment variables and configuration settings
 */

const config = {
  // Server configuration
  PORT: process.env.PORT || 5000,
  NODE_ENV: process.env.NODE_ENV || "development",

  // MongoDB connection
  MONGODB_URI:
    process.env.MONGODB_URI || "mongodb://localhost:27017/whispering_valley",

  // JWT authentication
  JWT_SECRET:
    process.env.JWT_SECRET || "whispering-valley-secure-jwt-token-2025",
  JWT_EXPIRE: process.env.JWT_EXPIRE || "30d",

  // Cookie settings
  COOKIE_EXPIRE: process.env.COOKIE_EXPIRE || 30,

  // Frontend URL for CORS and redirects
  FRONTEND_URL: process.env.FRONTEND_URL || 'http://localhost:"3000"',

  // Email configuration for password reset and notifications
  SMTP_HOST: process.env.SMTP_HOST || "smtp.gmail.com",
  SMTP_PORT: process.env.SMTP_PORT || 587,
  SMTP_SERVICE: process.env.SMTP_SERVICE || "gmail",
  SMTP_MAIL: process.env.SMTP_MAIL || "whisperingvalley2025@gmail.com",
  SMTP_PASSWORD: process.env.SMTP_PASSWORD || "pqcm dgyd qlxk aznk",

  // Stripe payment configuration
  STRIPE_API_KEY:
    process.env.STRIPE_API_KEY ||
    "sk_test_51P4N5QJbW0hpBNbT6Af8sPJFnTNVXoUDrfRCRHmvqU8dCURuJbGtHiGbmK2HvAf9gYYiENIRgzWrBdFk1OaLRoDx00aKCO7Xj9",
  STRIPE_SECRET_KEY:
    process.env.STRIPE_SECRET_KEY ||
    "sk_test_51P4N5QJbW0hpBNbT6Af8sPJFnTNVXoUDrfRCRHmvqU8dCURuJbGtHiGbmK2HvAf9gYYiENIRgzWrBdFk1OaLRoDx00aKCO7Xj9",

  // Cloudinary configuration for image uploads
  CLOUDINARY_NAME: process.env.CLOUDINARY_NAME || "dryps40yo",
  CLOUDINARY_API_KEY: process.env.CLOUDINARY_API_KEY || "171968424845584",
  CLOUDINARY_API_SECRET:
    process.env.CLOUDINARY_API_SECRET || "fkzQPLn0qlnQlXsN7R8ZCPjS_es",

  // File upload settings
  MAX_FILE_SIZE: process.env.MAX_FILE_SIZE || 5 * 1024 * 1024, // 5MB
  UPLOAD_PATH: process.env.UPLOAD_PATH || "./uploads",

  // Pagination defaults
  DEFAULT_PAGE_SIZE: process.env.DEFAULT_PAGE_SIZE || 10,

  // Rate limiting
  RATE_LIMIT_WINDOW_MS: process.env.RATE_LIMIT_WINDOW_MS || 15 * 60 * 1000, // 15 minutes
  RATE_LIMIT_MAX: process.env.RATE_LIMIT_MAX || 100, // 100 requests per windowMs
  // Together AI key
  TOGETHER_API_KEY: process.env.TOGETHER_API_KEY || "",
  // Text2Emotion microservice endpoint
  T2E_SERVICE_URL:
    process.env.T2E_SERVICE_URL || "http://localhost:5001/analyze",
};

export default config;
export const {
  PORT,
  NODE_ENV,
  MONGODB_URI,
  JWT_SECRET,
  JWT_EXPIRE,
  COOKIE_EXPIRE,
  FRONTEND_URL,
  SMTP_HOST,
  SMTP_PORT,
  SMTP_SERVICE,
  SMTP_MAIL,
  SMTP_PASSWORD,
  STRIPE_API_KEY,
  STRIPE_SECRET_KEY,
  CLOUDINARY_NAME,
  CLOUDINARY_API_KEY,
  CLOUDINARY_API_SECRET,
  MAX_FILE_SIZE,
  UPLOAD_PATH,
  DEFAULT_PAGE_SIZE,
  RATE_LIMIT_WINDOW_MS,
  RATE_LIMIT_MAX,
  TOGETHER_API_KEY,
  T2E_SERVICE_URL,
} = config;
