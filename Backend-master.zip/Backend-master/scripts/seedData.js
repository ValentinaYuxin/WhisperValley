import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import Post from '../models/Post.js';
import Comment from '../models/Comment.js';
import Like from '../models/Like.js';
// Import config as default import
import config from '../config.js';

// Connect to database directly instead of using connectDB
const connectToDatabase = async () => {
  try {
    // Connect directly to the MongoDB container
    const mongoURI = 'mongodb://localhost:27017/whispering_valley';
    
    if (!mongoURI) {
      console.error('Error: MongoDB URI is not defined');
      process.exit(1);
    }

    await mongoose.connect(mongoURI);

    console.log(`MongoDB Connected: ${mongoose.connection.host}`);
  } catch (error) {
    console.error(`Error connecting to MongoDB: ${error.message}`);
    process.exit(1);
  }
};

// Sample user data
const users = [
  {
    username: 'JohnDoe',
    email: 'john.doe@mytum.de',
    password: 'password123',
    role: 'user',
    avatar: 'https://randomuser.me/api/portraits/men/1.jpg'
  },
  {
    username: 'JaneSmith',
    email: 'jane.smith@mytum.de',
    password: 'password123',
    role: 'user',
    avatar: 'https://randomuser.me/api/portraits/women/2.jpg'
  },
  {
    username: 'AdminUser',
    email: 'admin@mytum.de',
    password: 'admin123',
    role: 'admin',
    avatar: 'https://randomuser.me/api/portraits/men/3.jpg'
  }
];

// Sample post data - will be linked to users
const posts = [
  {
    title: 'My Journey with Anxiety',
    content: 'Today I want to share my personal journey with anxiety and how I\'ve been managing it. Over the past few years, I\'ve learned several coping mechanisms that have significantly improved my quality of life. Deep breathing exercises, regular physical activity, and mindfulness meditation have been game-changers for me. I\'d love to hear what works for others!',
    emoji: '😔',
    emotionLabel: 'Fear',
    tags: ['anxiety', 'mental health', 'self-care']
  },
  {
    title: 'Finding Peace in Difficult Times',
    content: 'Life can be challenging, but I\'ve found that maintaining a daily gratitude practice helps me stay centered when things get tough. Each morning, I write down three things I\'m grateful for, and it shifts my perspective for the entire day. This simple habit has transformed how I approach difficulties and has helped me find moments of peace even during stressful periods.',
    emoji: '😊',
    emotionLabel: 'Enjoyment',
    tags: ['gratitude', 'mindfulness', 'daily practice']
  },
  {
    title: 'Overcoming Imposter Syndrome',
    content: 'As a professional in my field, I often struggle with imposter syndrome. Those nagging thoughts that I don\'t deserve my achievements or that I\'m not qualified enough. Recently, I\'ve been working on challenging these negative thought patterns by documenting my accomplishments and seeking support from trusted friends. Has anyone else experienced this? How do you deal with it?',
    emoji: '💪',
    emotionLabel: 'Fear',
    tags: ['imposter syndrome', 'work', 'self-doubt']
  },
  {
    title: 'The Power of Connection',
    content: 'Human connection is vital for our mental wellbeing. In our increasingly digital world, I\'ve been making a conscious effort to nurture my real-world relationships. Weekly coffee dates with friends, phone calls instead of texts, and joining community groups have all enriched my life tremendously. I believe that meaningful connections are the antidote to the isolation many of us feel.',
    emoji: '😊',
    emotionLabel: 'Enjoyment',
    tags: ['connection', 'relationships', 'community']
  }
];

// Sample comments data - will be linked to posts and users
const comments = [
  {
    content: "I completely relate to your experience. Breathing exercises have been life-changing for me too!",
    parentComment: null // This is a top-level comment
  },
  {
    content: "Have you tried meditation apps? I've found Headspace particularly helpful for my anxiety.",
    parentComment: null
  },
  {
    content: "Thank you for sharing your story. It helps knowing others are going through similar struggles.",
    parentComment: null
  },
  {
    content: "I'd recommend adding journaling to your routine. It's helped me identify my anxiety triggers.",
    parentComment: null
  },
  {
    content: "This is great advice! I've been keeping a gratitude journal for 6 months now.",
    parentComment: null
  },
  {
    content: "Which meditation app would you recommend for beginners?",
    parentComment: 1 // This is a reply to the second comment (index 1)
  },
  {
    content: "Journaling has been so therapeutic for me as well! I write every night before bed.",
    parentComment: 3 // This is a reply to the fifth comment (index 3)
  },
  {
    content: "Imposter syndrome is so common in tech fields. You're definitely not alone!",
    parentComment: null
  },
  {
    content: "Community involvement has been key for my mental health too. Great post!",
    parentComment: null
  }
];

// Function to seed users
const seedUsers = async () => {
  try {
    // Clear existing users
    await User.deleteMany({});
    console.log('Deleted all existing users');

    // Create new users with plain passwords (pre-save hook will hash)
    const createdUsers = [];
    for (const user of users) {
      const newUser = await User.create({
        ...user
      });
      createdUsers.push(newUser);
      console.log(`Created user: ${newUser.username} (${newUser.email})`);
    }

    return createdUsers;
  } catch (error) {
    console.error('Error seeding users:', error);
    process.exit(1);
  }
};

// Function to seed posts
const seedPosts = async (users) => {
  try {
    // Clear existing posts
    await Post.deleteMany({});
    console.log('Deleted all existing posts');

    // Create new posts linked to users
    const createdPosts = [];
    
    // Distribute posts among users
    for (let i = 0; i < posts.length; i++) {
      const user = users[i % users.length]; // Cycle through users
      
      const newPost = await Post.create({
        ...posts[i],
        user: user._id,
        author: `Anonymous-${Math.random().toString(36).substring(2, 8)}`
      });
      
      createdPosts.push(newPost);
      console.log(`Created post: "${newPost.title}" by ${user.username}`);
    }

    return createdPosts;
  } catch (error) {
    console.error('Error seeding posts:', error);
    process.exit(1);
  }
};

// Function to seed comments
const seedComments = async (users, posts) => {
  try {
    // Clear existing comments
    await Comment.deleteMany({});
    console.log('Deleted all existing comments');

    // Create new comments linked to posts and users
    const createdComments = [];
    let commentIdMap = []; // To track created comment IDs for replies
    
    // First, create all top-level comments
    for (let i = 0; i < comments.length; i++) {
      // Skip comments that are replies for now
      if (comments[i].parentComment !== null) continue;
      
      const postIndex = i % posts.length; // Cycle through posts
      const userIndex = (i + 1) % users.length; // Cycle through users offset by 1 from post

      const newComment = await Comment.create({
        content: comments[i].content,
        post: posts[postIndex]._id,
        user: users[userIndex]._id,
        parentComment: null
      });
      
      commentIdMap[i] = newComment._id;
      createdComments.push(newComment);
      console.log(`Created comment on post: "${posts[postIndex].title}" by ${users[userIndex].username}`);
    }
    
    // Now create replies, using the saved IDs
    for (let i = 0; i < comments.length; i++) {
      // Only process comments that are replies
      if (comments[i].parentComment === null) continue;
      
      const parentCommentIndex = comments[i].parentComment;
      const parentCommentId = commentIdMap[parentCommentIndex];
      
      // Find the post ID by looking at the parent comment
      const parentComment = createdComments.find(c => c._id.equals(parentCommentId));
      const postId = parentComment.post;
      
      // Use a different user than the parent comment
      const userIndex = (i + 2) % users.length;
      
      const newReply = await Comment.create({
        content: comments[i].content,
        post: postId,
        user: users[userIndex]._id,
        parentComment: parentCommentId
      });
      
      createdComments.push(newReply);
      console.log(`Created reply to comment by ${users[userIndex].username}`);
    }

    return createdComments;
  } catch (error) {
    console.error('Error seeding comments:', error);
    process.exit(1);
  }
};

// Function to seed likes
const seedLikes = async (users, posts, comments) => {
  try {
    // Clear existing likes
    await Like.deleteMany({});
    console.log('Deleted all existing likes');

    const createdLikes = [];
    
    // Add likes to posts
    for (let i = 0; i < posts.length; i++) {
      // Each post gets likes from 1-3 random users
      const numLikes = Math.floor(Math.random() * 3) + 1;
      
      for (let j = 0; j < numLikes; j++) {
        // Make sure each user only likes a post once
        const userIndex = (i + j) % users.length;
        
        const newLike = await Like.create({
          user: users[userIndex]._id,
          targetType: 'Post',
          targetId: posts[i]._id
        });
        
        createdLikes.push(newLike);
        
        // Update the post's like count
        await Post.findByIdAndUpdate(posts[i]._id, { $inc: { likeCount: 1 } });
        
        console.log(`User ${users[userIndex].username} liked post "${posts[i].title}"`);
      }
    }
    
    // Add likes to comments
    for (let i = 0; i < comments.length; i++) {
      // Each comment gets 0-2 random likes
      const numLikes = Math.floor(Math.random() * 3);
      
      for (let j = 0; j < numLikes; j++) {
        // Make sure each user only likes a comment once
        const userIndex = (i + j + 1) % users.length;
        
        const newLike = await Like.create({
          user: users[userIndex]._id,
          targetType: 'Comment',
          targetId: comments[i]._id
        });
        
        createdLikes.push(newLike);
        
        // Update the comment's like count
        await Comment.findByIdAndUpdate(comments[i]._id, { $inc: { likeCount: 1 } });
        
        console.log(`User ${users[userIndex].username} liked a comment`);
      }
    }

    return createdLikes;
  } catch (error) {
    console.error('Error seeding likes:', error);
    process.exit(1);
  }
};

// Function to simulate user login
const simulateLogin = async (email, password) => {
  try {
    // Find user and explicitly select the password field
    const user = await User.findOne({ email }).select('+password');
    
    if (!user) {
      console.log(`Login failed: User with email ${email} not found`);
      return null;
    }
    
    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    
    if (!isMatch) {
      console.log(`Login failed: Incorrect password for ${email}`);
      return null;
    }
    
    console.log(`Login successful: ${user.username} (${user.email})`);
    return user;
  } catch (error) {
    console.error('Error simulating login:', error);
    return null;
  }
};

// Main function to run the seeding process
const seedDatabase = async () => {
  try {
    console.log('Starting database seeding...');
    
    // Connect to the database
    await connectToDatabase();
    
    // Seed users
    const seededUsers = await seedUsers();
    
    // Simulate login for each user
    for (const user of users) {
      await simulateLogin(user.email, user.password);
    }
    
    // Seed posts
    const seededPosts = await seedPosts(seededUsers);
    
    // Seed comments
    const seededComments = await seedComments(seededUsers, seededPosts);
    
    // Seed likes
    const seededLikes = await seedLikes(seededUsers, seededPosts, seededComments);
    
    console.log('Database seeding completed successfully!');
    console.log(`Created ${seededUsers.length} users, ${seededPosts.length} posts, ${seededComments.length} comments, and ${seededLikes.length} likes`);
    
    // Close the database connection
    mongoose.connection.close();
    
  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    process.exit();
  }
};

// Run the seeding process
seedDatabase();
