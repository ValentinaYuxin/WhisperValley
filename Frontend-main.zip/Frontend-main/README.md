# Whispering Valley Frontend Documentation

This document provides a comprehensive overview of the Whispering Valley frontend application. It is intended for developers and contributors working on the user interface of the platform.

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Features](#2-features)
3. [Project Structure](#3-project-structure)
4. [Getting Started](#4-getting-started)
5. [Available Scripts](#5-available-scripts)
6. [Customization & Theming](#6-customization--theming)
7. [Key Components](#7-key-components)
8. [Routing](#8-routing)
9. [Assets](#9-assets)
10. [Contributing](#10-contributing)
11. [License](#11-license)

---

## 1. Project Overview

Whispering Valley Frontend is a modern, responsive web application for Whispering Valley—a safe, supportive, and anonymous community for students in Munich to share, reflect, and grow. Built with React, Vite, and Material UI, it delivers a beautiful user experience with features for journaling, forums, emotional tracking, and more.

---

## 2. Features

- **Anonymous Forum:** Share experiences, comment, and support others in a safe space.
- **Emotion Journaling:** Record and track your feelings with privacy and insight.
- **Mood Tracking:** Visualize emotional trends and patterns over time.
- **Personalized Feedback:** Receive thoughtful, AI-powered reflections.
- **Subscription Plans:** Free and Premium tiers with additional features for subscribers.
- **Responsive Design:** Optimized for all devices.
- **Modern UI:** Custom Material UI theme for a unique, calming look.

---

## 3. Project Structure

```
├── public/                # Static assets (backgrounds, logo, etc.)
├── src/
│   ├── assets/            # Image assets for features
│   ├── components/        # Reusable UI components
│   │   ├── forum/         # Forum-related components (Post, Comment, etc.)
│   ├── context/           # React context providers (state management)
│   ├── pages/             # Top-level pages (Home, SignIn, CreatePost, etc.)
│   ├── routes/            # App routing
│   ├── shared-theme/      # Custom Material UI theme and overrides
│   │   ├── customizations # Theme customizations (inputs, data display, etc.)
│   ├── menuItems.js       # Navigation menu structure
│   ├── App.jsx            # Main app entry
│   ├── main.jsx           # App bootstrap
│   └── index.css          # Global styles
├── Dockerfile             # For containerization
├── vite.config.js         # Vite configuration
├── package.json           # Project metadata and scripts
└── README.md              # This file
```

---

## 4. Getting Started

### Prerequisites
- [Node.js](https://nodejs.org/) (v16+ recommended)
- [npm](https://www.npmjs.com/) or [yarn](https://yarnpkg.com/)

## 5. Available Scripts

- `npm run dev` — Start the development server
- `npm run build` — Build for production
- `npm run preview` — Preview the production build
- `npm run lint` — Lint the codebase

---

## 6. Customization & Theming

- Uses **Material UI v6** with a custom theme (`src/shared-theme/`).
- Theme customizations for buttons, chips, inputs, and more in `customizations/`.
- Easily switch between light and dark modes.
- Typography and color palette defined in `themePrimitives.jsx`.

---

## 7. Key Components

- **Header & Footer:** Consistent navigation and branding.
- **Hero:** Landing section with a welcoming message.
- **Overview:** Introduction to the platform's purpose and features.
- **Features:** Highlights core functionalities.
- **Pricing:** Subscription plans with clear feature breakdown.
- **FAQ:** Frequently asked questions.
- **Contact:** Contact form for user inquiries.
- **Forum Components:**
  - `PostForm`, `PostCard`, `CommentList`, `AddCommentForm`, `EmojiSelector`, etc.
- **Pages:**
  - `HomePage.jsx`: Main landing and marketing page.
  - `CreatePost.jsx`: Page to create a new forum post.
  - `PostOverview.jsx`: View a post and its comments.
  - `SignIn.jsx`, `SignUp.jsx`: Authentication pages.

---

## 8. Routing

- Uses **React Router** for client-side navigation.
- Main routes defined in `src/pages/HomePage.jsx` and `src/routes/index.jsx`.
- Nested routes for forum, authentication, and marketing pages.

---

## 9. Assets

- All images and static files are in `public/` and `src/assets/`.
- Backgrounds, logos, and feature icons are used throughout the UI.

---

