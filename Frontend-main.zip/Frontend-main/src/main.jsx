import React from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { store, persistor } from "./store";
import { PersistGate } from "redux-persist/integration/react";
import axios from "axios";
import { logout } from "./store/slices/userSlice.js";

import "bootstrap/dist/css/bootstrap.css";
import "./index.css";

import { BrowserRouter } from "react-router-dom";

import App from "./App.jsx";

axios.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      const errMsg = error.response.data?.error?.toLowerCase() || "";
      if (errMsg.includes("token") || errMsg.includes("jwt")) {
        store.dispatch(logout());
        window.location.href = "/signin";
      }
    }
    // Prevent redirect for 403 errors
    if (error.response && error.response.status === 403) {
      console.error(
        "Forbidden access: You don't have permission to view this resource."
      );
    }
    return Promise.reject(error);
  }
);

const container = document.getElementById("root");
const root = createRoot(container);

root.render(
  <React.StrictMode>
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </PersistGate>
    </Provider>
  </React.StrictMode>
);
