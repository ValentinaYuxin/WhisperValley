import { useSelector, useDispatch } from 'react-redux';
import { useCallback, useState } from 'react';
import { 
  fetchPosts,
  fetchPostById,
  createPost as apiCreatePost,
  fetchComments,
  createComment as createCommentThunk,
  fetchAllTags,
  likePost,
  setSearchQuery,
  setSelectedTags,
  setCurrentPage,
  resetForumState,
  clearCurrentPost,
  updatePost as updatePostThunk,
  deletePost as deletePostThunk,
  updateComment as updateCommentThunk,
  deleteComment as deleteCommentThunk,
  reportContent
} from '../store/slices/forumSlice';

export const useForum = () => {
  const dispatch = useDispatch();
  const [period, setPeriod] = useState('3d');
  const [customRange, setCustomRange] = useState({ start: '', end: '' });
  const [selectedEmotion, setSelectedEmotion] = useState(null);
  const {
    posts,
    currentPost,
    comments,
    repliesByCommentId,
    allTags,
    totalPages,
    totalItems,
    currentPage,
    itemsPerPage,
    searchQuery,
    selectedTags,
    status,
    error
  } = useSelector(state => state.forum);

  const isLoading = status === 'loading';

  // Pagination handler for posts
  const handlePageChange = useCallback((event, value) => {
    dispatch(setCurrentPage(value));
    dispatch(fetchPosts({ page: value, searchQuery, selectedTags }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [dispatch, searchQuery, selectedTags]);

  // Search handler
  const handleSearch = useCallback((event) => {
    event.preventDefault();
    dispatch(setCurrentPage(1));
    dispatch(fetchPosts({ page: 1, searchQuery, tags: selectedTags || [] }));
  }, [dispatch, searchQuery, selectedTags]);

  // Tag selection handler for multi-tag
  const handleTagSelect = useCallback((tag) => {
    let newTags;
    if ((selectedTags || []).includes(tag)) {
      newTags = selectedTags.filter(t => t !== tag);
    } else {
      newTags = [...(selectedTags || []), tag];
    }
    dispatch(setSelectedTags(newTags));
    dispatch(setCurrentPage(1));
    dispatch(fetchPosts({ page: 1, searchQuery, tags: newTags }));
  }, [dispatch, searchQuery, selectedTags]);

  // --- Centralized CRUD handlers ---
  const createPost = useCallback(async (postData) => {
    try {
      const result = await dispatch(apiCreatePost(postData)).unwrap();
      return { success: true, data: result };
    } catch (error) {
      return { success: false, error: error?.message || 'Failed to create post' };
    }
  }, [dispatch]);

  const updatePost = useCallback(async ({ postId, postData }) => {
    try {
      const result = await dispatch(updatePostThunk({ postId, postData })).unwrap();
      return { success: true, data: result };
    } catch (error) {
      return { success: false, error: error?.message || 'Failed to update post' };
    }
  }, [dispatch]);

  const deletePost = useCallback(async (postId) => {
    try {
      await dispatch(deletePostThunk(postId)).unwrap();
      return { success: true };
    } catch (error) {
      return { success: false, error: error?.message || 'Failed to delete post' };
    }
  }, [dispatch]);

  const createComment = useCallback(async ({ postId, content, parentComment = null }) => {
    try {
      const result = await dispatch(createCommentThunk({ postId, content, parentComment })).unwrap();
      return { success: true, data: result };
    } catch (error) {
      return { success: false, error: error?.message || 'Failed to add comment' };
    }
  }, [dispatch]);

  const updateComment = useCallback(async ({ postId, commentId, content }) => {
    try {
      const result = await dispatch(updateCommentThunk({ postId, commentId, content })).unwrap();
      return { success: true, data: result };
    } catch (error) {
      return { success: false, error: error?.message || 'Failed to update comment' };
    }
  }, [dispatch]);

  const deleteComment = useCallback(async ({ postId, commentId }) => {
    try {
      await dispatch(deleteCommentThunk({ postId, commentId })).unwrap();
      return { success: true };
    } catch (error) {
      return { success: false, error: error?.message || 'Failed to delete comment' };
    }
  }, [dispatch]);

  // --- Report content handler ---
  const report = useCallback(async ({ targetType, targetId, reason }) => {
    try {
      const result = await dispatch(reportContent({ targetType, targetId, reason })).unwrap();
      return { success: true, data: result };
    } catch (error) {
      return { success: false, error: error?.message || 'Failed to report content' };
    }
  }, [dispatch]);

  // Reset filters
  const resetFilters = useCallback(() => {
    dispatch(setSearchQuery(""));
    setPeriod("3d");
    setCustomRange({ start: '', end: '' });
    dispatch(setSelectedTags([]));
    dispatch(setCurrentPage(1));
    dispatch(fetchPosts({ page: 1 }));
  }, [dispatch]);

  return {
    posts,
    currentPost,
    comments,
    repliesByCommentId,
    allTags,
    totalPages,
    totalItems,
    currentPage,
    itemsPerPage,
    searchQuery,
    selectedTags,
    isLoading,
    error,
    period,
    setPeriod,
    customRange,
    setCustomRange,
    selectedEmotion,
    setSelectedEmotion,
    fetchPosts: useCallback((params) => dispatch(fetchPosts(params)), [dispatch]),
    fetchPostById: useCallback((id) => dispatch(fetchPostById(id)), [dispatch]),
    fetchComments: useCallback((postId, paginationParams = {}) => {
      const params = {
        postId: String(postId),
        page: paginationParams.page || 1,
        limit: paginationParams.limit || 10
      };
      return dispatch(fetchComments(params));
    }, [dispatch]),
    fetchAllTags: useCallback(() => dispatch(fetchAllTags()), [dispatch]),
    likePost: useCallback((postId) => dispatch(likePost(postId)), [dispatch]),
    createPost,
    updatePost,
    deletePost,
    createComment,
    updateComment,
    deleteComment,
    report, // Add report handler to hook return
    handlePageChange,
    handleSearch,
    handleTagSelect,
    setSearchQuery: useCallback((query) => dispatch(setSearchQuery(query)), [dispatch]),
    resetForumState: useCallback(() => dispatch(resetForumState()), [dispatch]),
    clearCurrentPost: useCallback(() => dispatch(clearCurrentPost()), [dispatch]),
    resetFilters,
  };
};
