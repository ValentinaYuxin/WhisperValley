import { useDispatch, useSelector } from 'react-redux';
import { useCallback, useMemo } from "react";
import {
    fetchCurrent,
    fetchHistory,
    fetchById,
    fetchInvoices,
    startTrial,
    upgrade,
    cancelSubscription,
    cancelImmediately,
    changePlan,
    clearCheckoutUrl,
    clearError,
} from "../store/slices/subSlice";

export function useSubscription() {
    const dispatch = useDispatch();
    const { current, history, details, invoices, checkoutUrl, loading, error } =
        useSelector(s => s.subscription);

    const hasHadTrialOrPremium = useMemo(() => {
        return history.some(sub => sub.plan === 'premium' || sub.status === 'trialing');
    }, [history]);

    return {
        // returned state
        current,
        history,
        details,
        invoices,
        checkoutUrl,
        loading,
        error,
        hasHadTrialOrPremium,

        // returned actions
        fetchCurrent:      useCallback(() => dispatch(fetchCurrent()), [dispatch]),
        fetchHistory:      useCallback(() => dispatch(fetchHistory()), [dispatch]),
        fetchById:         useCallback(id => dispatch(fetchById(id)), [dispatch]),
        fetchInvoices:     useCallback(() => dispatch(fetchInvoices()), [dispatch]),
        startTrial:        useCallback(() => dispatch(startTrial()), [dispatch]),
        upgrade:           useCallback(cycle => dispatch(upgrade({ billingCycle: cycle })), [dispatch]),
        cancelSubscription: useCallback(() => dispatch(cancelSubscription()), [dispatch]),
        cancelImmediately: useCallback(() => dispatch(cancelImmediately()), [dispatch]),
        changePlan:        useCallback((id, price) => dispatch(changePlan({ subId: id, newPriceId: price })), [dispatch]),
        clearCheckoutUrl:  useCallback(() => dispatch(clearCheckoutUrl()), [dispatch]),
        clearError:        useCallback(() => dispatch(clearError()), [dispatch]),
    };
}