import { useDispatch, useSelector } from 'react-redux';
import { useCallback } from 'react';
import {
  fetchUnreadCount,
  fetchUnreadCountByType,
  fetchNotifications,
  markAllRead,
  clearNotifications,
  clearUnreadCountByType
} from '../store/slices/notificationsSlice';

export function useNotifications() {
  const dispatch = useDispatch();
  const notificationsState = useSelector((state) => state.notifications);

  return {
    ...notificationsState,
    fetchUnreadCount: useCallback(() => dispatch(fetchUnreadCount()), [dispatch]),
    fetchUnreadCountByType: useCallback(() => dispatch(fetchUnreadCountByType()), [dispatch]),
    fetchNotifications: useCallback((params) => dispatch(fetchNotifications(params)), [dispatch]),
    markAllRead: useCallback((type) => dispatch(markAllRead(type)), [dispatch]),
    clearNotifications: useCallback(() => dispatch(clearNotifications()), [dispatch]),
    clearUnreadCountByType: useCallback((type) => dispatch(clearUnreadCountByType(type)), [dispatch]),
  };
} 