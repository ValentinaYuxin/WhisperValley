import { useDispatch, useSelector } from "react-redux";
import { useCallback } from "react";
import {
  loginUser,
  registerUser, 
  logout,
  clearError,
  resetLoginState,
  fetchUserInfo,
  setUser,
} from "../store/slices/userSlice";


export const useUser = () => {
  const dispatch = useDispatch();
  const { user, tokenData, loading, error } = useSelector((state) => state.user);

  const login = useCallback(
    (credentials) => dispatch(loginUser(credentials)),
    [dispatch]
  );

  const register = useCallback(
    (credentials) => dispatch(registerUser(credentials)), 
    [dispatch]
  );

  const logoutUser = useCallback(() => {
    dispatch(logout());
  }, [dispatch]);

  const clearUserError = useCallback(() => {
    dispatch(clearError());
  }, [dispatch]);

  const resetUserState = useCallback(() => {
    dispatch(resetLoginState());
  }, [dispatch]);

  const refreshUser = useCallback(async () => {
    if (tokenData?.token && tokenData?.id) {
      console.log("Calling fetchUserInfo with tokenData:", tokenData);
      await dispatch(fetchUserInfo({ token: tokenData.token, id: tokenData.id }));
    } else {
      dispatch(setUser(null));
      console.warn("No tokenData available when refreshing user.");
    }
  }, [dispatch, tokenData]);


  return {
    user,
    tokenData,
    loading,
    error,
    login,
    register,       
    logout: logoutUser,
    clearError: clearUserError,
    resetUserState,
    refreshUser,
  };
};


