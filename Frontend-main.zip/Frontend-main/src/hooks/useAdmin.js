import { useDispatch, useSelector } from 'react-redux';
import { useCallback } from 'react';
import {
    fetchDashboardStats,
    fetchUsers,
    deleteUser,
    fetchUserById,
    clearUser,
    fetchUserSubscriptions,
    updateUser,
    fetchReports,
    updateReportStatus,
    getReportedItem,
    clearReportedItem,
    fetchPendingReportsCount,
    deleteReport,
    deletePostByAdmin,
    deleteCommentByAdmin,
    clearError,
    fetchContactMessages,
    deleteContactMessage,
    updateContactMessageStatus,
} from "../store/slices/adminSlice.js";

export function useAdmin() {
    const dispatch = useDispatch();
    const {
        stats, users, totalUsers, user, userSubscriptions,
        reports, totalReports, reportedItem, pendingReportsCount,
        contactMessages, totalMessages,
        loading, error
    } = useSelector((state) => state.admin);

    const fetchStats = useCallback(() => {
        dispatch(fetchDashboardStats());
    }, [dispatch]);

    const formatError = (err) => {
        if (typeof err === 'string') {
            return err;
        }
        if (err && typeof err === 'object') {
            if (err.message) return err.message;
            if (err.error) return err.error;
            // If it's an object but no specific message, stringify it
            return JSON.stringify(err);
        }
        return 'An unknown error occurred.';
    };

    return {
        stats,
        users,
        totalUsers,
        user,
        userSubscriptions,
        reports,
        totalReports,
        reportedItem,
        pendingReportsCount,
        contactMessages,
        totalMessages,
        loading,
        error: error ? formatError(error) : null,

        fetchDashboardStats: useCallback(() => dispatch( fetchDashboardStats() ), [dispatch]),

        fetchUsers: useCallback((params) => dispatch( fetchUsers(params) ), [dispatch]),
        deleteUser: useCallback((userId) => dispatch(deleteUser(userId)), [dispatch]),
        fetchUserById: useCallback((userId) => dispatch(fetchUserById(userId)), [dispatch]),
        clearUser: useCallback(() => dispatch(clearUser()), [dispatch]),
        fetchUserSubscriptions: useCallback((userId) => dispatch(fetchUserSubscriptions(userId)), [dispatch]),
        updateUser: useCallback((userId, userData) => dispatch(updateUser({ userId, userData })), [dispatch]),

        fetchReports: useCallback((params) => dispatch( fetchReports(params) ), [dispatch]),
        updateReportStatus: useCallback((reportId, status) => dispatch(updateReportStatus({ reportId, status })), [dispatch]),
        getReportedItem: useCallback((reportId) => dispatch( getReportedItem(reportId) ), [dispatch]),
        clearReportedItem: useCallback(() => dispatch(clearReportedItem()), [dispatch]),
        fetchPendingReportsCount: useCallback(() => dispatch( fetchPendingReportsCount() ), [dispatch]),
        deleteReport: useCallback((reportId) => dispatch(deleteReport(reportId)), [dispatch]),
        deletePostByAdmin: useCallback((postId) => dispatch(deletePostByAdmin(postId)), [dispatch]),
        deleteCommentByAdmin: useCallback((commentId) => dispatch(deleteCommentByAdmin(commentId)), [dispatch]),
        clearError: useCallback(() => dispatch(clearError()), [dispatch]),

        fetchContactMessages: useCallback((params) => dispatch( fetchContactMessages(params) ), [dispatch]),
        deleteContactMessage: useCallback((messageId) => dispatch(deleteContactMessage(messageId)), [dispatch]),
        updateContactMessageStatus: useCallback((messageId, status) => dispatch(updateContactMessageStatus({ messageId, status })), [dispatch]),

    };
}