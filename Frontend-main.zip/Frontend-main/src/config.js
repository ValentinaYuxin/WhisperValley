/**
 * Application configuration
 */

// API URL - change this based on environment
export const API_URL = process.env.NODE_ENV === 'production' 
  ? 'https://api.whisperingvalley.com/api/v1'  // Replace with your production API URL
  : 'http://localhost:8080/api/v1';

// Default pagination settings
export const DEFAULT_PAGE_SIZE = 10;

// Forum settings
export const MAX_POST_TITLE_LENGTH = 100;
export const MAX_POST_CONTENT_LENGTH = 5000;
export const MAX_COMMENT_LENGTH = 1000;

// Authentication related settings
export const TOKEN_STORAGE_KEY = 'token';
export const USER_STORAGE_KEY = 'user';

// Image upload limits
export const MAX_IMAGE_SIZE_MB = 5;
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];