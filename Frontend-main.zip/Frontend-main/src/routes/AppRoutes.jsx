import { Route, Navigate } from "react-router-dom";
import SignIn from "../pages/SignIn.jsx";
import SignUp from "../pages/SignUp.jsx";
import ResetPassword from "../pages/ResetPassword.jsx";
import Pricing from "../components/Pricing.jsx";
import Contact from "../pages/Contact.jsx";
import JournalCreatePage from "../pages/JournalCreatePage.jsx";
import Profile from "../pages/Profile.jsx";
import Forum from "../pages/Forum.jsx";
import CreatePost from "../pages/CreatePost.jsx";
import PostOverview from "../pages/PostOverview.jsx";
import MyPostsPage from "../components/Profile/Dashboard/MyPosts.jsx";
import NotificationPage from "../pages/Notification.jsx";
import Engagement from "../pages/Engagement.jsx";
import DashboardPage from "../pages/DashboardPage.jsx";
import AdminRoutes from "./AdminRoutes.jsx";
import JournalOverview from "../pages/JournalOverview.jsx";
import JournalDetailPage from "../pages/JournalDetailPage.jsx";

const AppRoutes = [
  <Route key="signin" path="/signin" element={<SignIn />} />,
  <Route key="signup" path="/signup" element={<SignUp />} />,
  <Route
    key="reset"
    path="/resetpassword/:resettoken"
    element={<ResetPassword />}
  />,
  <Route key="pricing" path="/pricing" element={<Pricing />} />,
  <Route key="contact" path="/contact" element={<Contact />} />,
  <Route
    key="journaloverview"
    path="/journals"
    element={<JournalOverview />}
  />,
  <Route
    key="journaldetail"
    path="/journals/:id"
    element={<JournalDetailPage />}
  />,

  <Route
    key="dailyjournal"
    path="/dailyjournal"
    element={<JournalCreatePage />}
  />,
  <Route key="profile" path="/profile" element={<Profile />} />,
  <Route key="forum" path="/forum" element={<Forum />} />,
  <Route key="createpost" path="/forum/newPost" element={<CreatePost />} />,
  <Route
    key="postoverview"
    path="/forum/posts/:id"
    element={<PostOverview />}
  />,
  <Route key="myposts" path="/myposts" element={<MyPostsPage />} />,
  <Route
    key="notification"
    path="/notification"
    element={<NotificationPage />}
  />,
  <Route
    key="received-comments"
    path="/received-comments"
    element={<Navigate to="/notification?tab=Received Comments" replace />}
  />,
  <Route
    key="received-likes"
    path="/received-likes"
    element={<Navigate to="/notification?tab=Received Likes" replace />}
  />,
  <Route key="engagement" path="/myengagements" element={<Engagement />} />,
  <Route
    key="mycomments"
    path="/mycomments"
    element={<Navigate to="/myengagements?tab=My Comments" replace />}
  />,
  <Route
    key="mylikes"
    path="/mylikes"
    element={<Navigate to="/myengagements?tab=My Likes" replace />}
  />,
  <Route key="dashboard" path="/dashboard" element={<DashboardPage />} />,
  <Route key="admin-routes" path="/admin/*" element={<AdminRoutes />} />,
];

export default AppRoutes;
