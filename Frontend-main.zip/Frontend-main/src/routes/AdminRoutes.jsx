import React from "react";
import { Navigate, Routes, Route } from "react-router-dom";
import { useUser } from "../hooks/useRedux.js";
import AdminLayout from "../components/Admin/AdminLayout.jsx";
import { Box, CircularProgress } from "@mui/material";

import DashboardPage from "../pages/Admin/DashboardPage.jsx";
import UsersPage from "../pages/Admin/UsersPage.jsx";
import UserDetailPage from "../pages/Admin/UserDetailPage.jsx";
import ReportsPage from "../pages/Admin/ReportsPage.jsx";
import ContactMessagesPage from "../pages/Admin/ContactMessagesPage.jsx";

const AdminRoutes = () => {
    const { user, loading } = useUser();

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress />
            </Box>
        );
    }

    return user && user.role === 'admin' ? (
        <Routes>
            <Route path="/" element={<AdminLayout />}>
                <Route index element={<Navigate to='dashboard' replace />} />

                <Route path='dashboard' element={<DashboardPage />} />
                <Route path="users" element={<UsersPage />} />
                <Route path="users/:userId" element={<UserDetailPage />} />
                <Route path="reports" element={<ReportsPage />} />
                <Route path="contact-messages" element={<ContactMessagesPage />} />

            </Route>
        </Routes>
    ) : (
        <Navigate to="/signin" replace />
    );
};

export default AdminRoutes;
