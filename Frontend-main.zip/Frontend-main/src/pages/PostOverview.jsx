import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link, useLocation } from "react-router-dom";
import {
  Box,
  Button,
  Container,
  Typography,
  Paper,
  Divider,
  Chip,
  Avatar,
  Stack,
  IconButton,
  Alert,
  Pagination,
  CircularProgress,
} from "@mui/material";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import ThumbUpOutlinedIcon from "@mui/icons-material/ThumbUpOutlined";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Header from "../components/Header";
import { useForum } from "../hooks/useForum";
import { useUser } from "../hooks/useRedux";
import { formatDate } from "../utils/formatDate";
// Import forum components
import Comment from "../components/forum/Comment";
import InputComment from "../components/forum/InputComment";
import ForumBackground from "../components/forum/ForumBackground";
import ThreeDotMenu from "../components/forum/ThreeDotMenu";
import { useDispatch, useSelector } from "react-redux";
import ReportModal from "../components/forum/ReportModal";
import Dialog from '@mui/material/Dialog';
import TextField from '@mui/material/TextField';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { useNotifications } from "../hooks/useNotifications";

const PostOverview = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  // Use Redux state for authentication
  const token = useSelector((state) => state.user.tokenData?.token);
  const isAuthenticated = !!token;

  // Admin check
  const location = useLocation();
  const fromAdminReports = location.state?.fromAdminReports;

  // Redirect to sign in if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/signin', { replace: true });
    }
  }, [isAuthenticated, navigate]);
  const { fetchNotifications } = useNotifications();
  const [newComment, setNewComment] = useState("");
  const [commentPage, setCommentPage] = useState(1);
  const commentsPerPage = 10;
  
  const { currentUser } = useUser();
  const { 
    currentPost, 
    comments, 
    isLoading, 
    error, 
    fetchPostById, 
    fetchComments, 
    createComment,
    updatePost,
    deletePost,
    updateComment,
    deleteComment,
    likePost,
    report,
    clearCurrentPost 
  } = useForum();
  
  // State for post menu
  const [postMenuAnchor, setPostMenuAnchor] = useState(null);
  // State for update modal (optional, for post/comment update)
  const [updateModalOpen, setUpdateModalOpen] = useState(false);
  const [updateTarget, setUpdateTarget] = useState(null); // { type: 'post'|'comment', data: }

  // Content state for updates
  const [updateContent, setUpdateContent] = useState("");

  // Snackbar for comment success
  const [commentSuccess, setCommentSuccess] = useState(false);

  // Report modal states
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState(null); // { type: 'post'|'comment', id: string }
  const [reportReason, setReportReason] = useState('');
  const [reportSuccess, setReportSuccess] = useState(false);
  const [reportError, setReportError] = useState(null);

  // Determine if current user is post owner
  const isPostOwner = currentPost?.isOwner;

  // Access forum state for comment creation feedback
  const forumState = useSelector(state => state.forum);
  const isCreatingComment = forumState.isCreatingComment;
  const commentError = forumState.error && forumState.isCreatingComment ? forumState.error : null;

  // Fetch post details and comments with pagination
  useEffect(() => {
    if (id) {
      console.log('Fetching post with ID:', id);
      fetchPostById(id);
      // Fetch first page of comments with pagination
      fetchComments(id, { page: commentPage, limit: commentsPerPage });
    }
    
    // Clean up when unmounting
    return () => {
      clearCurrentPost();
    };
  }, [id, fetchPostById, fetchComments, clearCurrentPost, commentPage, commentsPerPage]);

  // Debug logging
  useEffect(() => {
    console.log('Current post state:', currentPost);
  }, [currentPost]);

  useEffect(() => {
    console.log('Comments state:', comments);
  }, [comments]);
  
  const handleSubmitComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim() || isCreatingComment) {
      return;
    }
    try {
      const result = await createComment({
        postId: String(id),
        content: newComment.trim()
      });
      if (result.success) {
        setNewComment('');
        setCommentSuccess(true);
        fetchComments(id, { page: commentPage, limit: commentsPerPage });
      } else {
        throw new Error(result.error);
      }
    } catch (err) {
      console.error('Error submitting comment:', err);
      if (err.message?.includes('sign') || err.message?.includes('auth')) {
        navigate('/signin', { state: { from: `/forum/posts/${id}` } });
      }
    }
  };
  
  const handleLikePost = async () => {
    try {
      await likePost(id);
      await fetchPostById(id); // Refresh post data
      fetchNotifications({ page: 1, limit: 10, type: "like" });
    } catch (err) {
      console.error('Error liking post:', err);
      // If there's an auth error, then handle the redirect
      if (err.response && err.response.status === 401) {
        navigate('/signin', { state: { from: `/forum/posts/${id}` } });
      }
    }
  };
  
  const handleCommentPageChange = (event, value) => {
    setCommentPage(value);
    // Fetch comments for the specific page:
    fetchComments(id, { page: value, limit: commentsPerPage });
    // Scroll to comments section
    document.getElementById('comments-section')?.scrollIntoView({ behavior: 'smooth' });
  };
  
  // Calculate total comment pages
  const totalCommentPages = comments?.length 
    ? Math.ceil(comments.length / commentsPerPage) 
    : 1;
  
  // Group comments by parentComment to support nested replies
  const repliesByCommentId = React.useMemo(() => {
    const map = {};
    if (comments && comments.length) {
      comments.forEach(comment => {
        if (comment.parentComment) {
          if (!map[comment.parentComment]) map[comment.parentComment] = [];
          map[comment.parentComment].push(comment);
        }
      });
    }
    return map;
  }, [comments]);

  // Only top-level comments (no parentComment)
  const topLevelComments = comments?.filter(c => !c.parentComment) || [];

  // Paginate only top-level comments for display
  const paginatedTopLevel = topLevelComments.length
    ? topLevelComments.slice(
        (commentPage - 1) * commentsPerPage,
        commentPage * commentsPerPage
      )
    : [];
  // Handler for submitting a reply to a comment
  const handleReplySubmit = async (parentCommentId, content) => {
    if (!content.trim()) return;
    const result = await createComment({
      postId: String(id),
      content: content.trim(),
      parentComment: parentCommentId
    });
    if (result.success) {
      // Refetch comments for the current page so the reply appears instantly
      fetchComments(id, { page: commentPage, limit: commentsPerPage });
      // Optionally, scroll to the comment section to show the new reply
      setTimeout(() => {
        document.getElementById('comments-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 30);
    }
    return result;
  };
  
  // --- Post menu handlers ---
  const handlePostMenuOpen = (e) => setPostMenuAnchor(e.currentTarget);
  const handlePostMenuClose = () => setPostMenuAnchor(null);

  const handleUpdatePost = () => {
    setUpdateTarget({ type: 'post', data: currentPost });
    setUpdateContent(currentPost.content);
    setUpdateModalOpen(true);
    handlePostMenuClose();
  };
  const handleDeletePost = async () => {
    handlePostMenuClose();
    try {
      const result = await deletePost(currentPost._id);
      if (result.success) {
        navigate('/forum');
      } else {
        alert('Failed to delete post: ' + (result.error || 'Unknown error'));
      }
    } catch (err) {
      alert('Failed to delete post: ' + (err?.message || err));
    }
  };
  const handleReportPost = () => {
    setReportTarget({ type: 'post', id: currentPost._id });
    setReportModalOpen(true);
    handlePostMenuClose();
  };

  // --- Comment menu handlers ---
  const handleUpdateComment = (comment) => {
    setUpdateTarget({ type: 'comment', data: comment });
    setUpdateContent(comment.text || comment.content);
    setUpdateModalOpen(true);
  };
  const handleDeleteComment = async (commentId) => {
    try {
      const result = await deleteComment({ postId: currentPost._id, commentId });
      if (!result.success) {
        alert('Failed to delete comment: ' + (result.error || 'Unknown error'));
      }
    } catch (err) {
      alert('Failed to delete comment: ' + (err?.message || err));
    }
  };
  const handleReportComment = (comment) => {
    setReportTarget({ type: 'comment', id: comment.id }); // id is always set
    setReportModalOpen(true);
  };

  // For update modal submission (post or comment)
  const handleUpdateSubmit = async () => {
    if (!updateContent.trim()) return;
    try {
      if (updateTarget?.type === "post") {
        const result = await updatePost({ postId: updateTarget.data._id, postData: { content: updateContent } });
        if (result.success) fetchPostById(updateTarget.data._id);
      } else if (updateTarget?.type === "comment") {
        const result = await updateComment({ postId: currentPost._id, commentId: updateTarget.data.id || updateTarget.data._id, content: updateContent });
        if (result.success) fetchComments(currentPost._id, { page: commentPage, limit: commentsPerPage });
      }
      setUpdateModalOpen(false);
      setUpdateTarget(null);
      setUpdateContent("");
    } catch (err) {
      console.error("Error updating:", err);
    }
  };

  const handleReportSubmit = async () => {
    // Debug log to check what is being sent
    console.log('Submitting report with:', {
      targetType: reportTarget?.type,
      targetId: reportTarget?.id,
      reason: reportReason.trim(),
    });
    if (!reportTarget?.type || !reportTarget?.id || !reportReason.trim()) {
      setReportError('All fields are required for reporting.');
      return;
    }
    try {
      const result = await report({
        targetType: reportTarget.type,
        targetId: reportTarget.id,
        reason: reportReason.trim(),
      });
      if (result.success) {
        setReportSuccess(true);
        setReportModalOpen(false);
        setReportReason('');
        setReportError(null);
      } else {
        setReportError(result.error);
      }
    } catch (err) {
      setReportError(err?.message || 'Failed to report');
    }
  };

  if (isLoading && !currentPost) {
    return (
      <>
        <Header />
        <ForumBackground>
          <Container sx={{ py: 4, display: 'flex', justifyContent: 'center' }}>
            <CircularProgress color="secondary" />
          </Container>
        </ForumBackground>
      </>
    );
  }
  
  if (error) {
    return (
      <>
        <Header />
        <ForumBackground>
          <Container sx={{ py: 4 }}>
            <Alert severity="error">{error}</Alert>
            <Button 
              startIcon={<ArrowBackIcon />} 
              onClick={() => navigate("/forum")}
              sx={{ mt: 2 }}
            >
              Back to Forum
            </Button>
          </Container>
        </ForumBackground>
      </>
    );
  }
  
  if (!currentPost) {
    return (
      <>
        <Header />
        <ForumBackground>
          <Container sx={{ py: 4 }}>
            <Alert severity="error">Post not found</Alert>
            <Button 
              startIcon={<ArrowBackIcon />} 
              onClick={() => navigate("/forum")}
              sx={{ mt: 2 }}
            >
              Back to Forum
            </Button>
          </Container>
        </ForumBackground>
      </>
    );
  }
  
  return (
    <>
      <Header />
      <ForumBackground>
        <Container maxWidth="md" sx={{ py: 4 }}>
          {fromAdminReports && (
            <Button
              startIcon={<ArrowBackIcon />}
              component={Link}
              to="/admin/reports"
              sx={{
                mb: 3,
                mr: 2,
                color: '#6a1b9a',
                '&:hover': {
                  bgcolor: 'rgba(106, 27, 154, 0.08)'
                }
              }}
            >
              Back to Reports
            </Button>
          )}
          <Button 
            startIcon={<ArrowBackIcon />} 
            component={Link} 
            to="/forum"
            sx={{ 
              mb: 3,
              color: '#6a1b9a',
              '&:hover': {
                bgcolor: 'rgba(106, 27, 154, 0.08)'
              }
            }}
          >
            Back to Forum
          </Button>
          <Paper elevation={3} sx={{ 
            p: 4, 
            borderRadius: 2, 
            mb: 4,
            bgcolor: 'rgba(255, 255, 255, 0.9)',
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)'
          }}>
            <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
              <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', color: '#333' }}>
                {currentPost.title}
              </Typography>
              <IconButton onClick={handlePostMenuOpen}>
                <MoreVertIcon />
              </IconButton>
              <ThreeDotMenu
                anchorEl={postMenuAnchor}
                isOwner={isPostOwner}
                onClose={handlePostMenuClose}
                onUpdate={handleUpdatePost}
                onDelete={handleDeletePost}
                onReport={handleReportPost}
              />
            </Box>
            
            <Box sx={{ display: "flex", alignItems: "center", mb: 3 }}>
              <Avatar 
                sx={{ mr: 1, bgcolor: '#8e24aa' }}
              >
                {currentPost.emoji || "😊"}
              </Avatar>
              <Box>
                <Typography variant="subtitle1">
                  {currentPost.author || "Anonymous"}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {formatDate(currentPost.createdAt)}
                </Typography>
              </Box>
            </Box>
            
            {currentPost.emotion && (
              <Box sx={{ mb: 3 }}>
                <Chip 
                  label={currentPost.emotion} 
                  color="secondary" 
                  sx={{ borderRadius: 1 }}
                />
              </Box>
            )}
            
            <Typography variant="body1" paragraph sx={{ whiteSpace: 'pre-line' }}>
              {currentPost.content}
            </Typography>
            
            {/* Like and comment count section */}
            <Box sx={{ display: "flex", alignItems: "center", mt: 3, mb: 2 }}>
              <Box 
                sx={{ 
                  display: "flex", 
                  alignItems: "center", 
                  mr: 3,
                  borderRadius: 1,
                  padding: '4px 8px',
                  bgcolor: 'rgba(142, 36, 170, 0.08)',
                }}
              >
                <IconButton 
                  onClick={handleLikePost} 
                  color={currentPost.isLiked ? "secondary" : "default"}
                  aria-label={currentPost.isLiked ? "Unlike post" : "Like post"}
                  sx={{ p: 0.5, mr: 0.5 }}
                  size="small"
                >
                  {currentPost.isLiked ? <ThumbUpIcon fontSize="small" /> : <ThumbUpOutlinedIcon fontSize="small" />}
                </IconButton>
                <Typography variant="body2">
                  {currentPost.likeCount || 0} likes
                </Typography>
              </Box>
              
              <Typography variant="body2" color="text.secondary">
                {comments?.length || 0} comments
              </Typography>
            </Box>
            
            {currentPost.tags && currentPost.tags.length > 0 && (
              <Box sx={{ mt: 3 }}>
                <Stack direction="row" spacing={1} flexWrap="wrap">
                  {currentPost.tags.map((tag, index) => (
                    <Chip 
                      key={index} 
                      label={tag} 
                      size="small"
                      sx={{ mb: 1 }}
                    />
                  ))}
                </Stack>
              </Box>
            )}
          </Paper>
          
          {/* Comments section */}
          <Paper elevation={2} sx={{ 
            p: 3, 
            borderRadius: 2,
            bgcolor: 'rgba(255, 255, 255, 0.85)',
            boxShadow: '0 2px 12px rgba(0, 0, 0, 0.08)'
          }}>
            <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold' }}>
              Comments ({comments?.length || 0})
            </Typography>
            
            {/* Comment input section - always show for authenticated users */}
            <Box id="comments-section" sx={{ mb: 4 }}>
              {isAuthenticated ? (
                <>
                  <InputComment
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    onSubmit={handleSubmitComment}
                    isSubmitting={isCreatingComment}
                    avatarUrl={currentUser?.avatar}
                    avatarText={currentUser?.username?.charAt(0) || "A"}
                  />
                  {commentError && (
                    <MuiAlert severity="error" sx={{ mt: 2 }}>{typeof commentError === 'string' ? commentError : 'Failed to add comment.'}</MuiAlert>
                  )}
                </>
              ) : (
                <Typography color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
                  Please <Link to="/signin">sign in</Link> to comment.
                </Typography>
              )}
            </Box>
            
            {isLoading && comments?.length === 0 ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}>
                <CircularProgress color="secondary" size={30} />
              </Box>
            ) : comments?.length === 0 ? (
              <Typography color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
                No comments yet. Be the first to comment!
              </Typography>
            ) : (
              <>
                <Stack spacing={3}>
                  {paginatedTopLevel.map((comment) => (
                    <Comment
                      key={comment._id}
                      comment={{
                        ...comment,
                        timestamp: formatDate(comment.createdAt),
                        text: comment.content || comment.text,
                        username: comment.author || comment.username || "Anonymous",
                      }}
                      currentUser={currentUser}
                      onUpdate={handleUpdateComment}
                      onDelete={handleDeleteComment}
                      onReport={handleReportComment}
                      depth={0}
                      repliesByCommentId={repliesByCommentId}
                      currentPost={currentPost}
                      onSubmitReply={handleReplySubmit}
                    />
                  ))}
                </Stack>
                {/* Pagination for comments */}
                {totalCommentPages > 1 && (
                  <Box sx={{ 
                    display: 'flex', 
                    justifyContent: 'center', 
                    mt: 3, 
                    pt: 2,
                    borderTop: '1px solid rgba(0, 0, 0, 0.1)'
                  }}>
                    <Pagination
                      count={totalCommentPages}
                      page={commentPage}
                      onChange={handleCommentPageChange}
                      color="secondary"
                      size="medium"
                      sx={{
                        '& .MuiPaginationItem-root': {
                          color: '#6a1b9a',
                          '&.Mui-selected': {
                            bgcolor: '#8e24aa',
                            color: '#fff',
                            '&:hover': {
                              bgcolor: '#6a1b9a',
                            }
                          },
                          '&:hover': {
                            bgcolor: 'rgba(142, 36, 170, 0.1)',
                          }
                        }
                      }}
                    />
                  </Box>
                )}
              </>
            )}
          </Paper>
          {/* Update Modal for editing post or comment */}
          <Dialog open={updateModalOpen} onClose={() => setUpdateModalOpen(false)} maxWidth="sm" fullWidth>
            <Box component="form" onSubmit={(e) => {
              e.preventDefault();
              handleUpdateSubmit();
            }} sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                {updateTarget?.type === 'post' ? 'Edit Post' : 'Edit Comment'}
              </Typography>
              <TextField
                multiline
                minRows={4}
                fullWidth
                autoFocus
                value={updateContent}
                onChange={e => setUpdateContent(e.target.value)}
                label={updateTarget?.type === 'post' ? 'Post Content' : 'Comment Content'}
                sx={{ mb: 2 }}
              />
              <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                <Button onClick={() => setUpdateModalOpen(false)} color="inherit">Cancel</Button>
                <Button type="submit" variant="contained" color="secondary">Save</Button>
              </Box>
            </Box>
          </Dialog>
          {/* Report Modal for reporting post or comment */}
          <ReportModal
            open={reportModalOpen}
            onClose={() => setReportModalOpen(false)}
            onSubmit={handleReportSubmit}
            reason={reportReason}
            setReason={setReportReason}
            error={reportError}
            targetType={reportTarget?.type}
          />
          <Snackbar
            open={commentSuccess}
            autoHideDuration={2500}
            onClose={() => setCommentSuccess(false)}
            anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          >
            <MuiAlert onClose={() => setCommentSuccess(false)} severity="success" sx={{ width: '100%' }}>
              Comment added!
            </MuiAlert>
          </Snackbar>
          <Snackbar
            open={reportSuccess}
            autoHideDuration={3000}
            onClose={() => setReportSuccess(false)}
            anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          >
            <MuiAlert onClose={() => setReportSuccess(false)} severity="success" sx={{ width: '100%' }}>
              Report submitted successfully!
            </MuiAlert>
          </Snackbar>
        </Container>
      </ForumBackground>
    </>
  );
};

export default PostOverview;

// --- Summary ---
// - Authentication check now uses Redux state (token from user slice)
// - Comment input is always shown for authenticated users
// - Duplicate token logic removed, DRY principle applied
// - If not authenticated, prompt user to sign in
// - All API calls should use the same token logic (handled in thunks)
