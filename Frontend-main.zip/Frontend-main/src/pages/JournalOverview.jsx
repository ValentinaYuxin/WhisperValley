import React, {
  useEffect,
  useState,
  useRef,
  useCallback,
  useMemo,
} from "react";
import axios from "axios";
import {
  Box,
  Typography,
  Button,
  CircularProgress,
  Container,
  Fab,
  Tooltip,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import JournalCard from "../components/Innervoice/JournalCard";
import { useNavigate } from "react-router-dom";
import { API_URL } from "../config";
import JournalDateFilter from "../components/Innervoice/JournalDateFilter";
import EmotionLabelFilter from "../components/forum/EmotionLabelFilter";

export default function JournalOverview() {
  const [journals, setJournals] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [period, setPeriod] = useState("7d");
  const [customRange, setCustomRange] = useState({ start: "", end: "" });
  const [selectedEmotion, setSelectedEmotion] = useState(null);
  const observer = useRef();
  const navigate = useNavigate();

  // Fetch journals (either reset or paginate)
  const fetchJournals = async (reset = false) => {
    try {
      setLoading(true);
      const res = await axios.get(`${API_URL}/premium/journals`, {
        params: {
          page: reset ? 1 : page,
          limit: 5,
          start:
            period === "custom" && customRange.start
              ? customRange.start
              : undefined,
          end:
            period === "custom" && customRange.end
              ? customRange.end
              : undefined,
        },
        withCredentials: true,
      });

      const fetched = res.data.data || [];

      if (reset) {
        setJournals(fetched);
      } else {
        setJournals((prev) => {
          const combined = [...prev, ...fetched];
          const uniqueMap = new Map();
          combined.forEach((j) => {
            uniqueMap.set(j._id, j);
          });
          return Array.from(uniqueMap.values());
        });
      }

      setHasMore(res.data.hasMore || fetched.length > 0);
      setError("");
    } catch (err) {
      console.error("❌ Failed to fetch journals:", err);
      setError("Failed to load journal entries.");
    } finally {
      setLoading(false);
    }
  };

  // Trigger journal reload on filter change
  useEffect(() => {
    setPage(1);
    setHasMore(true);
    fetchJournals(true);
  }, [period, customRange, selectedEmotion]);

  // Load next page if paginating
  useEffect(() => {
    if (page !== 1) {
      fetchJournals(false);
    }
  }, [page]);

  // Infinite scroll observer
  const lastJournalRef = useCallback(
    (node) => {
      if (loading || !hasMore) return;
      if (observer.current) observer.current.disconnect();

      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
          setPage((prev) => prev + 1);
        }
      });

      if (node) observer.current.observe(node);
    },
    [loading, hasMore]
  );

  const handleDelete = (id) => {
    setJournals((prev) => prev.filter((j) => j._id !== id));
  };

  // Local filtering after fetching
  const filteredJournals = useMemo(() => {
    const now = new Date();
    let cutoff = new Date();

    if (period === "3d") cutoff.setDate(now.getDate() - 3);
    else if (period === "7d") cutoff.setDate(now.getDate() - 7);
    else if (period === "30d") cutoff.setDate(now.getDate() - 30);

    if (period === "custom") {
      const start = new Date(`${customRange.start}T00:00:00.000Z`);
      const end = new Date(`${customRange.end}T23:59:59.999Z`);

      return journals.filter((j) => {
        const created = new Date(j.createdAt);
        const inRange =
          (!customRange.start || created >= start) &&
          (!customRange.end || created <= end);
        const emotionMatch =
          !selectedEmotion || j.emotionLabels === selectedEmotion;

        return inRange && emotionMatch;
      });
    }

    return journals.filter((j) => {
      const created = new Date(j.createdAt);
      const recent = created >= cutoff;
      const emotionMatch =
        !selectedEmotion || j.emotionLabels === selectedEmotion;
      return recent && emotionMatch;
    });
  }, [journals, period, customRange, selectedEmotion]);

  return (
    <Box
      sx={{
        minHeight: "100vh",
        backgroundImage: `url('${import.meta.env.BASE_URL}bg.png')`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
        display: "flex",
        flexDirection: "column",
        pt: "96px",
        pb: "80px",
        px: { xs: 2, sm: 3, md: 4 },
      }}
    >
      <Tooltip title="Create New Journal" arrow>
        <Fab
          color="secondary"
          onClick={() => navigate("/dailyjournal")}
          sx={{
            position: "fixed",
            top: { xs: "120px", md: "120px" },
            right: { xs: "16px", md: "calc(50% - 340px)" },
            zIndex: 1200,
            width: 52,
            height: 52,
            boxShadow: "0 6px 12px rgba(0,0,0,0.2)",
            transition: "transform 0.2s ease-in-out, box-shadow 0.2s",
            "&:hover": {
              transform: "scale(1.1)",
              boxShadow: "0 10px 18px rgba(0,0,0,0.3)",
            },
          }}
        >
          <AddIcon sx={{ fontSize: 26 }} />
        </Fab>
      </Tooltip>

      <Container maxWidth="sm">
        <Typography variant="h3" gutterBottom align="center">
          My Journal
        </Typography>

        <JournalDateFilter
          period={period}
          setPeriod={setPeriod}
          customRange={customRange}
          setCustomRange={setCustomRange}
          posts={journals}
        />

        <EmotionLabelFilter
          selected={selectedEmotion}
          onSelect={setSelectedEmotion}
        />

        {loading && journals.length === 0 ? (
          <Box display="flex" justifyContent="center" mt={4}>
            <CircularProgress />
          </Box>
        ) : error ? (
          <Typography color="error" align="center">
            {error}
          </Typography>
        ) : filteredJournals.length === 0 ? (
          <Box textAlign="center" mt={6}>
            {journals.length === 0 ? (
              <>
                <Typography variant="h6" gutterBottom>
                  You haven't written any journal yet.
                </Typography>
                <Typography variant="body1" mb={3}>
                  Start journaling to reflect on your emotions and track your
                  journey 💜
                </Typography>
              </>
            ) : (
              <>
                <Typography variant="h6" gutterBottom>
                  No journals match your current filters.
                </Typography>
                <Typography variant="body1" mb={3}>
                  Try adjusting the date range or emotion label.
                </Typography>
              </>
            )}
          </Box>
        ) : (
          <Box
            mt={4}
            sx={{
              backgroundColor: "rgba(255,255,255,0.7)",
              borderRadius: 3,
              boxShadow: 3,
              p: 2,
              display: "flex",
              flexDirection: "column",
              gap: 2,
            }}
          >
            {filteredJournals.map((journal, index) => {
              const isLast = index === filteredJournals.length - 1;
              return (
                <div key={journal._id} ref={isLast ? lastJournalRef : null}>
                  <JournalCard journal={journal} onDelete={handleDelete} />
                </div>
              );
            })}
            {loading && (
              <Box display="flex" justifyContent="center" mt={2}>
                <CircularProgress size={24} />
              </Box>
            )}
          </Box>
        )}
      </Container>
    </Box>
  );
}
