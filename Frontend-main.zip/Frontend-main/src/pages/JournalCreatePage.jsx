import React, { useState } from "react";
import axios from "axios";
import {
  TextField,
  Button,
  Box,
  Alert,
  Typography,
  Radio,
  RadioGroup,
  FormControl,
  FormLabel,
  FormControlLabel,
  CssBaseline,
  Container,
  Card,
  CircularProgress, // For loading spinner
} from "@mui/material";
import EmotionalLabels from "../components/forum/EmotionalLabels.jsx";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import { useNavigate } from "react-router-dom";

export default function JournalCreatePage() {
  const navigate = useNavigate(); // Get navigate function from react-router-dom
  const [content, setContent] = useState("");
  const [score1, setScore1] = useState(1);
  const [score2, setScore2] = useState(1);
  const [score3, setScore3] = useState(1);
  const [emotionLabel, setEmotionLabel] = useState("");

  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [showOverlay, setShowOverlay] = useState(false);
  const [feedback, setFeedback] = useState("");

  // state to track loading status (for disabling submit button and showing spinner)
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // 🔍 Check if emotion label is selected
    if (!emotionLabel) {
      setErrorMessage("Please select an emotional label.");
      return;
    }

    try {
      setLoading(true); // Start loading - disable submit button

      // Step 1: Submit journal entry to backend
      const journalRes = await axios.post(
        "http://localhost:8080/api/v1/premium/journals",
        {
          questionaireScore: [score1, score2, score3],
          content: content,
          emotionLabels: emotionLabel,
        },
        {
          withCredentials: true, // Ensure cookies are sent
        }
      );

      // Extract the created journal ID from response
      const journalId =
        journalRes.data?.journalId || journalRes.data?.journal?._id;
      if (!journalId) {
        setErrorMessage("Failed to retrieve journal ID.");
        setLoading(false); // Stop loading on error
        return;
      }

      // Step 2: Request AI-generated feedback using journal ID
      const feedbackRes = await axios.post(
        "http://localhost:8080/api/v1/premium/feedback",
        { journalId },
        { withCredentials: true }
      );

      const feedbackMessage =
        feedbackRes.data?.feedback || "No feedback generated.";

      // Step 3: Show overlay with feedback message
      setFeedback(feedbackMessage);
      setShowOverlay(true);

      // Reset form state
      setSuccessMessage("Successfully saved journal.");
      setErrorMessage("");
      setContent("");
      setEmotionLabel("");
      setScore1(1);
      setScore2(1);
      setScore3(1);
    } catch (err) {
      console.error("Submission error:", err);
      setErrorMessage(
        err.response?.data?.error || "Failed to save journal or fetch feedback."
      );
      setSuccessMessage("");
    } finally {
      setLoading(false); // Stop loading - re-enable submit button
    }
  };

  return (
    <>
      <CssBaseline />
      <Box
        component="main"
        sx={{
          backgroundImage: `url('${import.meta.env.BASE_URL}bg.png')`,
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          backgroundPosition: "center",
          minHeight: "100vh",
          pt: { xs: "110px", sm: "120px", md: "130px" }, // Prevent header overlap
          pb: 4,
          px: 2,
        }}
      >
        <Container maxWidth="md" sx={{ position: "relative" }}>
          {/* Back to Overview Button */}
          <Box sx={{ position: "absolute", top: -48, left: 0 }}>
            <Button
              onClick={() => navigate("/journals")}
              startIcon={<ArrowBackIosNewIcon />}
              sx={{
                textTransform: "none",
                fontWeight: "bold",
                color: "secondary.main",
                backgroundColor: "#f3e8ff",
                borderRadius: "12px",
                px: 2.5,
                py: 0.8,
                fontSize: "0.95rem",
                boxShadow: "none",
                "&:hover": {
                  backgroundColor: "#e0d4f7",
                },
              }}
            >
              Back to Overview
            </Button>
          </Box>

          <Card
            sx={{
              p: 4,
              mt: 4,
              mb: 8,
              borderRadius: 3,
              boxShadow: 5,
              bgcolor: "rgba(255, 255, 255, 0.7)",
            }}
          >
            <Typography variant="h3" sx={{ mb: 2, textAlign: "center" }}>
              Daily Journal
            </Typography>
            <Typography variant="subtitle1" sx={{ mb: 4, textAlign: "center" }}>
              Take a moment to reflect.
            </Typography>

            {/* Journal Form */}
            <Box
              component="form"
              onSubmit={handleSubmit}
              sx={{ display: "flex", flexDirection: "column", gap: 3 }}
            >
              {/* Question 1: Motivation */}
              <FormControl>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    flexWrap: "wrap",
                    gap: 2,
                  }}
                >
                  <FormLabel sx={{ color: "black" }}>
                    Rate your motivation level today
                  </FormLabel>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Typography variant="caption"> worst </Typography>
                    <RadioGroup
                      row
                      value={score1}
                      onChange={(e) => setScore1(Number(e.target.value))}
                    >
                      {[1, 2, 3, 4, 5].map((num) => (
                        <FormControlLabel
                          key={num}
                          value={num}
                          control={
                            <Radio
                              sx={{
                                color: "black",
                                "&.Mui-checked": { color: "#B388EB" },
                              }}
                            />
                          }
                          label={num}
                          sx={{ color: "black" }}
                        />
                      ))}
                    </RadioGroup>
                    <Typography variant="caption"> best </Typography>
                  </Box>
                </Box>
              </FormControl>

              {/* Question 2: Mood */}
              <FormControl>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    flexWrap: "wrap",
                    gap: 2,
                  }}
                >
                  <FormLabel sx={{ color: "black" }}>
                    Rate your overall mood today
                  </FormLabel>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Typography variant="caption"> worst </Typography>
                    <RadioGroup
                      row
                      value={score2}
                      onChange={(e) => setScore2(Number(e.target.value))}
                    >
                      {[1, 2, 3, 4, 5].map((num) => (
                        <FormControlLabel
                          key={num}
                          value={num}
                          control={
                            <Radio
                              sx={{
                                color: "black",
                                "&.Mui-checked": { color: "#B388EB" },
                              }}
                            />
                          }
                          label={num}
                          sx={{ color: "black" }}
                        />
                      ))}
                    </RadioGroup>
                    <Typography variant="caption"> best </Typography>
                  </Box>
                </Box>
              </FormControl>

              {/* Question 3: Connection */}
              <FormControl>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    flexWrap: "wrap",
                    gap: 2,
                  }}
                >
                  <FormLabel sx={{ color: "black" }}>
                    Rate your sense of connection today
                  </FormLabel>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Typography variant="caption"> worst </Typography>
                    <RadioGroup
                      row
                      value={score3}
                      onChange={(e) => setScore3(Number(e.target.value))}
                    >
                      {[1, 2, 3, 4, 5].map((num) => (
                        <FormControlLabel
                          key={num}
                          value={num}
                          control={
                            <Radio
                              sx={{
                                color: "black",
                                "&.Mui-checked": { color: "#B388EB" },
                              }}
                            />
                          }
                          label={num}
                          sx={{ color: "black" }}
                        />
                      ))}
                    </RadioGroup>
                    <Typography variant="caption"> best </Typography>
                  </Box>
                </Box>
              </FormControl>

              {/* Emotion label selector */}
              <EmotionalLabels
                emotion={emotionLabel}
                setEmotion={setEmotionLabel}
                error={errorMessage && !emotionLabel}
                helperText={!emotionLabel ? errorMessage : ""}
              />

              {/* Free-text content input */}
              <FormControl fullWidth>
                <FormLabel sx={{ color: "black" }}>
                  Whisper your emotions and thoughts here, no rush, no judgment
                </FormLabel>
                <TextField
                  multiline
                  rows={5}
                  fullWidth
                  variant="filled"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                />
              </FormControl>

              {/* Submit button */}
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={loading} // Disable button while loading
                sx={{
                  backgroundColor: "secondary.main",
                  "&:hover": {
                    backgroundColor: "secondary.dark",
                  },
                }}
              >
                {/* Show spinner while loading, otherwise show "Send" */}
                {loading ? (
                  <CircularProgress size={24} sx={{ color: "white" }} />
                ) : (
                  "Send"
                )}
              </Button>

              {/* Alert messages */}
              {successMessage && (
                <Alert severity="success">{successMessage}</Alert>
              )}
              {errorMessage && <Alert severity="error">{errorMessage}</Alert>}
            </Box>
          </Card>
        </Container>
      </Box>

      {/* Feedback overlay shown after journal is submitted */}
      {showOverlay && (
        <Box
          sx={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            bgcolor: "rgba(0,0,0,0.6)",
            zIndex: 1300,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Box
            sx={{
              bgcolor: "white",
              p: 4,
              borderRadius: 3,
              maxWidth: "90%",
              width: "400px",
              textAlign: "center",
              boxShadow: 10,
            }}
          >
            <Typography variant="body1" sx={{ mb: 3 }}>
              {feedback}
            </Typography>
            <Button
              variant="contained"
              color="secondary"
              onClick={() => {
                setShowOverlay(false);
                navigate("/journals");
              }}
            >
              Close
            </Button>
          </Box>
        </Box>
      )}
    </>
  );
}
