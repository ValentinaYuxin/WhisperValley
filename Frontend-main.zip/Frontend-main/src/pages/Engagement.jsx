import React, { useEffect, useState } from "react";
import {
  AppBar,
  Box,
  CssBaseline,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Button,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import CommentIcon from "@mui/icons-material/Comment";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import { useNavigate, useLocation } from "react-router-dom";
import MyComments from "../components/Engagement/MyComments";
import MyLikes from "../components/Engagement/MyLikes";

const drawerWidth = 240;

export default function Engagement() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const query = new URLSearchParams(location.search);
  const tabFromQuery = query.get("tab") || "My Comments";

  const [selectedMenu, setSelectedMenu] = useState(tabFromQuery);
  const navigate = useNavigate();

  useEffect(() => {
    setSelectedMenu(tabFromQuery);
  }, [tabFromQuery]);

  const handleDrawerToggle = () => setMobileOpen(!mobileOpen);

  const handleMenuClick = (menu) => {
    setSelectedMenu(menu);
    navigate(`/myengagements?tab=${encodeURIComponent(menu)}`, {
      replace: true,
    });
    setMobileOpen(false); //
  };

  const menuItems = [
    { text: "My Comments", icon: <CommentIcon /> },
    { text: "My Likes", icon: <ThumbUpIcon /> },
  ];

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />

      <AppBar
        position="fixed"
        sx={{
          background: "linear-gradient(to right, #e1d5f5, #f3e8ff)",
          color: "#4b0082",
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
          boxShadow: "none",
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: "none" } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" fontWeight="bold" noWrap>
            Engagement Center
          </Typography>
        </Toolbar>
      </AppBar>

      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
        aria-label="engagement folders"
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{ keepMounted: true }}
          sx={{
            display: { xs: "block", sm: "none" },
            "& .MuiDrawer-paper": { width: drawerWidth },
          }}
        >
          <DrawerContent
            selectedMenu={selectedMenu}
            onMenuClick={handleMenuClick}
          />
        </Drawer>

        <Drawer
          variant="permanent"
          sx={{
            display: { xs: "none", sm: "block" },
            "& .MuiDrawer-paper": { width: drawerWidth },
          }}
          open
        >
          <DrawerContent
            selectedMenu={selectedMenu}
            onMenuClick={handleMenuClick}
          />
        </Drawer>
      </Box>

      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          backgroundColor: "#fafafa",
          minHeight: "100vh",
        }}
      >
        <Toolbar />
        <Box
          sx={{
            backgroundColor: "#fff",
            borderRadius: 2,
            p: 4,
            boxShadow: 2,
            minHeight: "70vh",
          }}
        >
          {selectedMenu === "My Comments" && <MyComments />}
          {selectedMenu === "My Likes" && <MyLikes />}
        </Box>
      </Box>
    </Box>
  );
}

function DrawerContent({ selectedMenu, onMenuClick }) {
  const menuItems = [
    { text: "My Comments", icon: <CommentIcon /> },
    { text: "My Likes", icon: <ThumbUpIcon /> },
  ];

  return (
    <Box sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <Box sx={{ px: 2, pt: 2 }}>
        <Button
          startIcon={<ArrowBackIosNewIcon fontSize="small" />}
          onClick={() => window.history.back()}
          sx={{
            alignSelf: "flex-start",
            mb: 1,
            color: "#4b0082",
            fontSize: 15,
            textTransform: "none",
          }}
        >
          Back
        </Button>
      </Box>
      <Divider />
      <List sx={{ mt: 3 }}>
        {menuItems.map(({ text, icon }) => (
          <ListItem key={text} disablePadding>
            <ListItemButton
              onClick={() => onMenuClick(text)}
              selected={selectedMenu === text}
              sx={{
                borderRadius: 2,
                mx: 1,
                my: 0.5,
                "&.Mui-selected": {
                  backgroundColor: "#e6d6fa",
                  "& .MuiListItemText-primary": {
                    color: "#4b0082",
                    fontWeight: "bold",
                  },
                  "& .MuiListItemIcon-root": { color: "#4b0082" },
                },
                "&:hover": { backgroundColor: "#f1e9ff" },
              }}
            >
              <ListItemIcon sx={{ color: "#4b0082" }}>{icon}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );
}
