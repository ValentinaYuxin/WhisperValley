import { useState } from "react";
import axios from "axios";
import { Box, Paper, Typography, TextField, Button } from "@mui/material";

const Contact = () => {
  const [formData, setFormData] = useState({
    email: "",
    subject: "",
    message: "",
  });
  const [status, setStatus] = useState(""); // "loading" | "success" | "error"
  const [errors, setErrors] = useState({});

  // Validate all fields before submit
  const validateForm = () => {
    const newErrors = {};

    // Email required + format
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email.trim())) {
        newErrors.email = "Invalid email format";
      }
    }

    // Subject required + length
    if (!formData.subject.trim()) {
      newErrors.subject = "Subject is required";
    } else if (formData.subject.trim().length > 100) {
      newErrors.subject = "Subject must be 100 characters or fewer";
    }

    // Message required + length
    if (!formData.message.trim()) {
      newErrors.message = "Message is required";
    } else if (formData.message.trim().length > 2000) {
      newErrors.message = "Message must be 2000 characters or fewer";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
    setErrors((prev) => ({ ...prev, [e.target.name]: "" }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("");
    setErrors({});

    if (!validateForm()) {
      setStatus("error");
      return;
    }

    try {
      setStatus("loading");
      await axios.post("http://localhost:8080/api/v1/contact", formData);
      setStatus("success");
      setFormData({ email: "", subject: "", message: "" });
    } catch (error) {
      console.error(error);
      if (error.response && error.response.data.errors) {
        setErrors(error.response.data.errors);
      }
      setStatus("error");
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        backgroundImage: 'url("/Signbg.png")',
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        pt: "150px",
      }}
    >
      <Paper
        elevation={3}
        sx={{
          maxWidth: "600px",
          mx: "auto",
          p: "40px",
          borderRadius: "16px",
        }}
      >
        <Typography
          variant="h4"
          sx={{
            textAlign: "center",
            color: "#6d5b9b",
            mb: "32px",
            fontWeight: "bold",
          }}
        >
          Contact Us
        </Typography>

        <form onSubmit={handleSubmit} noValidate>
          <Box sx={{ mb: "20px" }}>
            <Typography
              sx={{ color: "#3D1F6C", fontWeight: "bold", mb: "6px" }}
            >
              Email
            </Typography>
            <TextField
              fullWidth
              color="secondary"
              name="email"
              value={formData.email}
              onChange={handleChange}
              variant="outlined"
              size="small"
              error={Boolean(errors.email)}
              helperText={errors.email || " "}
            />
          </Box>

          <Box sx={{ mb: "20px" }}>
            <Typography
              sx={{ color: "#3D1F6C", fontWeight: "bold", mb: "6px" }}
            >
              Subject
            </Typography>
            <TextField
              fullWidth
              color="secondary"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              variant="outlined"
              size="small"
              inputProps={{ maxLength: 100 }}
              error={Boolean(errors.subject)}
              helperText={errors.subject || " "}
            />
          </Box>

          <Box sx={{ mb: "24px" }}>
            <Typography
              sx={{ color: "#3D1F6C", fontWeight: "bold", mb: "6px" }}
            >
              Message
            </Typography>
            <TextField
              fullWidth
              color="secondary"
              multiline
              rows={5}
              name="message"
              value={formData.message}
              onChange={handleChange}
              variant="outlined"
              inputProps={{ maxLength: 2000 }}
              error={Boolean(errors.message)}
              helperText={errors.message || " "}
            />
          </Box>

          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{
              backgroundColor: "#6d5b9b",
              color: "white",
              py: "14px",
              fontSize: "1rem",
              fontWeight: "bold",
              borderRadius: "8px",
              "&:hover": {
                backgroundColor: "#5a4885",
              },
            }}
          >
            {status === "loading" ? "Submitting..." : "Submit"}
          </Button>
        </form>

        {status === "success" && (
          <Typography sx={{ color: "green", mt: "16px", textAlign: "center" }}>
            ✅ Thank you! Your feedback has been submitted.
          </Typography>
        )}

        {status === "error" && !Object.keys(errors).length && (
          <Typography sx={{ color: "red", mt: "16px", textAlign: "center" }}>
            ❌ Submission failed. Please try again later.
          </Typography>
        )}
      </Paper>
    </Box>
  );
};

export default Contact;
