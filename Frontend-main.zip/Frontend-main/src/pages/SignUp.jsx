import * as React from "react";
import {
  Box,
  Button,
  CssBaseline,
  Divider,
  FormLabel,
  FormControl,
  Link,
  TextField,
  Typography,
  Stack,
  Card as MuiCard,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import { useNavigate } from "react-router-dom";
import { useUser } from "../hooks/useRedux";
import { registerUser } from "../store/slices/userSlice";

const Card = styled(MuiCard)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  alignSelf: "center",
  width: "100%",
  padding: theme.spacing(4),
  gap: theme.spacing(2),
  margin: "auto",
  [theme.breakpoints.up("sm")]: {
    maxWidth: "450px",
  },
  boxShadow:
    "hsla(277, 66.90%, 23.70%, 0.72) 0px 5px 15px 0px, hsla(297, 65.30%, 28.20%, 0.44) 0px 15px 35px -5px",
}));

const SignUpContainer = styled(Stack)(({ theme }) => ({
  position: "relative",
  height: "100dvh",
  padding: theme.spacing(2),
  [theme.breakpoints.up("sm")]: {
    padding: theme.spacing(4),
  },
  "&::before": {
    content: '""',
    display: "block",
    position: "absolute",
    zIndex: -1,
    inset: 0,
    backgroundImage: 'url("/Signbg.png")',
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
}));

export default function SignUp() {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [confirmPassword, setConfirmPassword] = React.useState("");
  const [name, setName] = React.useState("");

  const [emailError, setEmailError] = React.useState(false);
  const [emailErrorMessage, setEmailErrorMessage] = React.useState("");
  const [passwordError, setPasswordError] = React.useState(false);
  const [passwordErrorMessage, setPasswordErrorMessage] = React.useState("");
  const [nameError, setNameError] = React.useState(false);
  const [nameErrorMessage, setNameErrorMessage] = React.useState("");

  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [dialogMessage, setDialogMessage] = React.useState("");
  const [dialogType, setDialogType] = React.useState("success");

  const navigate = useNavigate();
  const { register, loading, resetUserState } = useUser();

  // Reset user state (loading/error) when entering SignUp page
  React.useEffect(() => {
    resetUserState();
  }, [resetUserState]);

  const showDialog = (message, type = "success") => {
    setDialogMessage(message);
    setDialogType(type);
    setDialogOpen(true);
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
    if (dialogType === "success") {
      navigate("/");
    }
  };

  const validateInputs = () => {
    let isValid = true;
    setEmailError(false);
    setEmailErrorMessage("");
    setPasswordError(false);
    setPasswordErrorMessage("");
    setNameError(false);
    setNameErrorMessage("");

    // Updated email validation
    const allowedDomains = ["@mytum.de", "@tum.de", "@campus.lmu.de"];
    const hasValidDomain = allowedDomains.some((domain) =>
      email.toLowerCase().endsWith(domain)
    );

    if (!email || !/\S+@\S+\.\S+/.test(email) || !hasValidDomain) {
      setEmailError(true);
      setEmailErrorMessage(
        "Please use your student email (for example: @tum.de, @mytum.de or @campus.lmu.de)."
      );
      isValid = false;
    }

    if (!password || password.length < 8) {
      setPasswordError(true);
      setPasswordErrorMessage("Password must be at least 8 characters long.");
      isValid = false;
    }

    if (!name) {
      setNameError(true);
      setNameErrorMessage("Username is required.");
      isValid = false;
    }

    if (password !== confirmPassword) {
      setPasswordError(true);
      setPasswordErrorMessage("Passwords do not match.");
      isValid = false;
    }

    return isValid;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!validateInputs()) return;

    const result = await register({ username: name, email, password });

    if (registerUser.fulfilled.match(result)) {
      showDialog("Registration successful!", "success");
    } else {
      const msg = result.payload || "Registration failed.";
      if (msg.includes("email already exists")) {
        setEmailError(true);
        setEmailErrorMessage(msg);
      } else if (msg.includes("Password")) {
        setPasswordError(true);
        setPasswordErrorMessage(msg);
      } else if (msg.includes("username")) {
        setNameError(true);
        setNameErrorMessage(msg);
      } else {
        showDialog(msg, "error");
      }
    }
  };

  return (
    <>
      <CssBaseline />
      <SignUpContainer direction="column" justifyContent="center">
        <Card variant="outlined">
          <Typography component="h1" variant="h4">
            Sign up
          </Typography>

          <Box
            component="form"
            onSubmit={handleSubmit}
            sx={{ display: "flex", flexDirection: "column", gap: 2 }}
          >
            <FormControl>
              <FormLabel htmlFor="name">Username</FormLabel>
              <TextField
                required
                fullWidth
                color="secondary"
                id="name"
                placeholder="Snow White"
                error={nameError}
                helperText={nameErrorMessage}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </FormControl>

            <FormControl>
              <FormLabel htmlFor="email">Email</FormLabel>
              <TextField
                required
                fullWidth
                color="secondary"
                id="email"
                placeholder="you@example.com"
                error={emailError}
                helperText={emailErrorMessage}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </FormControl>

            <FormControl>
              <FormLabel htmlFor="password">Password</FormLabel>
              <TextField
                required
                fullWidth
                color="secondary"
                id="password"
                type="password"
                placeholder="••••••••"
                error={passwordError}
                helperText={passwordErrorMessage}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </FormControl>

            <FormControl>
              <FormLabel htmlFor="confirmpassword">Confirm Password</FormLabel>
              <TextField
                required
                fullWidth
                color="secondary"
                id="confirmpassword"
                type="password"
                placeholder="••••••••"
                error={passwordError}
                helperText={passwordError ? passwordErrorMessage : ""}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </FormControl>

            <Button
              type="submit"
              fullWidth
              color="secondary"
              variant="contained"
              disabled={loading}
            >
              {loading ? "Registering..." : "Sign up"}
            </Button>
          </Box>

          <Divider>
            <Typography sx={{ color: "text.secondary" }}>or</Typography>
          </Divider>

          <Typography sx={{ textAlign: "center" }}>
            Already have an account?{" "}
            <Link href="./SignIn" variant="body2" color="secondary">
              Sign in
            </Link>
          </Typography>
        </Card>
      </SignUpContainer>

      <Dialog
        open={dialogOpen}
        onClose={handleDialogClose}
        PaperProps={{
          sx: {
            borderRadius: 4,
            p: 2,
            minWidth: 300,
            backgroundColor: "#f9f4ff",
            border: "2px solid #a259ff",
          },
        }}
      >
        <DialogTitle
          sx={{
            color: dialogType === "success" ? "#6a1b9a" : "#d32f2f",
            fontWeight: "bold",
            fontSize: "1.3rem",
          }}
        >
          {dialogType === "success" ? "Success" : "Error"}
        </DialogTitle>
        <DialogContent sx={{ color: "#4a148c" }}>{dialogMessage}</DialogContent>
        <DialogActions>
          <Button
            onClick={handleDialogClose}
            color="secondary"
            variant="contained"
            sx={{
              backgroundColor: "#a259ff",
              "&:hover": { backgroundColor: "#8e44ff" },
              borderRadius: 2,
              px: 3,
            }}
          >
            OK
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
