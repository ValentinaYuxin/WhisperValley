import * as React from "react";
import {
  AppBar,
  Avatar,
  Box,
  CssBaseline,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogActions,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import DashboardIcon from "@mui/icons-material/Dashboard";
import PersonIcon from "@mui/icons-material/Person";
import LockIcon from "@mui/icons-material/Lock";
import SubscriptionsIcon from "@mui/icons-material/Subscriptions";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../store/slices/userSlice";
import EditProfile from "../components/Profile/EditProfile";
import ChangePassword from "../components/Profile/ChangePassword";
import OverviewContent from "../components/Profile/Dashboard/OverviewContent.jsx";
import MySub from "../components/Profile/MySubscription/MySub.jsx";
import { useNavigate } from "react-router-dom";

const drawerWidth = 240;

function Profile() {
  // State for drawer and menu selection
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [isClosing, setIsClosing] = React.useState(false);
  const [selectedMenu, setSelectedMenu] = React.useState("Dashboard");
  // State for logout confirmation dialog
  const [logoutDialogOpen, setLogoutDialogOpen] = React.useState(false);

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = useSelector((state) => state.user.user);

  if (!user) return <div>Loading...</div>;

  // Toggle drawer in mobile mode
  const handleDrawerToggle = () => {
    if (!isClosing) {
      setMobileOpen(!mobileOpen);
    }
  };

  const handleDrawerClose = () => {
    setIsClosing(true);
    setMobileOpen(false);
  };

  const handleDrawerTransitionEnd = () => {
    setIsClosing(false);
  };

  // Actual logout logic
  const handleLogout = () => {
    setLogoutDialogOpen(false);
    dispatch(logout());
    localStorage.removeItem("token");
    sessionStorage.removeItem("token");
    navigate("/signin");
  };

  const menuItems = [
    { text: "Dashboard", icon: <DashboardIcon /> },
    { text: "My Subscription", icon: <SubscriptionsIcon /> },
    { text: "Edit Profile", icon: <PersonIcon /> },
    { text: "Change Password", icon: <LockIcon /> },
  ];

  // Get avatar URL (supports relative and absolute)
  const getAvatarUrl = () => {
    if (!user?.avatar) return undefined;
    if (user.avatar.startsWith("http")) return user.avatar;
    return `http://localhost:8080${user.avatar}`;
  };

  // Drawer layout with navigation list
  const drawer = (
    <Box>
      <Box
        sx={{
          backgroundColor: "#e1d5f5",
          p: 2,
          pt: 3,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          borderBottomLeftRadius: 8,
          borderBottomRightRadius: 8,
        }}
      >
        {/* Back to homepage button */}
        <Button
          startIcon={<ArrowBackIosNewIcon fontSize="small" />}
          onClick={() => navigate("/")}
          sx={{
            alignSelf: "flex-start",
            mb: 1,
            color: "#4b0082",
            fontSize: 15,
            textTransform: "none",
          }}
        >
          Back
        </Button>
        <Avatar src={getAvatarUrl()} sx={{ width: 64, height: 64, mb: 1 }}>
          {!user.avatar || user.avatar.endsWith(".png")
            ? ""
            : user.username?.charAt(0)}
        </Avatar>
        <Typography variant="subtitle1" textAlign="center">
          {user?.username || "User123"}
        </Typography>
      </Box>
      <Divider />
      <List>
        {menuItems.map(({ text, icon }) => (
          <ListItem key={text} disablePadding>
            <ListItemButton
              onClick={() => setSelectedMenu(text)}
              selected={selectedMenu === text}
              sx={{
                borderRadius: 2,
                mx: 1,
                my: 0.5,
                "&.Mui-selected": {
                  backgroundColor: "#e6d6fa",
                  "& .MuiListItemText-primary": {
                    color: "#4b0082",
                    fontWeight: "bold",
                  },
                  "& .MuiListItemIcon-root": {
                    color: "#4b0082",
                  },
                },
                "&:hover": {
                  backgroundColor: "#f1e9ff",
                },
              }}
            >
              <ListItemIcon sx={{ color: "#4b0082" }}>{icon}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
      <Divider />
      <List>
        {/* Log out button opens confirmation dialog */}
        <ListItem disablePadding>
          <ListItemButton onClick={() => setLogoutDialogOpen(true)}>
            <ListItemIcon>
              <ExitToAppIcon />
            </ListItemIcon>
            <ListItemText primary="Log out" />
          </ListItemButton>
        </ListItem>
      </List>
    </Box>
  );

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      {/* AppBar on top */}
      <AppBar
        position="fixed"
        sx={{
          background: "linear-gradient(to right, #e1d5f5, #f3e8ff)",
          color: "#4b0082",
          boxShadow: "none",
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: "none" } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap component="div" fontWeight="bold">
            Hello, {user?.username || "User123"}!
          </Typography>
        </Toolbar>
      </AppBar>

      {/* Drawer navigation on the left */}
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
        aria-label="navigation"
      >
        {/* Mobile temporary drawer */}
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerClose}
          onTransitionEnd={handleDrawerTransitionEnd}
          sx={{
            display: { xs: "block", sm: "none" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
          ModalProps={{
            keepMounted: true,
          }}
        >
          {drawer}
        </Drawer>

        {/* Permanent drawer for desktop */}
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: "none", sm: "block" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>

      {/* Main content area */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          backgroundColor: "#fafafa",
          overflow: "auto",
        }}
      >
        <Toolbar />
        <Box
          sx={{
            backgroundColor: "#fff",
            borderRadius: 2,
            p: 4,
            boxShadow: 2,
            minHeight: "70vh",
          }}
        >
          {selectedMenu === "Dashboard" && <OverviewContent />}
          {selectedMenu === "Edit Profile" && <EditProfile />}
          {selectedMenu === "My Subscription" && <MySub />}
          {selectedMenu === "Change Password" && <ChangePassword />}
        </Box>
      </Box>

      {/* Logout confirmation dialog */}
      <Dialog
        open={logoutDialogOpen}
        onClose={() => setLogoutDialogOpen(false)}
      >
        <DialogTitle
          sx={{ color: "#4b0082", fontWeight: "bold", textAlign: "center" }}
        >
          Are you sure you want to log out?
        </DialogTitle>
        <DialogActions sx={{ justifyContent: "center", pb: 2 }}>
          <Button
            variant="outlined"
            onClick={() => setLogoutDialogOpen(false)}
            sx={{
              color: "#4b0082",
              borderColor: "#4b0082",
              textTransform: "none",
              mr: 1.5,
              "&:hover": {
                borderColor: "#6a1b9a",
                backgroundColor: "#f3e8ff",
              },
            }}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={handleLogout}
            sx={{
              backgroundColor: "#4b0082",
              textTransform: "none",
              "&:hover": {
                backgroundColor: "#6a1b9a",
              },
            }}
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

export default Profile;
