import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Button,
  Container,
  TextField,
  Typography,
  Paper,
  Chip,
  Stack,
  Alert,
  CircularProgress
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useForum } from "../hooks/useForum";
import ForumBackground from "../components/forum/ForumBackground";
import EmojiSelector from "../components/forum/EmojiSelector";
import EmotionalLabels from "../components/forum/EmotionalLabels";
import Header from "../components/Header";

const CreatePost = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  // Authentication check and redirect
  useEffect(() => {
    const token = localStorage.getItem('token') || sessionStorage.getItem('token');
    if (!token) {
      navigate('/signin', { replace: true });
    }
  }, [navigate]);
  const [tags, setTags] = useState([]);
  const [newTag, setNewTag] = useState("");
  const [emoji, setEmoji] = useState("😊");
  const [emotionLabel, setEmotionLabel] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [errors, setErrors] = useState({});
  
  const { createPost, isLoading, error, fetchAllTags, allTags } = useForum();
  
  useEffect(() => {
    fetchAllTags();
  }, [fetchAllTags]);
  
  const handleEmojiClick = (emojiData) => {
    setEmoji(emojiData.emoji);
    setShowEmojiPicker(false);
  };
  
  const handleAddTag = () => {
    const trimmed = newTag.trim();
    if (trimmed && !tags.includes(trimmed)) {
      setTags([...tags, trimmed]);
      setNewTag("");
    }
  };
  
  const handleRemoveTag = (tagToRemove) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };
  
  const validateForm = () => {
    const newErrors = {};
    
    if (!title.trim()) {
      newErrors.title = "Title is required";
    }
    
    if (!content.trim()) {
      newErrors.content = "Content is required";
    }
    
    if (!emotionLabel) {
      newErrors.emotionLabel = "Please select one emotion label";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    const postData = {
      title,
      content,
      tags,
      emoji,
      emotionLabel
    };
    
    console.log("Submitting post data:", postData);
    
    try {
      const result = await createPost(postData);
      if (result) {
        navigate("/forum");
      }
    } catch (error) {
      console.error("Error creating post:", error);
    }
  };
  
  const handleCancel = () => {
    navigate("/forum");
  };
  
  return (
    <>
      <Header />
      <ForumBackground>
        <Container maxWidth="md" sx={{ py: 4 }}>
          <Box sx={{ mb: 3 }}>
            <Button 
              startIcon={<ArrowBackIcon />} 
              onClick={handleCancel}
              variant="text"
              sx={{ color: '#8e24aa' }}
            >
              Back to Forum
            </Button>
          </Box>
          
          <Paper elevation={3} sx={{ p: 4, borderRadius: 3 }}>
            <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', color: '#333' }}>
              Create New Post
            </Typography>
            
            {error && (
              <Alert severity="error" sx={{ mb: 3 }}>
                {typeof error === 'string' ? error : (
                  Array.isArray(error) ? error.join(', ') : 'An error occurred while creating the post'
                )}
              </Alert>
            )}
            
            <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
              <EmojiSelector
                emoji={emoji}
                showEmojiPicker={showEmojiPicker}
                setShowEmojiPicker={setShowEmojiPicker}
                handleEmojiClick={handleEmojiClick}
              />
              
              <TextField
                label="Title"
                fullWidth
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                error={!!errors.title}
                helperText={errors.title || ""}
                sx={{ mb: 3 }}
              />
              
              <EmotionalLabels 
                emotion={emotionLabel} 
                setEmotion={setEmotionLabel} 
                error={!!errors.emotionLabel}
                helperText={errors.emotionLabel || ""}
              />
              
              <TextField
                label="Content"
                fullWidth
                required
                multiline
                rows={6}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                error={!!errors.content}
                helperText={errors.content || ""}
                sx={{ mb: 3 }}
              />
              
              {/* Tag input section */}
              <Box sx={{ mb: 3 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Tags (optional)
                </Typography>
                
                <Stack direction="row" spacing={1} sx={{ mb: 2, flexWrap: "wrap", gap: 1 }}>
                  {tags.map((tag, index) => (
                    <Chip 
                      key={index} 
                      label={tag} 
                      onDelete={() => handleRemoveTag(tag)}
                      sx={{
                        bgcolor: 'rgba(142, 36, 170, 0.1)',
                        color: '#8e24aa',
                        '&:hover': { bgcolor: 'rgba(142, 36, 170, 0.2)' }
                      }}
                    />
                  ))}
                </Stack>
                
                <Box sx={{ display: "flex", gap: 1 }}>
                  <TextField
                    label="Add tag"
                    variant="outlined"
                    size="small"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    sx={{ flexGrow: 1 }}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddTag();
                      }
                    }}
                  />
                  <Button 
                    variant="outlined" 
                    onClick={handleAddTag}
                    disabled={!newTag.trim()}
                    sx={{
                      color: '#8e24aa',
                      borderColor: '#8e24aa',
                      '&:hover': {
                        borderColor: '#6a1b9a',
                        backgroundColor: 'rgba(142, 36, 170, 0.08)'
                      }
                    }}
                  >
                    Add
                  </Button>
                </Box>
                {allTags && allTags.length > 0 && (
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="caption" color="text.secondary">
                      Suggested tags:
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                      {allTags
                        .filter(tag => !tags.includes(tag))
                        .slice(0, 10)
                        .map((tag, index) => (
                          <Chip
                            key={index}
                            label={tag}
                            size="small"
                            onClick={() => setTags([...tags, tag])}
                            sx={{
                              bgcolor: 'transparent',
                              border: '1px dashed #8e24aa50',
                              color: '#8e24aa',
                              '&:hover': { bgcolor: 'rgba(142, 36, 170, 0.08)' }
                            }}
                          />
                        ))}
                    </Box>
                  </Box>
                )}
              </Box>
              
              <Box sx={{ display: "flex", justifyContent: "space-between", gap: 2, mt: 4 }}>
                <Button 
                  variant="outlined" 
                  onClick={handleCancel}
                  sx={{
                    color: '#8e24aa',
                    borderColor: '#8e24aa',
                    '&:hover': {
                      borderColor: '#6a1b9a',
                      backgroundColor: 'rgba(142, 36, 170, 0.08)'
                    }
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  variant="contained" 
                  disabled={isLoading}
                  sx={{
                    bgcolor: '#8e24aa',
                    '&:hover': { bgcolor: '#6a1b9a' }
                  }}
                >
                  {isLoading ? <CircularProgress size={24} color="inherit" /> : "Create Post"}
                </Button>
              </Box>
            </Box>
          </Paper>
        </Container>
      </ForumBackground>
    </>
  );
};

export default CreatePost;