import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  LineChart,
  CartesianGrid,
  XAxis,
  YAxis,
  Line,
  ResponsiveContainer,
} from "recharts";
import {
  Box,
  Typography,
  Card,
  Select,
  MenuItem,
  Container,
  Grid,
  Toolbar,
  Divider,
  CircularProgress,
} from "@mui/material";
import { useUser } from "../hooks/useRedux";

// Generate recent N months dynamically
const generateRecentMonths = (count = 6) => {
  const result = [];
  const now = new Date();

  for (let i = 0; i < count; i++) {
    const year = now.getFullYear();
    const monthNumber = now.getMonth() + 1;
    const label = `${year}-${monthNumber}`;
    const value = `${year}-${String(monthNumber).padStart(2, "0")}`;
    result.push({ value, label });
    now.setMonth(now.getMonth() - 1);
  }

  return result;
};
const monthOptions = generateRecentMonths(6);

const emotionColors = {
  Enjoyment: "#4CAF50",
  Fear: "#9C27B0",
  Anger: "#F44336",
  Sadness: "#2196F3",
  Disgust: "#FF9800",
  Surprise: "#FFC107",
  Contempt: "#795548",
};

// Helper: aggregate logs by hour (format MM-DD HH:00)
function aggregateLogsByHour(logs) {
  const counts = {};
  logs.forEach(({ date, time }) => {
    const datetimeStr = `${date}T${time}`;
    const dt = new Date(datetimeStr);
    const month = String(dt.getMonth() + 1).padStart(2, "0");
    const day = String(dt.getDate()).padStart(2, "0");
    const hour = String(dt.getHours()).padStart(2, "0");
    const key = `${month}-${day} ${hour}:00`;
    counts[key] = (counts[key] || 0) + 1;
  });
  return Object.entries(counts).map(([datetime, count]) => ({
    datetime,
    count,
  }));
}

export default function DashboardPage() {
  const { user } = useUser();
  const userID = user?._id;
  const now = new Date();
  const defaultMonth = `${now.getFullYear()}-${String(
    now.getMonth() + 1
  ).padStart(2, "0")}`;

  const [selectedMonth, setSelectedMonth] = useState(() => {
    return localStorage.getItem("selectedMonth") || defaultMonth;
  });
  const [emotionData, setEmotionData] = useState([]);
  const [moodTrendData, setMoodTrendData] = useState([]);
  const [timelineData, setTimelineData] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false); // Loading indicator

  // Fetch dashboard data when userID or selectedMonth changes
  useEffect(() => {
    if (!userID) return;

    setLoading(true);

    const emotionURL = `http://localhost:8080/api/v1/premium/dashboard/${userID}/emotion-distribution?month=${selectedMonth}`;
    const trendURL = `http://localhost:8080/api/v1/premium/dashboard/${userID}/score-trend?month=${selectedMonth}`;
    const timelineURL = `http://localhost:8080/api/v1/premium/dashboard/${userID}/journal-timeline?month=${selectedMonth}`;
    const summaryURL = `http://localhost:8080/api/v1/premium/dashboard/${userID}/monthly-summary?month=${selectedMonth}`;

    Promise.all([
      axios.get(emotionURL),
      axios.get(trendURL),
      axios.get(timelineURL),
      axios.get(summaryURL),
    ])
      .then(([emotionRes, trendRes, timelineRes, summaryRes]) => {
        setEmotionData(emotionRes.data || []);
        setMoodTrendData(trendRes.data || []);
        const aggregated = timelineRes?.data?.data?.length
          ? aggregateLogsByHour(timelineRes.data.data)
          : [];
        setTimelineData(aggregated);
        setSummary(summaryRes.data?.success ? summaryRes.data.summary : null);
      })
      .catch((err) => {
        console.error("Dashboard API error:", err);
        setEmotionData([]);
        setMoodTrendData([]);
        setTimelineData([]);
        setSummary(null);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [userID, selectedMonth]);

  // Return full JSX tree defined in separate file
  return (
    <Box
      component="main"
      sx={{
        backgroundImage: `url('${import.meta.env.BASE_URL}bg.png')`,
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
        backgroundPosition: "center",
        minHeight: "100vh",
        height: "100%",
        paddingTop: "80px",
        justifyContent: "center",
        alignItems: "center",
        px: 2,
        py: 4,
        fontFamily: `"M PLUS Rounded 1c", sans-serif`,
      }}
    >
      <Container maxWidth="lg">
        <Toolbar />

        <Box sx={{ textAlign: "center", mb: 4 }}>
          <Typography variant="h4" gutterBottom>
            Mood Dashboard
          </Typography>
          <Typography variant="h5" gutterBottom>
            Your Emotional Snapshot
          </Typography>
          <Divider sx={{ my: 2, borderBottomWidth: 2, opacity: 0.5 }} />
        </Box>

        <Box sx={{ display: "flex", justifyContent: "center", mb: 4 }}>
          <Box sx={{ textAlign: "center" }}>
            <Typography variant="body2" sx={{ mb: 1 }}>
              Select month:
            </Typography>
            <Select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              size="small"
            >
              {monthOptions.map((m) => (
                <MenuItem key={m.value} value={m.value}>
                  {m.label}
                </MenuItem>
              ))}
            </Select>
          </Box>
        </Box>

        {/* Show loading indicator during data fetch */}
        {loading ? (
          <Box textAlign="center" py={8}>
            <CircularProgress />
            <Typography sx={{ mt: 2 }} color="text.secondary">
              Loading dashboard data...
            </Typography>
          </Box>
        ) : (
          // Existing charts and summary container...
          <Box
            sx={{
              backgroundColor: "rgba(255, 255, 255, 0.7)",
              borderRadius: 2,
              boxShadow: 3,
              padding: 3,
              maxWidth: 900,
              marginX: "auto",
              width: "100%",
            }}
          >
            <Grid
              container
              spacing={4}
              justifyContent="center"
              sx={{ width: "100%" }}
            >
              {/* Timeline Chart */}
              <Grid item xs={12} sx={{ width: "100%" }}>
                <Card sx={{ p: 3, bgcolor: "rgba(255,255,255,0.85)" }}>
                  <Typography
                    variant="h6"
                    gutterBottom
                    sx={{ textAlign: "center" }}
                  >
                    Your Journal Timeline
                  </Typography>
                  <Box sx={{ width: "100%", height: 300 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={timelineData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 100 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                          dataKey="datetime"
                          angle={-45}
                          textAnchor="end"
                          interval={0}
                        />
                        <YAxis domain={[0, 10]} />
                        <Tooltip />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="count"
                          stroke="#8884d8"
                          dot={{ r: 5 }}
                          activeDot={{ r: 8 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </Box>
                </Card>
              </Grid>

              {/* Pie Chart */}
              <Grid item xs={12} sx={{ width: "100%" }}>
                <Card sx={{ p: 3, bgcolor: "rgba(255,255,255,0.85)" }}>
                  <Typography
                    variant="h6"
                    gutterBottom
                    sx={{ textAlign: "center" }}
                  >
                    How You've Been Feeling
                  </Typography>
                  <Box sx={{ width: "100%", height: 300 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={emotionData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          label
                        >
                          {emotionData.map((entry, index) => (
                            <Cell
                              key={`cell-${index}`}
                              fill={emotionColors[entry.name] || "#8884d8"}
                            />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend layout="horizontal" verticalAlign="bottom" />
                      </PieChart>
                    </ResponsiveContainer>
                  </Box>
                </Card>
              </Grid>

              {/* Mood Trend Line Chart */}
              <Grid item xs={12} sx={{ width: "100%" }}>
                <Card sx={{ p: 3, bgcolor: "rgba(255,255,255,0.85)" }}>
                  <Typography
                    variant="h6"
                    gutterBottom
                    sx={{ textAlign: "center" }}
                  >
                    Mood Score Trend
                  </Typography>
                  <Box sx={{ width: "100%", height: 300 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={moodTrendData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis domain={[0, 10]} />
                        <Tooltip />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="averageScore"
                          stroke="#8884d8"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </Box>
                </Card>
              </Grid>

              {/* Monthly Summary */}
              <Grid item xs={12} sx={{ width: "100%" }}>
                <Card
                  sx={{
                    p: 3,
                    bgcolor: "rgba(255,255,255,0.85)",
                    minHeight: 220,
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                  }}
                >
                  <Typography
                    variant="h6"
                    gutterBottom
                    sx={{ textAlign: "center" }}
                  >
                    Monthly Summary
                  </Typography>

                  {summary ? (
                    <Box
                      sx={{
                        px: 2,
                        whiteSpace: "pre-line",
                        fontSize: "1rem",
                        width: "100%",
                        overflowWrap: "break-word",
                      }}
                    >
                      <Typography>
                        📅 Total journals written:{" "}
                        <strong>{summary.totalJournals}</strong>
                      </Typography>
                      <Typography>
                        🏷️ Most frequent emotional label:{" "}
                        <strong>{summary.mostFrequentLabel || "None"}</strong>
                      </Typography>
                      <Typography>
                        📈 Day with highest average score:{" "}
                        <strong>
                          {summary.highestAvgScoreDay
                            ? `${
                                summary.highestAvgScoreDay.day
                              } (avg: ${summary.highestAvgScoreDay.avg.toFixed(
                                2
                              )})`
                            : "N/A"}
                        </strong>
                      </Typography>
                      <Typography>
                        📉 Day with lowest average score:{" "}
                        <strong>
                          {summary.lowestAvgScoreDay
                            ? `${
                                summary.lowestAvgScoreDay.day
                              } (avg: ${summary.lowestAvgScoreDay.avg.toFixed(
                                2
                              )})`
                            : "N/A"}
                        </strong>
                      </Typography>
                      <Typography>
                        ⏰ Peak journaling hour (UTC):{" "}
                        <strong>
                          {summary.peakWritingHour !== null
                            ? `${summary.peakWritingHour}:00`
                            : "N/A"}
                        </strong>
                      </Typography>

                      <Divider sx={{ my: 2 }} />

                      <Typography
                        sx={{
                          fontStyle: "italic",
                          fontSize: "0.95rem",
                          color: "#555",
                          lineHeight: 1.5,
                        }}
                      >
                        ✨ {summary.summaryText} ✨
                      </Typography>
                    </Box>
                  ) : (
                    <Box
                      sx={{
                        textAlign: "center",
                        py: 8,
                        fontStyle: "italic",
                        color: "text.secondary",
                        minHeight: 140,
                        width: "100%",
                      }}
                    >
                      Loading summary...
                    </Box>
                  )}
                </Card>
              </Grid>
            </Grid>
          </Box>
        )}
      </Container>
    </Box>
  );
}
