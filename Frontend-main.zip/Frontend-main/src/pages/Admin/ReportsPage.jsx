import React, {useEffect, useState} from "react";
import {
    Typography,
    Box,
    Paper,
    CircularProgress,
    Alert,
    FormControl,
    InputLabel,
    Select,
    MenuItem, TablePagination,
} from '@mui/material';
import { useAdmin } from '../../hooks/useAdmin';
import ReportedItemDialog from "../../components/Admin/Reports/ReportedItemDialog.jsx";
import ReportsTable from "../../components/Admin/Reports/ReportsTable.jsx";
import DeleteReportDialog from "../../components/Admin/Reports/DeleteReportDialog.jsx";
import Grid from "@mui/material/Grid";

export default function AdminReportsPage() {
    const {
        reports,
        loading,
        error,
        fetchReports,
        updateReportStatus,
        getReportedItem,
        reportedItem,
        clearReportedItem,
        fetchPendingReportsCount,
        totalReports,
        deleteReport,
        deletePostByAdmin,
        deleteCommentByAdmin,
        clearError,
    } = useAdmin();

    const [ selectedReportId, setSelectedReportId ] = useState(null);
    const [ reportedItemDialogOpen, setReportedItemDialogOpen ] = useState(false);

    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);

    const [ statusFilter, setStatusFilter ] = useState('');
    const [ targetTypeFilter, setTargetTypeFilter ] = useState('');

    const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
    const [reportToDeleteId, setReportToDeleteId] = useState(null);

    useEffect(() => {
        clearError();
        fetchReports({ status: statusFilter, targetType: targetTypeFilter });
        fetchPendingReportsCount();
    }, [fetchReports, fetchPendingReportsCount, clearError, statusFilter, targetTypeFilter]);

    useEffect(() => {
        if (selectedReportId && !reportedItemDialogOpen) {
            getReportedItem(selectedReportId);
        }
    }, [selectedReportId, reportedItemDialogOpen, getReportedItem]);

    useEffect(() => {
        if (reportedItem) {
            setReportedItemDialogOpen(true);
        }
    }, [reportedItem]);

    const handleViewReportedItem = (reportId) => {
        setSelectedReportId(reportId);
    };

    const handleReportedItemDialogClose = () => {
        setReportedItemDialogOpen(false);
        setSelectedReportId(null);
        clearReportedItem();
    };

    const handleUpdateStatus = async (reportId, status) => {
        await updateReportStatus(reportId, status);
        fetchReports({ status: statusFilter, targetType: targetTypeFilter });
        fetchPendingReportsCount();  // refetch pending count after status update
    }

    const handleDeleteItem = async (itemId, itemType) => {
        if (itemType === 'post') {
            await deletePostByAdmin(itemId);
        } else if (itemType === 'comment') {
            await deleteCommentByAdmin(itemId);
        }
        fetchReports({ page: page + 1, limit: rowsPerPage, status: statusFilter, targetType: targetTypeFilter });
        fetchPendingReportsCount();
    }

    const handleDeleteReport = (reportId) => {
        setReportToDeleteId(reportId);
        setOpenDeleteDialog(true);
    }

    const handleConfirmDelete = async () => {
        if (reportToDeleteId) {
            await deleteReport(reportToDeleteId);
            const newPage = reports.length === 1 && page > 0 ? page - 1 : page;

            await fetchReports({
                page: newPage + 1,
                limit: rowsPerPage,
                status: statusFilter,
                targetType: targetTypeFilter
            });
            setPage(newPage);
            setOpenDeleteDialog(false);
            setReportToDeleteId(null);
        }
    };

    const handleCancelDelete = () => {
        setOpenDeleteDialog(false);
        setReportToDeleteId(null);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    }

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    }

    if (loading && !reports) return <CircularProgress />;

    if (error) return <Alert severity="error">Error fetching reports:{error.message || error.error || JSON.stringify(error)}</Alert>;

    // ensure reports is an array before mapping over it
    const reportsToDisplay = Array.isArray(reports) ? reports : [];

    return (
        <Paper sx={{ p: 3, borderRadius: 2 }}>

            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
                <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', color: '#4b0082' }}>
                    User Reports
                </Typography>

                {/* Filter Controls */}
                <Box>
                    <Grid container spacing={2}>
                        <Grid item>
                            <FormControl variant="outlined" size="small" sx={{ minWidth: 150 }}>
                                <InputLabel>Filter by Status</InputLabel>
                                <Select
                                    id="status-filter"
                                    value={statusFilter}
                                    onChange={(e) => {
                                        setStatusFilter(e.target.value);
                                        setPage(0);
                                    }}
                                    label="Filter by Status"
                                >
                                    <MenuItem value="">All</MenuItem>
                                    <MenuItem value="pending">Pending</MenuItem>
                                    <MenuItem value="reviewed">Reviewed</MenuItem>
                                    <MenuItem value="dismissed">Dismissed</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item>
                            <FormControl variant="outlined" size="small" sx={{ minWidth: 150 }}>
                                <InputLabel>Filter by Type</InputLabel>
                                <Select
                                    id="type-filter"
                                    value={targetTypeFilter}
                                    onChange={(e) => {
                                        setTargetTypeFilter(e.target.value);
                                        setPage(0);
                                    }}
                                    label="Filter by Type"
                                >
                                    <MenuItem value="">All</MenuItem>
                                    <MenuItem value="post">Post</MenuItem>
                                    <MenuItem value="comment">Comment</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                </Box>
            </Box>

            <ReportsTable
                reports={reportsToDisplay}
                onView={handleViewReportedItem}
                onDelete={handleDeleteReport}
                onUpdateStatus={handleUpdateStatus}
            />

            <TablePagination
                component="div"
                count={totalReports || 0}
                page={page}
                onPageChange={handleChangePage}
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                rowsPerPageOptions={[5, 10, 25]}
            />

            <ReportedItemDialog
                open={reportedItemDialogOpen}
                handleClose={handleReportedItemDialogClose}
                reportedItem={reportedItem?.data}
                itemType={reportedItem?.type}
                onDeleteItem={handleDeleteItem}
            />

            <DeleteReportDialog
                open={openDeleteDialog}
                onClose={handleCancelDelete}
                onConfirm={handleConfirmDelete}
            />
        </Paper>
    );
}