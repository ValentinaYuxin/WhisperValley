import React, { useEffect } from "react";
import { Typography, Box, CircularProgress, Alert } from "@mui/material";
import { useAdmin } from "../../hooks/useAdmin";
import PeopleAltIcon from "@mui/icons-material/PeopleAlt";
import PostAddIcon from "@mui/icons-material/PostAdd";
import StatCard from "../../components/Admin/Dashboard/StatCard.jsx";
import NewUsersLineChart from "../../components/Admin/Dashboard/NewUsersLineChart.jsx";
import SubscriptionsPieChart from "../../components/Admin/Dashboard/SubscriptionPieChart.jsx";

export default function AdminDashboardPage() {
    const { stats, loading, error, fetchDashboardStats } = useAdmin();

    useEffect(() => {
        fetchDashboardStats();
    }, [fetchDashboardStats]);

    if (loading) return <CircularProgress />;
    if (error) return <Alert severity="error">Error fetching dashboard data: {error}</Alert>;

    if (!stats) return <Alert severity="info">No Dashboard data found.</Alert>;

    const subDataForPieChart = stats?.subscriptions?.byPlan
        ? Object.keys(stats.subscriptions.byPlan).map((key) => ({
            name: key.charAt(0).toUpperCase() + key.slice(1),
            value: stats.subscriptions.byPlan[key],
        }))
        : [];

    return (
        <Box
            sx={{
                width: "100%",
                minHeight: "calc(100vh - 64px)",
                display: "flex",
                justifyContent: "center",
                px: { xs: 2, sm: 3, md: 4 },
                py: 1,
            }}
        >
            <Box sx={{ width: "100%", maxWidth: "1200px" }}>
                <Typography
                    variant="h4"
                    gutterBottom
                    sx={{ fontWeight: "bold", color: "#4b0082", mb: 3 }}
                >
                    Admin Dashboard
                </Typography>

                {/*first row*/}
                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "row",
                        gap: 3,
                        alignItems: "center",
                        mb: 4,
                        flexWrap: "wrap",
                    }}
                >
                    {/*line chart*/}
                    <Box sx={{ flex: 1.5, minWidth: 300, maxWidth: "66.6%" }}>
                        <NewUsersLineChart
                            data={stats.users?.newLast30DaysDaily || []}
                        />
                    </Box>

                    <Box
                        sx={{
                            flex: 1,
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "center",
                            alignItems: "flex-start",
                            gap: 5,
                            minWidth: 180,
                            maxWidth: 250,
                        }}
                    >
                        <StatCard
                            title="Total Users"
                            value={stats.users?.total || 0}
                            icon={<PeopleAltIcon fontSize="medium" />}
                            color="#e6d6fa"
                        />
                        <StatCard
                            title="New Users (7 Days)"
                            value={stats.users?.newLast7Days || 0}
                            icon={<PeopleAltIcon fontSize="medium" />}
                            color="#e6d6fa"
                        />
                    </Box>
                </Box>

                {/*second row*/}
                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "row",
                        gap: 4,
                        alignItems: "center",
                        flexWrap: "wrap",
                    }}
                >
                    {/*two columns*/}
                    <Box
                        sx={{
                            flex: 2,
                            display: "flex",
                            gap: 5,
                            minWidth: 400,
                        }}
                    >
                        {/*first column*/}
                        <Box
                            sx={{
                                flex: 1,
                                display: "flex",
                                flexDirection: "column",
                                gap: 2,
                            }}
                        >
                            <StatCard
                                title="Total Forum Posts"
                                value={stats.content?.totalPosts || 0}
                                icon={<PostAddIcon fontSize="medium" />}
                            />
                            <StatCard
                                title="Total Journal Entries"
                                value={stats.journals?.total || 0}
                                icon={<PostAddIcon fontSize="medium" />}
                            />
                        </Box>
                        {/*second column*/}
                        <Box
                            sx={{
                                flex: 1,
                                display: "flex",
                                flexDirection: "column",
                                gap: 2,
                            }}
                        >
                            <StatCard
                                title="Forum Posts (7 Days)"
                                value={stats.content?.postsLast7Days || 0}
                                icon={<PostAddIcon fontSize="medium" />}
                            />
                            <StatCard
                                title="Avg Journals per User"
                                value={
                                    stats.journals?.averagePerUser?.toFixed(2) || "0.00"
                                }
                                icon={<PostAddIcon fontSize="medium" />}
                            />
                        </Box>
                    </Box>

                    {/*pie chart*/}
                    <Box
                        sx={{
                            flex: 1.3,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            minWidth: 320,
                        }}
                    >
                        <SubscriptionsPieChart data={subDataForPieChart} />
                    </Box>
                </Box>
            </Box>
        </Box>
    );
}
