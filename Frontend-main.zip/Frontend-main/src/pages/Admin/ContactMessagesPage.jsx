import React, {useEffect, useState} from "react";
import {
    Typography,
    Box,
    Paper,
    CircularProgress,
    Alert,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Grid,
    TablePagination,
} from '@mui/material';
import { useAdmin } from '../../hooks/useAdmin';
import ContactMessagesTable from "../../components/Admin/ContactMessages/ContactMessagesTable.jsx";
import DeleteMessageDialog from "../../components/Admin/ContactMessages/DeleteMessagesDialog.jsx";
import ViewMessageDialog from "../../components/Admin/ContactMessages/ViewMessageDialog.jsx";

export default function AdminContactMessagesPage() {
    const {
        contactMessages, totalMessages, loading, error, fetchContactMessages, deleteContactMessage , updateContactMessageStatus,
    } = useAdmin();
    const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
    const [messageToDeleteId, setMessageToDeleteId] = useState(null);
    const [openViewDialog, setOpenViewDialog] = useState(false);
    const [messageToView, setMessageToView] = useState(null);

    // pagination
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);

    // filter
    const [statusFilter, setStatusFilter] = useState('all');
    const [timeFilter, setTimeFilter] = useState('all');

    useEffect(() => {
        fetchContactMessages({ page: page + 1, limit: rowsPerPage, status: statusFilter, time: timeFilter });
    }, [fetchContactMessages, page, rowsPerPage, statusFilter, timeFilter]);

    // delete handler
    const handleDeleteClick = (messageId) => {
        setMessageToDeleteId(messageId);
        setOpenDeleteDialog(true);
    };

    const handleConfirmDelete = async () => {
        if (messageToDeleteId) {
            await deleteContactMessage(messageToDeleteId);

            // update pagination
            const newPage = contactMessages.length === 1 && page > 0 ? page - 1 : page;

            await fetchContactMessages({
                page: page + 1,
                limit: rowsPerPage,
                status: statusFilter,
                time: timeFilter
            });

            setPage(newPage);
            setOpenDeleteDialog(false);
            setMessageToDeleteId(null);
        }
    };

    const handleCancelDelete = () => {
        setOpenDeleteDialog(false);
        setMessageToDeleteId(null);
    };

    // view handler
    const handleViewClick = (message) => {
        setMessageToView(message);
        setOpenViewDialog(true);
    };

    const handleCloseViewDialog = () => {
        setOpenViewDialog(false);
        setMessageToView(null);
    };

    const handleUpdateStatus = async (messageId, status) => {
        await updateContactMessageStatus(messageId, status);
    };

    // pagination handler
    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    if (loading && !contactMessages) return <CircularProgress />;

    if (error)
        return <Alert severity="error">
            Error fetching contact messages: {error.message || error.error || JSON.stringify(error)}
        </Alert>;


    return (
        <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
                <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', color: '#4b0082', m: 0 }}>
                    Contact Messages
                </Typography>

                <Box>
                    <Grid container spacing={2}>
                        <Grid item>
                            <FormControl variant="outlined" size="small" sx={{ minWidth: 150 }}>
                                <InputLabel>Filter by Status</InputLabel>
                                <Select
                                    value={statusFilter}
                                    onChange={(e) => {
                                        setStatusFilter(e.target.value);
                                        setPage(0);
                                    }}
                                    label="Filter by Status"
                                >
                                    <MenuItem value="all">All</MenuItem>
                                    <MenuItem value="new">New</MenuItem>
                                    <MenuItem value="read">Read</MenuItem>
                                    <MenuItem value="resolved">Resolved</MenuItem>
                                    <MenuItem value="archived">Archived</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item>
                            <FormControl variant="outlined" size=
                                "small" sx={{ minWidth: 150 }}>
                                <InputLabel>Filter by Time</InputLabel>
                                <Select
                                    value={timeFilter}
                                    onChange={(e) => setTimeFilter(e.target.value)}
                                    label="Filter by Time"
                                >
                                    <MenuItem value="all">All Time</MenuItem>
                                    <MenuItem value="24h">Last 24 Hours</MenuItem>
                                    <MenuItem value="7d">Last 7 Days</MenuItem>
                                    <MenuItem value="30d">Last 30 Days
                                    </MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                </Box>
            </Box>

            <ContactMessagesTable
                // pass messages for the current page
                messages={contactMessages}
                onView={handleViewClick}
                onDelete={handleDeleteClick}
                onUpdateStatus={handleUpdateStatus}
            />

            <TablePagination
                component="div"
                count={totalMessages || 0}
                page={page}
                onPageChange={handleChangePage}
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                rowsPerPageOptions={[5, 10, 25]}
            />

            <DeleteMessageDialog
                open={openDeleteDialog}
                onClose={handleCancelDelete}
                onConfirm={handleConfirmDelete}
            />

            <ViewMessageDialog
                open={openViewDialog}
                onClose={handleCloseViewDialog}
                message={messageToView}
            />
        </Paper>
    );
}