import React, {useState, useEffect, useCallback} from "react";
import {
    Typography,
    Paper,
    CircularProgress,
    Alert,
    TablePagination,
} from '@mui/material';
import { useAdmin } from '../../hooks/useAdmin';
import { useUser } from "../../hooks/useRedux.js";
import { useNavigate } from "react-router-dom";
import UserFilters from "../../components/Admin/Users/UserFilters.jsx";
import UserTable from "../../components/Admin/Users/UserTable.jsx";
import DeleteUserDialog from "../../components/Admin/Users/DeleteUserDialog.jsx";


export default function AdminUsersPage() {
    const { users, totalUsers, loading, error, fetchUsers, deleteUser } = useAdmin();
    const { user: currentUser } = useUser();
    const navigate = useNavigate();

    // state for confirmation dialog
    const [ open, setOpen ] = useState(false);
    const [ selectedUserId, setSelectedUserId ] = useState(null);

    // state for filters and pagination
    const [searchTerm, setSearchTerm] = useState('');
    const [roleFilter, setRoleFilter] = useState('all');
    const [subscriptionFilter, setSubscriptionFilter] = useState('all');
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);

    const fetchUsersCallback = useCallback(() => {
        const params = {
            page: page + 1,
            limit: rowsPerPage,
            search: searchTerm,
            role: roleFilter,
            subscription: subscriptionFilter,
        };
        fetchUsers(params);
    }, [page, rowsPerPage, searchTerm, roleFilter, subscriptionFilter, fetchUsers]);

    useEffect(() => {
        fetchUsersCallback();
    }, [fetchUsersCallback]);

    // search
    const handleSearchChange = (event) => {
        setSearchTerm(event.target.value);
        setPage(0);
    };

    const handleRoleFilterChange = (event) => {
        setRoleFilter(event.target.value);
        setPage(0);
    };

    // filter
    const handleSubscriptionFilterChange = (event) => {
        setSubscriptionFilter(event.target.value);
        setPage(0);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    }

    // open confirmation dialog
    const handleClickOpen = (userId) => {
        setSelectedUserId(userId);
        setOpen(true);
    };

    // close confirmation dialog
    const handleClose = () => {
        setOpen(false);
        setSelectedUserId(null);
    };

    const handleDelete = async () => {
        if (selectedUserId) {
            await deleteUser(selectedUserId);
            fetchUsersCallback();  //refresh after deletion
        }
        handleClose();
    }

    // navigate to user detail page
    const handleViewUser = (userId) => {
        navigate(`/admin/users/${userId}`);
    }

    return (
        <>
            <Paper sx={{ p: 3, borderRadius: 2, width: '100%' }}>
                <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', color: '#4b0082' }}>
                    User Management
                </Typography>

                <UserFilters
                    searchTerm={searchTerm}
                    handleSearchChange={handleSearchChange}
                    roleFilter={roleFilter}
                    handleRoleFilterChange={handleRoleFilterChange}
                    subscriptionFilter={subscriptionFilter}
                    handleSubscriptionFilterChange={handleSubscriptionFilterChange}
                />

                {loading ? (
                    <CircularProgress />
                ) : error ? (
                    <Alert severity="error">Error fetching users:{error}</Alert>
                ) : (
                    <>
                        <UserTable
                            users={users}
                            currentUser={currentUser}
                            handleViewUser={handleViewUser}
                            handleClickOpen={handleClickOpen}
                        />
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25]}
                            component="div"
                            count={totalUsers}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                        />
                    </>
                )}
            </Paper>

            <DeleteUserDialog
                open={open}
                handleClose={handleClose}
                handleDelete={handleDelete}
            />
        </>
    );
}