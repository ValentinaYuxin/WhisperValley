import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
    Typography,
    Box,
    CircularProgress,
    Alert,
    Grid,
} from '@mui/material';
import { useAdmin } from '../../hooks/useAdmin';
import UserBasicInfoCard from "../../components/Admin/Users/UserBasicInfoCard.jsx";
import UserCurrentSubCard from "../../components/Admin/Users/UserCurrentSubCard.jsx";
import UserSubHistoryCard from "../../components/Admin/Users/UserSubHistoryCard.jsx";
import EditUserModal from "../../components/Admin/Users/EditUserModal.jsx";

export default function AdminUserDetailPage() {
    const { userId } = useParams();
    const navigate = useNavigate();
    const {
        user, userSubscriptions, loading, error,
        fetchUserById, fetchUserSubscriptions, clearUser, updateUser,
    } = useAdmin();

    const [isEditModalOpen, setIsEditModalOpen] = useState(false);

    // edit handler
    const handleEditUser = () => {
        setIsEditModalOpen(true);
    };

    const handleCloseEditModal = () => {
        setIsEditModalOpen(false);
    };

    const handleSaveUser = async (id, formData) => {
        await updateUser(id, formData);
        setIsEditModalOpen(false);
        fetchUserById(id);
    };

    const handleGrantPremium = (id) => {
        console.log(`Grant premium to user with ID: ${id}`);
        // TODO: implement logic
    }

    const handleCancelSubscription = (id) => {
        console.log(`Cancel subscription for user with ID: ${id}`);
        // TODO: implement logic
    }

    useEffect(() => {
        if (userId) {
            fetchUserById(userId);
            fetchUserSubscriptions(userId);
        }
        return () => {
            clearUser(); // Clear user data when component unmounts or userId changes
        }
    }, [userId, fetchUserById, fetchUserSubscriptions, clearUser]);

    if (loading) return <CircularProgress />;

    if (error) return <Alert severity="error">Error fetching user details: {error}</Alert>;

    if (!user) return <Alert severity="info">User not found.</Alert>;

    return (
        <Box>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: "bold", color: "#4b0082", mb: 4 }}>
                User Details: {user.username}
            </Typography>

            <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                    <UserBasicInfoCard user={user} onEditUser={handleEditUser}/>
                </Grid>

                {user.role !== 'admin' && (
                    <Grid item xs={12} md={6}>
                        <UserCurrentSubCard
                            user={user}
                            // onGrantPremium={handleGrantPremium}
                            // onCancelSubscription={handleCancelSubscription}
                        />
                    </Grid>
                )}

                {user.role !== 'admin' && (
                    <Grid item xs={12}>
                        <UserSubHistoryCard userSubscriptions={userSubscriptions} />
                    </Grid>
                )}
            </Grid>

            {user && (
                <EditUserModal
                    open={isEditModalOpen}
                    onClose={handleCloseEditModal}
                    user={user}
                    onSave={handleSaveUser}
                    loading={loading}
                    error={error}
                />
            )}
        </Box>
    );
}

