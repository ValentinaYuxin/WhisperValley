import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import CssBaseline from "@mui/material/CssBaseline";
import Footer from "../components/Footer.jsx";
import Overview from "../components/HomePage/Overview.jsx";
import Features from "../components/HomePage/Features.jsx";
import Hero from "../components/HomePage/Hero.jsx";
import FAQ from "../components/HomePage/FAQ.jsx";
import Divider from "@mui/material/Divider";

export default function HomePage() {
  const location = useLocation();

  useEffect(() => {
    if (location.hash) {
      const element = document.getElementById(location.hash.replace("#", ""));
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: "smooth" });
        }, 100);
      }
    }
  }, [location.hash]);

  return (
    <>
      <CssBaseline />
      <Hero />
      <div id="overview">
        <Overview />
      </div>
      <div id="features">
        <Features />
      </div>
      <Divider />
      <div id="faq">
        <FAQ />
      </div>
      <Footer />
    </>
  );
}
