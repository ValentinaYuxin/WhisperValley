import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  CircularProgress,
  Typography,
  Button,
  Chip
} from "@mui/material";
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import Header from "../components/Header";
import ForumBackground from "../components/forum/ForumBackground";
import ForumContainer from "../components/forum/ForumContainer";
import ForumHeader from "../components/forum/ForumHeader";
import ForumPostList from "../components/forum/ForumPostList";
import ForumSearchBar from "../components/forum/ForumSearchBar";
import DatePeriodFilter from "../components/forum/DatePeriodFilter";
import ForumTagFilter from "../components/forum/ForumTagFilter";
import { useForum } from "../hooks/useForum";
import ForumEmptyState from "../components/forum/ForumEmptyState";
import ForumErrorAlert from "../components/forum/ForumErrorAlert";
import ForumLoading from "../components/forum/ForumLoading";
import EmotionLabelFilter from "../components/forum/EmotionLabelFilter";
import ForumPagination from "../components/forum/ForumPagination";

const EMOTION_LABELS = ['Happy', 'Sad', 'Angry', 'Excited', 'Bored'];
const EmotionLabelFilterComponent = ({ selected, onSelect }) => (
  <Box mb={2}>
    <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
      Filter by Emotion
    </Typography>
    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
      {EMOTION_LABELS.map(label => (
        <Chip
          key={label}
          label={label}
          color="default"
          onClick={() => onSelect(selected === label ? null : label)}
          sx={{
            fontWeight: 500,
            bgcolor: selected === label ? '#9c27b0' : undefined,
            color: selected === label ? '#fff' : undefined,
            '&:hover': selected === label ? { bgcolor: '#8e24aa' } : undefined
          }}
        />
      ))}
    </Box>
  </Box>
);

export default function Forum() {
  const navigate = useNavigate();
  const {
    posts,
    allTags,
    totalPages,
    totalItems,
    currentPage,
    itemsPerPage,
    searchQuery,
    selectedTags,
    isLoading,
    error,
    fetchPosts,
    fetchAllTags,
    handlePageChange,
    handleSearch,
    handleTagSelect,
    setSearchQuery,
    period,
    setPeriod,
    customRange,
    setCustomRange,
    handlePostClick,
    resetFilters,
    selectedEmotion,
    setSelectedEmotion
  } = useForum();

  useEffect(() => {
    fetchPosts({
      searchQuery,
      tags: selectedTags,
      period,
      customRange,
      emotionLabel: selectedEmotion,
      page: currentPage,
      limit: itemsPerPage
    });
  }, [searchQuery, selectedTags, period, customRange, selectedEmotion, currentPage, itemsPerPage, fetchPosts]);

  const hasMore = currentPage < totalPages;

  return (
    <>
      <Header />
      <ForumBackground>
        <ForumContainer>
          {/* Create New Post Button */}
          <Box display="flex" justifyContent="flex-end" mb={2}>
            <Button
              variant="contained"
              color="secondary"
              onClick={() => navigate("/forum/newPost")}
              sx={{ fontWeight: 600 }}
            >
              Create New Post
            </Button>
          </Box>
          <ForumHeader totalItems={totalItems} />
          <Box sx={{ p: 2 }}>
            <ForumSearchBar
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              onSearch={handleSearch}
            />
            <DatePeriodFilter
              period={period}
              setPeriod={setPeriod}
              customRange={customRange}
              setCustomRange={setCustomRange}
              posts={posts}
            />
            <EmotionLabelFilter
              selected={selectedEmotion}
              onSelect={setSelectedEmotion}
            />
            <ForumTagFilter
              tags={allTags}
              selectedTags={selectedTags}
              onTagSelect={handleTagSelect}
            />
            <Box display="flex" justifyContent="flex-end" mb={2}>
              <Button
                variant="outlined"
                color="primary"
                size="small"
                onClick={resetFilters}
                sx={{
                  minWidth: 0,
                  borderRadius: '50% 50% 0 0',
                  width: 36,
                  height: 36,
                  p: 0,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: 1,
                  borderTopLeftRadius: 18,
                  borderTopRightRadius: 18,
                  borderBottomLeftRadius: 0,
                  borderBottomRightRadius: 0,
                  ml: 1,
                  color: '#9c27b0',
                  borderColor: '#9c27b0',
                  '&:hover': {
                    borderColor: '#7B1FA2',
                    backgroundColor: '#F3E5F5',
                    color: '#7B1FA2'
                  }
                }}
                title="Reset Filters"
              >
                <RestartAltIcon fontSize="small" />
              </Button>
            </Box>
            <ForumLoading isLoading={isLoading} />
            <ForumPostList
              posts={posts}
              onTagSelect={handleTagSelect}
              onPostClick={handlePostClick}
              isLoading={isLoading}
            />
            <ForumPagination
              totalPages={totalPages}
              currentPage={currentPage}
              onPageChange={(page) => {
                fetchPosts({
                  searchQuery,
                  tags: selectedTags,
                  period,
                  customRange,
                  emotionLabel: selectedEmotion,
                  page,
                  limit: itemsPerPage
                });
              }}
            />
            <ForumEmptyState show={!isLoading && (!posts || posts.length === 0)} />
          </Box>
        </ForumContainer>
      </ForumBackground>
    </>
  );
}
