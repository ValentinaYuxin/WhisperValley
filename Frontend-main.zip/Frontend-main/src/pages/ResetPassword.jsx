import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import {
  TextField,
  Button,
  Typography,
  Box,
  Alert,
  CssBaseline,
  Card as MuiCard,
  Stack,
  FormLabel,
  FormControl,
} from "@mui/material";
import { styled } from "@mui/material/styles";

// Styled card for the form container
const Card = styled(MuiCard)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  alignSelf: "center",
  width: "100%",
  padding: theme.spacing(4),
  gap: theme.spacing(2),
  margin: "auto",
  [theme.breakpoints.up("sm")]: {
    maxWidth: "450px",
  },
  boxShadow:
    "hsla(220, 30%, 5%, 0.05) 0px 5px 15px 0px, hsla(220, 25%, 10%, 0.05) 0px 15px 35px -5px",
}));

// Background container with gradient
const ResetPasswordContainer = styled(Stack)(({ theme }) => ({
  position: "relative",
  height: "100dvh",
  minHeight: "100%",
  padding: theme.spacing(2),
  [theme.breakpoints.up("sm")]: {
    padding: theme.spacing(4),
  },
  "&::before": {
    content: '""',
    display: "block",
    position: "absolute",
    zIndex: -1,
    inset: 0,
    backgroundImage:
      "radial-gradient(ellipse at 50% 50%, hsl(210, 100%, 97%), hsl(0, 0%, 100%))",
    backgroundRepeat: "no-repeat",
  },
}));

export default function ResetPassword() {
  // Get token from URL params
  const { resettoken } = useParams();
  const navigate = useNavigate();

  // State variables for form fields and errors
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [passwordError, setPasswordError] = useState(false);
  const [passwordErrorMessage, setPasswordErrorMessage] = useState("");
  const [confirmPasswordError, setConfirmPasswordError] = useState(false);
  const [confirmPasswordErrorMessage, setConfirmPasswordErrorMessage] =
    useState("");
  const [globalError, setGlobalError] = useState("");
  const [success, setSuccess] = useState("");

  // Validate inputs before submission
  const validateInputs = () => {
    let isValid = true;

    setPasswordError(false);
    setPasswordErrorMessage("");
    setConfirmPasswordError(false);
    setConfirmPasswordErrorMessage("");
    setGlobalError("");

    if (!password) {
      setPasswordError(true);
      setPasswordErrorMessage("Password is required.");
      isValid = false;
    } else if (password.length < 8) {
      setPasswordError(true);
      setPasswordErrorMessage("Password must be at least 8 characters long.");
      isValid = false;
    }

    if (!confirmPassword) {
      setConfirmPasswordError(true);
      setConfirmPasswordErrorMessage("Confirm password is required.");
      isValid = false;
    }

    if (password && confirmPassword && password !== confirmPassword) {
      setPasswordError(true);
      setConfirmPasswordError(true);
      setPasswordErrorMessage("Passwords do not match.");
      setConfirmPasswordErrorMessage("Passwords do not match.");
      isValid = false;
    }

    return isValid;
  };

  // Submit new password to the backend
  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!validateInputs()) return;

    setSuccess("");

    try {
      const response = await axios.put(
        `http://localhost:8080/api/v1/auth/resetpassword/${resettoken}`,
        {
          password: password,
        }
      );

      setSuccess(
        response.data.message || "Password has been reset successfully!"
      );
      alert(
        "Password reset successful! You can now log in with your new password."
      );
      navigate("/SignIn");
    } catch (e) {
      console.error("Password reset failed:", e.response?.data || e.message);

      if (e.response?.data?.error) {
        const msg = e.response.data.error;

        if (msg.includes("password")) {
          setPasswordError(true);
          setPasswordErrorMessage(msg);
          setConfirmPasswordError(true);
          setConfirmPasswordErrorMessage(msg);
        } else {
          setGlobalError(msg);
        }
      } else {
        setGlobalError(
          "Failed to reset password. The link might be invalid or expired."
        );
      }
    }
  };

  return (
    <>
      <CssBaseline />
      <ResetPasswordContainer direction="column" justifyContent="center">
        <Card variant="outlined">
          <Typography
            component="h1"
            variant="h4"
            sx={{ width: "100%", fontSize: "clamp(2rem, 10vw, 2.15rem)" }}
          >
            Reset Password
          </Typography>

          {/* Form */}
          <Box
            component="form"
            onSubmit={handleSubmit}
            noValidate
            sx={{
              display: "flex",
              flexDirection: "column",
              width: "100%",
              gap: 2,
            }}
          >
            {/* New password field */}
            <FormControl>
              <FormLabel htmlFor="password">New Password</FormLabel>
              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                placeholder="••••••••"
                type="password"
                id="password"
                autoComplete="new-password"
                autoFocus
                error={passwordError}
                helperText={passwordErrorMessage}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </FormControl>

            {/* Confirm password field */}
            <FormControl>
              <FormLabel htmlFor="confirmPassword">
                Confirm New Password
              </FormLabel>
              <TextField
                margin="normal"
                required
                fullWidth
                name="confirmPassword"
                placeholder="••••••••"
                type="password"
                id="confirmPassword"
                autoComplete="new-password"
                error={confirmPasswordError}
                helperText={confirmPasswordErrorMessage}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </FormControl>

            {/* Submit button */}
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Reset Password
            </Button>

            {/* Success or error messages */}
            {success && <Alert severity="success">{success}</Alert>}
            {globalError && <Alert severity="error">{globalError}</Alert>}
          </Box>
        </Card>
      </ResetPasswordContainer>
    </>
  );
}
