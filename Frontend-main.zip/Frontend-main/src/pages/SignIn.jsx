import * as React from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  TextField,
  Button,
  Typography,
  Box,
  Checkbox,
  FormLabel,
  FormControl,
  FormControlLabel,
  Link,
  Divider,
  Stack,
  CssBaseline,
  Card as MuiCard,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import ForgotPassword from "../components/ForgetPassword.jsx";
import { useUser } from "../hooks/useRedux";
import { loginUser } from "../store/slices/userSlice";
import { useEffect } from "react";

// Load token from storage on page load if already available
const savedToken =
  localStorage.getItem("token") || sessionStorage.getItem("token");
if (savedToken) {
  axios.defaults.headers.common["Authorization"] = `Bearer ${savedToken}`;
}

// Styled card component for login form
const Card = styled(MuiCard)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  alignSelf: "center",
  width: "100%",
  padding: theme.spacing(4),
  gap: theme.spacing(2),
  margin: "auto",
  [theme.breakpoints.up("sm")]: {
    maxWidth: "450px",
  },
  boxShadow:
    "hsla(277, 66.90%, 23.70%, 0.72) 0px 5px 15px 0px, hsla(297, 65.30%, 28.20%, 0.44) 0px 15px 35px -5px",
}));

// Styled background container for the sign-in page
const SignInContainer = styled(Stack)(({ theme }) => ({
  position: "relative",
  height: "100dvh",
  minHeight: "100%",
  padding: theme.spacing(2),
  [theme.breakpoints.up("sm")]: {
    padding: theme.spacing(4),
  },
  "&::before": {
    content: '""',
    display: "block",
    position: "absolute",
    zIndex: -1,
    inset: 0,
    backgroundImage: 'url("/Signbg.png")',
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
  },
}));

export default function SignIn() {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");

  const [rememberMe, setRememberMe] = React.useState(
    localStorage.getItem("rememberMe") === "true"
  );

  const [open, setOpen] = React.useState(false);
  const handleClickOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const [loginErrorMessage, setLoginErrorMessage] = React.useState("");

  const navigate = useNavigate();
  const { login, resetUserState } = useUser();

  // Reset Redux states (loading/error) when entering the SignIn page
  React.useEffect(() => {
    resetUserState();
  }, [resetUserState]);

  const validateInputs = () => {
    let isValid = true;

    const allowedDomains = ["@mytum.de", "@tum.de", "@campus.lmu.de"];
    const hasValidDomain = allowedDomains.some((domain) =>
      email.toLowerCase().endsWith(domain)
    );

    if (!email || !/\S+@\S+\.\S+/.test(email) || !hasValidDomain) {
      setLoginErrorMessage(
        "Please use your student email (for example: @tum.de, @mytum.de or @campus.lmu.de)."
      );
      isValid = false;
    } else if (!password) {
      setLoginErrorMessage("Password is required.");
      isValid = false;
    } else if (password.length < 8) {
      setLoginErrorMessage("Password must be at least 8 characters long.");
      isValid = false;
    }

    return isValid;
  };

  useEffect(() => {
    if (loginErrorMessage) {
      const timer = setTimeout(() => {
        setLoginErrorMessage("");
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [loginErrorMessage]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoginErrorMessage(""); // clear previous error
    if (!validateInputs()) return;

    try {
      const result = await login({ email, password, rememberMe });

      if (loginUser.fulfilled.match(result)) {
        const loggedInUser = result.payload.user;
        if (loggedInUser.role === "admin") {
          navigate("/admin/dashboard");
        } else {
          navigate("/");
        }
      } else {
        setLoginErrorMessage(
          "Login failed. Please check your email and password."
        );
      }
    } catch (e) {
      console.error("Login exception:", e);
      setLoginErrorMessage(
        "Login failed. Please check your email and password."
      );
    }
  };

  return (
    <>
      <CssBaseline />
      <SignInContainer direction="column" justifyContent="space-between">
        <Card variant="outlined">
          <Typography
            component="h1"
            variant="h4"
            sx={{ width: "100%", fontSize: "clamp(2rem, 10vw, 2.15rem)" }}
          >
            Sign in
          </Typography>

          {loginErrorMessage && (
            <Typography sx={{ color: "error.main", textAlign: "center" }}>
              {loginErrorMessage}
            </Typography>
          )}

          <Box
            component="form"
            onSubmit={handleSubmit}
            noValidate
            sx={{
              display: "flex",
              flexDirection: "column",
              width: "100%",
              gap: 2,
            }}
          >
            <FormControl>
              <FormLabel htmlFor="email">Email</FormLabel>
              <TextField
                id="email"
                type="email"
                name="email"
                placeholder="your@email.com"
                autoComplete="email"
                autoFocus
                required
                fullWidth
                variant="outlined"
                color="secondary"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </FormControl>

            <FormControl>
              <FormLabel htmlFor="password">Password</FormLabel>
              <TextField
                name="password"
                placeholder="••••••••"
                type="password"
                id="password"
                autoComplete="current-password"
                required
                fullWidth
                variant="outlined"
                color="secondary"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </FormControl>

            <FormControlLabel
              control={
                <Checkbox
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  color="secondary"
                />
              }
              label="Remember me"
            />

            <ForgotPassword open={open} handleClose={handleClose} />

            <Button
              type="submit"
              fullWidth
              color="secondary"
              variant="contained"
            >
              Sign in
            </Button>

            <Link
              component="button"
              type="button"
              onClick={handleClickOpen}
              variant="body2"
              color="secondary"
            >
              Forgot your password?
            </Link>
          </Box>

          <Divider>or</Divider>

          <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
            <Typography sx={{ textAlign: "center" }}>
              Don&apos;t have an account?{" "}
              <Link href="./SignUp" variant="body2" color="secondary">
                Sign up
              </Link>
            </Typography>
          </Box>
        </Card>
      </SignInContainer>
    </>
  );
}
