import React, { useEffect, useState } from "react";
import {
  Box,
  Container,
  Typography,
  CircularProgress,
  Fab,
  Tooltip,
  Chip,
  Card,
  CardContent,
  Button,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { API_URL } from "../config";

const emotionColors = {
  Enjoyment: "#4CAF50",
  Fear: "#9C27B0",
  Anger: "#F44336",
  Sadness: "#2196F3",
  Disgust: "#FF9800",
  Surprise: "#FFC107",
  Contempt: "#795548",
};

export default function JournalDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [journal, setJournal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchJournal = async () => {
      try {
        const res = await axios.get(`${API_URL}/premium/journals/${id}`, {
          withCredentials: true,
        });
        setJournal(res.data.journal);
      } catch (err) {
        setError("Failed to load journal.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchJournal();
  }, [id]);

  return (
    <Box
      sx={{
        minHeight: "100vh",
        backgroundImage: `url('${import.meta.env.BASE_URL}bg.png')`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
        pt: { xs: "110px", sm: "120px", md: "130px" },
        pb: "80px",
        px: { xs: 2, sm: 3, md: 4 },
      }}
    >
      <Container maxWidth="sm">
        {/* Top Button Row */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 2,
          }}
        >
          {/* Back to Overview Button */}
          <Button
            onClick={() => navigate("/journals")}
            startIcon={<ArrowBackIosNewIcon />}
            sx={{
              textTransform: "none",
              fontWeight: "bold",
              color: "secondary.main",
              backgroundColor: "#f3e8ff",
              borderRadius: "12px",
              px: 2.5,
              py: 0.8,
              fontSize: "0.95rem",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#e0d4f7",
              },
            }}
          >
            Back to Overview
          </Button>

          {/* Floating Add Button (moved inline) */}
          <Tooltip title="Create New Journal" arrow>
            <Fab
              color="secondary"
              onClick={() => navigate("/dailyjournal")}
              size="medium"
              sx={{
                boxShadow: "0 6px 12px rgba(0,0,0,0.2)",
                "&:hover": {
                  transform: "scale(1.1)",
                  boxShadow: "0 10px 18px rgba(0,0,0,0.3)",
                },
              }}
            >
              <AddIcon sx={{ fontSize: 26 }} />
            </Fab>
          </Tooltip>
        </Box>

        {/* Main content */}
        {loading ? (
          <Box display="flex" justifyContent="center" mt={4}>
            <CircularProgress />
          </Box>
        ) : error ? (
          <Typography color="error" align="center">
            {error}
          </Typography>
        ) : journal ? (
          <Card
            sx={{
              p: 4,
              mt: 2,
              borderRadius: 3,
              boxShadow: 5,
              bgcolor: "rgba(255, 255, 255, 0.85)",
            }}
          >
            <CardContent>
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                mb={2}
              >
                <Typography variant="h6">
                  {new Date(journal.createdAt).toLocaleDateString()}
                </Typography>

                {/* Emotion Labels */}
                <Box display="flex" gap={1} flexWrap="wrap">
                  {(Array.isArray(journal.emotionLabels)
                    ? journal.emotionLabels
                    : [journal.emotionLabels]
                  ).map((label, index) =>
                    label ? (
                      <Chip
                        key={`${label}-${index}`}
                        label={label}
                        sx={{
                          backgroundColor: emotionColors[label] || "grey",
                          color: "#fff",
                          fontWeight: 500,
                        }}
                      />
                    ) : null
                  )}
                </Box>
              </Box>

              {/* Questionnaire Scores */}
              <Typography variant="body1" gutterBottom>
                🧠 Motivation: {journal.questionaireScore?.[0] ?? "-"}
              </Typography>
              <Typography variant="body1" gutterBottom>
                🌈 Mood: {journal.questionaireScore?.[1] ?? "-"}
              </Typography>
              <Typography variant="body1" gutterBottom>
                🧍‍♀️ Connection: {journal.questionaireScore?.[2] ?? "-"}
              </Typography>

              {/* Optional Content */}
              <Typography variant="body2" mt={2}>
                {journal.content || "(No content)"}
              </Typography>
            </CardContent>
          </Card>
        ) : null}
      </Container>
    </Box>
  );
}
