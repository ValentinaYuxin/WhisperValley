import { useEffect, useState } from "react";
import {
  AppBar,
  Box,
  CssBaseline,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Button,
  Badge,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import CommentIcon from "@mui/icons-material/Comment";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import { useNavigate, useLocation } from "react-router-dom";
import { useNotifications } from "../hooks/useNotifications";
import ReceivedComments from "../components/Notification/ReceivedComments";
import ReceivedLikes from "../components/Notification/ReceivedLikes";

const drawerWidth = 240;

export default function Notification() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const query = new URLSearchParams(location.search);
  const tabFromQuery = query.get("tab") || "Received Comments";

  const [selectedMenu, setSelectedMenu] = useState(tabFromQuery);
  const navigate = useNavigate();
  const {
    unreadCountByType = { comment: 0, like: 0 },
    fetchUnreadCountByType,
    clearUnreadCountByType,
  } = useNotifications();

  useEffect(() => {
    setSelectedMenu(tabFromQuery);
  }, [tabFromQuery]);

  // Fetch unread counts when component mounts
  useEffect(() => {
    fetchUnreadCountByType();
  }, [fetchUnreadCountByType]);

  // Set up interval to refresh unread counts every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      fetchUnreadCountByType();
    }, 30000);

    return () => clearInterval(interval);
  }, [fetchUnreadCountByType]);

  const handleDrawerToggle = () => setMobileOpen(!mobileOpen);

  const handleMenuClick = (menu, type) => {
    setSelectedMenu(menu);
    navigate(`/notification?tab=${encodeURIComponent(menu)}`, {
      replace: true,
    });
    setMobileOpen(false); // close drawer on mobile

    // Clear unread count for the clicked type
    if (type) {
      clearUnreadCountByType(type);
    }
  };

  const menuItems = [
    {
      text: "Received Comments",
      icon: <CommentIcon />,
      unreadCount: unreadCountByType.comment,
      type: "comment",
    },
    {
      text: "Received Likes",
      icon: <ThumbUpIcon />,
      unreadCount: unreadCountByType.like,
      type: "like",
    },
  ];

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />

      <AppBar
        position="fixed"
        sx={{
          background: "linear-gradient(to right, #e1d5f5, #f3e8ff)",
          color: "#4b0082",
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
          boxShadow: "none",
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: "none" } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap fontWeight="bold">
            Notification Center
          </Typography>
        </Toolbar>
      </AppBar>

      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
        aria-label="notification folders"
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{ keepMounted: true }}
          sx={{
            display: { xs: "block", sm: "none" },
            "& .MuiDrawer-paper": { width: drawerWidth },
          }}
        >
          <DrawerContent
            selectedMenu={selectedMenu}
            onMenuClick={handleMenuClick}
            menuItems={menuItems}
          />
        </Drawer>

        <Drawer
          variant="permanent"
          sx={{
            display: { xs: "none", sm: "block" },
            "& .MuiDrawer-paper": { width: drawerWidth },
          }}
          open
        >
          <DrawerContent
            selectedMenu={selectedMenu}
            onMenuClick={handleMenuClick}
            menuItems={menuItems}
          />
        </Drawer>
      </Box>

      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          backgroundColor: "#fafafa",
          minHeight: "100vh",
        }}
      >
        <Toolbar />
        <Box
          sx={{
            backgroundColor: "#fff",
            borderRadius: 2,
            p: 4,
            boxShadow: 2,
            minHeight: "70vh",
          }}
        >
          {selectedMenu === "Received Comments" && <ReceivedComments />}
          {selectedMenu === "Received Likes" && <ReceivedLikes />}
        </Box>
      </Box>
    </Box>
  );
}

function DrawerContent({ selectedMenu, onMenuClick, menuItems }) {
  return (
    <Box sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <Box sx={{ px: 2, pt: 2 }}>
        <Button
          startIcon={<ArrowBackIosNewIcon fontSize="small" />}
          onClick={() => window.history.back()}
          sx={{
            alignSelf: "flex-start",
            mb: 1,
            color: "#4b0082",
            fontSize: 15,
            textTransform: "none",
          }}
        >
          Back
        </Button>
      </Box>
      <Divider />
      <List sx={{ mt: 3 }}>
        {menuItems.map(({ text, icon, unreadCount, type }) => (
          <ListItem key={text} disablePadding>
            <ListItemButton
              onClick={() => onMenuClick(text, type)}
              selected={selectedMenu === text}
              sx={{
                borderRadius: 2,
                mx: 1,
                my: 0.5,
                "&.Mui-selected": {
                  backgroundColor: "#e6d6fa",
                  "& .MuiListItemText-primary": {
                    color: "#4b0082",
                    fontWeight: "bold",
                  },
                  "& .MuiListItemIcon-root": { color: "#4b0082" },
                },
                "&:hover": { backgroundColor: "#f1e9ff" },
              }}
            >
              <ListItemIcon sx={{ color: "#4b0082" }}>
                <Badge
                  badgeContent={unreadCount}
                  color="error"
                  invisible={unreadCount === 0}
                  sx={{
                    "& .MuiBadge-badge": {
                      backgroundColor: "#f44336",
                      color: "white",
                      fontSize: "0.75rem",
                      minWidth: "18px",
                      height: "18px",
                    },
                  }}
                >
                  {icon}
                </Badge>
              </ListItemIcon>
              <ListItemText primary={text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );
}
