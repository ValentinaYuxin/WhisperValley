import React, { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header.jsx";
import HomePage from "./pages/HomePage.jsx";
import appRoutes from "./routes/AppRoutes.jsx";
import { useUser } from "./hooks/useRedux";
import { useNotifications } from "./hooks/useNotifications";
import axios from "axios";

const pagesWithoutHeader = [
  "/profile",
  "/notification",
  "/myengagements",
  "/admin",
];

function AppContent() {
  const location = useLocation();
  const { refreshUser, user, tokenData } = useUser();
  const { unreadCount, fetchUnreadCount } = useNotifications();

  const shouldShowHeader = !pagesWithoutHeader.some((path) =>
    location.pathname.startsWith(path)
  );

  useEffect(() => {
    if (user) {
      fetchUnreadCount();
    }
  }, [user, fetchUnreadCount]);

  useEffect(() => {
    if (tokenData?.token) {
      axios.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${tokenData.token}`;
      console.log(
        "axios default header set:",
        tokenData.token.substring(0, 10) + "..."
      );

      if (!user || !user.username) {
        console.log(
          "App.jsx: Detected valid tokenData, initiating refreshUser..."
        );
        refreshUser();
      }
    } else {
      delete axios.defaults.headers.common["Authorization"];
      console.log("axios default header cleared.");
    }
  }, [user, tokenData, refreshUser]);

  return (
    <>
      {shouldShowHeader && <Header unreadCount={unreadCount} />}
      <Routes>
        <Route path="/" element={<HomePage />} />
        {appRoutes}
      </Routes>
    </>
  );
}

export default function App() {
  return <AppContent />;
}
