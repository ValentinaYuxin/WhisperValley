import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { logout } from "./userSlice.js";

const API_URL = 'http://localhost:8080/api/v1';

const initialState = {
    current: null,
    history: [],
    details: null,  // store a specific sub fetched by ID
    invoices: [],
    loading: false,
    error: null,
    checkoutUrl: null,
};

// Helper function to get the token from the user slice
const getToken = (getState) => {
    const { user } = getState();
    return user?.tokenData?.token || null;
};


// Async Thunks
export const fetchCurrent = createAsyncThunk(
    'subscription/fetchCurrent',
    async (_, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) return rejectWithValue('No authentication token found, please login again');

        try {
            const response = await axios.get(`${API_URL}/subscriptions/current`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            return response.data.subscription;
        } catch (err) {
            return rejectWithValue(err.response?.data?.message || 'Failed to fetch current subscription');
        }
    }
);

export const fetchHistory = createAsyncThunk(
    'subscription/fetchHistory',
    async (_, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) return rejectWithValue('No authentication token found, please login again');

        try {
            const response = await axios.get(`${API_URL}/subscriptions/history`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            return response.data.history;
        } catch (err) {
            return rejectWithValue(err.response?.data?.message || 'Failed to fetch subscription history');
        }
    }
);

export const fetchById = createAsyncThunk(
    'subscription/fetchById',
    async (id, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) return rejectWithValue('No authentication token found, please login again');

        try {
            const response = await axios.get(`${API_URL}/subscriptions/${id}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            return response.data.subscription;
        } catch (err) {
            return rejectWithValue(err.response?.data?.message || 'Failed to fetch subscription by ID');
        }
    }
);

export const fetchInvoices = createAsyncThunk(
    'subscription/fetchInvoices',
    async (_, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) return rejectWithValue('No authentication token found, please login again');

        try {
            // from invoices endpoint not subscriptions
            const response = await axios.get(`${API_URL}/invoices`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            return response.data.invoices;
        } catch (err) {
            return rejectWithValue(err.response?.data?.message || 'Failed to fetch invoices');
        }
    }
);


export const startTrial = createAsyncThunk(
    'subscription/startTrial',
    async (_, { getState, rejectWithValue, dispatch }) => {
        const token = getToken(getState);
        if (!token) return rejectWithValue('No authentication token found, please login again');

        try {
            const response = await axios.post(`${API_URL}/subscriptions/trial`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            dispatch(fetchCurrent());
            return response.data.url;   // Checkout URL
        } catch (err) {
            return rejectWithValue(err.response?.data?.message || 'Failed to start trial');
        }
    }
);

export const upgrade = createAsyncThunk(
    'subscription/upgrade',
    async ({ billingCycle }, { getState, rejectWithValue, dispatch }) => {
        const token = getToken(getState);
        if (!token) return rejectWithValue('No authentication token found, please login again');

        try {
            const response = await axios.post(
                `${API_URL}/subscriptions/upgrade`,
                { billingCycle },
                { headers: { Authorization: `Bearer ${token}` } }
            );
            dispatch(fetchCurrent());
            return response.data.url;
        } catch (err) {
            return rejectWithValue(err.response?.data?.message || 'Failed to upgrade to premium directly');
        }
    }
);

export const cancelSubscription = createAsyncThunk(
    'subscription/cancelSubscription',
    async (_, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) return rejectWithValue('No authentication token found, please login again');

        const { subscription } = getState();
        const subscriptionId = subscription.current?.stripeSubscriptionId;

        if (!subscriptionId) return rejectWithValue('No active subscription ID found to cancel.');

        try {
            const response = await axios.post(
                `${API_URL}/subscriptions/cancel`,
                {subscriptionId},
                { headers: { Authorization: `Bearer ${token}` } }
            );
            console.log("Cancel subscription response:", response.data);
            return response.data.subscription;
        } catch (err) {
            console.error("Cancel subscription failed:", err.response?.data);
            return rejectWithValue(err.response?.data?.message || 'Failed to cancel subscription');
        }
    }
);

export const cancelImmediately = createAsyncThunk(
    'subscription/cancelImmediately',
    async (_, { getState, rejectWithValue, dispatch }) => {
        const token = getToken(getState);
        if (!token) return rejectWithValue('No authentication token found, please login again');

        try {
            const response = await axios.post(`${API_URL}/subscriptions/cancel-immediately`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            // fetch current subscription again to update state after immediate cancellation
            dispatch(fetchCurrent());
            return response.data.subscription;
        } catch (err) {
            return rejectWithValue(err.response?.data?.message || 'Failed to cancel subscription immediately');
        }
    }
);

export const changePlan = createAsyncThunk(
    'subscription/changePlan',
    async ({ subId, newPriceId }, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) return rejectWithValue('No authentication token found, please login again');

        try {
            const response = await axios.post(`${API_URL}/subscriptions/change-plan`, {subId, newPriceId}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            return response.data.subscription;
        } catch (err) {
            return rejectWithValue(err.response?.data?.message || 'Failed to change subscription plan');
        }
    }
);


// Slice
const subSlice = createSlice({
    name: 'subscription',
    initialState,
    reducers: {
        clearCheckoutUrl(state) {
            state.checkoutUrl = null;
        },
        clearError(state) {
            state.error = null;
        }
    },
    extraReducers: builder => {
        builder
            // fetchCurrent
            .addCase(fetchCurrent.pending, state => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchCurrent.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.current = payload;
            })
            .addCase(fetchCurrent.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            // fetchHistory
            .addCase(fetchHistory.pending, state => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchHistory.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.history = payload;
            })
            .addCase(fetchHistory.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            // fetch by subscription id
            .addCase(fetchById.pending, state => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchById.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.detail = payload;
            })
            .addCase(fetchById.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            // fetch invoices
            .addCase(fetchInvoices.pending, state => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchInvoices.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.invoices = payload;
            })
            .addCase(fetchInvoices.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            // upgrade directly from free to premium without trial
            .addCase(upgrade.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(upgrade.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.checkoutUrl = payload?.url || null;
            })
            .addCase(upgrade.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload || 'Upgrade failed';
            })

            // change plan
            .addCase(changePlan.pending, state => {
                state.loading = true;
                state.error = null;
            })
            .addCase(changePlan.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.current = payload;
            })
            .addCase(changePlan.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            // cancel at period end
            .addCase(cancelSubscription.pending, state => {
                state.loading = true;
                state.error = null;
            })
            .addCase(cancelSubscription.fulfilled, (state, { payload }) => {
                state.current = payload;
                state.loading = false;
            })
            .addCase(cancelSubscription.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            // cancel immediately
            .addCase(cancelImmediately.pending, state => {
                state.loading = true; state.error = null;
            })
            .addCase(cancelImmediately.fulfilled, (state, { payload }) => {
                state.current = null;  // back to free
                state.history.unshift(payload);
                state.loading = false;
            })
            .addCase(cancelImmediately.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            // clear all sub data when user logs out
            .addCase(logout, () => initialState)

            // startTrial & upgrade (both return checkoutUrl)
            .addMatcher(
                action => [startTrial.fulfilled.type, upgrade.fulfilled.type].includes(action.type),
                (state, { payload }) => {
                    state.checkoutUrl = payload;
                    state.loading = false;
                }
            )
            .addMatcher(
                action => [startTrial.pending.type, upgrade.pending.type].includes(action.type),
                state => {
                    state.loading = true;
                    state.error = null;
                }
            )
            .addMatcher(
                action => [startTrial.rejected.type, upgrade.rejected.type].includes(action.type),
                (state, { payload }) => {
                    state.loading = false;
                    state.error = payload;
                }
            )

    }
});

export const { clearCheckoutUrl, clearError } = subSlice.actions;
export default subSlice.reducer;