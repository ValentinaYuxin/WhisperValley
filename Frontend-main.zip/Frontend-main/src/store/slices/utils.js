import { fetchCurrent } from "./subSlice.js";

export const dispatchFetchCurrent = () => (dispatch) => {
    dispatch(fetchCurrent());
}