import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import { dispatchFetchCurrent } from './utils.js';

const API_URL = 'http://localhost:8080/api/v1';

// Retrieve token from localStorage or sessionStorage and decode it
const getUserFromStorage = () => {
  const token = localStorage.getItem('token') || sessionStorage.getItem('token');
  if (token) {
    try {
      const decoded = jwtDecode(token);
      // Check if the token has not expired
      if (decoded.exp * 1000 > Date.now()) {
        console.log("Token from storage is valid.");
        return { id: decoded.id || decoded._id, token };
      } else {
        // If expired, clear stored token
        console.warn("Token from storage expired. Clearing.");
        localStorage.removeItem('token');
        sessionStorage.removeItem('token');
        delete axios.defaults.headers.common['Authorization'];
      }
    } catch (error) {
      // If invalid token, clear stored token
      console.error('Invalid token from storage:', error);
      localStorage.removeItem('token');
      sessionStorage.removeItem('token');
      delete axios.defaults.headers.common['Authorization'];
    }
  }
  return null;
};

const initialState = {
  user: null,           
  tokenData: getUserFromStorage(), 
  subscription: null,
  loading: false,
  error: null,
};

// Fetch user info using token and id
export const fetchUserInfo = createAsyncThunk(
  'user/fetchUserInfo',
  async ({ token, id }, { dispatch, rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_URL}/users/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      return { user: response.data.data, token };
    } catch (err) {
      return rejectWithValue(err.response?.data?.error || 'Failed to fetch user info');
    }
  }
);

// Login user
export const loginUser = createAsyncThunk(
  'user/login',
  async ({ email, password, rememberMe }, { dispatch, rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${API_URL}/auth/login`,
        { email, password },
        { withCredentials: true }
      );
      const token = response.data.token;
      if (!token) return rejectWithValue('No token received');

      // Save token depending on rememberMe
      if (rememberMe) {
        localStorage.setItem('token', token);
        localStorage.setItem('rememberMe', 'true');
      } else {
        sessionStorage.setItem('token', token);
        localStorage.setItem('rememberMe', 'false');
      }

      // Decode token to get user id
      const decoded = jwtDecode(token);
      const tokenData = { token, id: decoded.id || decoded._id };

      // Temporarily set user with tokenData
      dispatch(setUser({ tokenData: tokenData, user: null }));

      // Fetch full user info
      const userInfoAction = await dispatch(fetchUserInfo({ token: tokenData.token, id: tokenData.id }));
      if (fetchUserInfo.rejected.match(userInfoAction)) {
        return rejectWithValue(userInfoAction.payload);
      }

      // Fetch current subscription or other current data
      await dispatch(dispatchFetchCurrent());
      return { token, user: userInfoAction.payload.user };
    } catch (err) {
      return rejectWithValue(err.response?.data?.error || 'Login failed');
    }
  }
);

// Register user
export const registerUser = createAsyncThunk(
  'user/register',
  async ({ username, email, password }, { dispatch, rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${API_URL}/auth/register`,
        { username, email, password },
        { withCredentials: true }
      );

      const token = response.data.token;
      if (!token) return rejectWithValue('No token received');

      // Save token to sessionStorage by default
      sessionStorage.setItem('token', token);
      localStorage.setItem('rememberMe', 'false');
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

      // Decode and fetch user info
      const decoded = jwtDecode(token);
      const userInfoAction = await dispatch(fetchUserInfo({ token, id: decoded.id || decoded._id }));
      if (fetchUserInfo.rejected.match(userInfoAction)) {
        return rejectWithValue(userInfoAction.payload);
      }

      await dispatch(dispatchFetchCurrent());
      return { token, user: userInfoAction.payload.user };
    } catch (err) {
      return rejectWithValue(err.response?.data?.error || 'Registration failed');
    }
  }
);

// Update user profile
export const updateUserProfile = createAsyncThunk(
  'user/updateUserProfile',
  async ({ formData, id, token, isUsernameChanged }, { rejectWithValue }) => {
    try {
      // Update profile fields
      await axios.put(`${API_URL}/users/${id}`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data'
        }
      });

      // If username changed, subtract points
      if (isUsernameChanged) {
        await axios.post(
          `${API_URL}/users/points/subtract`,
          { pointsToSubtract: 1 },
          { headers: { Authorization: `Bearer ${token}` } }
        );
      }

      // Get updated user info
      const updatedUser = await axios.get(`${API_URL}/users/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      return updatedUser.data.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.error || 'Failed to update profile.');
    }
  }
);

// Change password
export const changePassword = createAsyncThunk(
  'user/changePassword',
  async ({ currentPassword, newPassword, token }, { rejectWithValue }) => {
    try {
      await axios.put(
        `${API_URL}/auth/updatepassword`,
        { currentPassword, newPassword },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      // success: no payload needed
      return 'Password updated successfully';
    } catch (err) {
    
      if (
        err.response?.status === 401 &&
        (err.response?.data?.error?.toLowerCase().includes('token') ||
         err.response?.data?.error?.toLowerCase().includes('jwt'))
      ) {
        return rejectWithValue('__TOKEN_EXPIRED__');
      }
     
      return rejectWithValue(
        err.response?.data?.error || 'Failed to update password'
      );
    }
  }
);

// Slice
const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    // Clear user state and remove tokens
    logout: (state) => {
      state.user = null;
      state.tokenData = null;
      state.error = null;
      localStorage.removeItem('token');
      localStorage.removeItem('rememberMe');
      sessionStorage.removeItem('token');
      delete axios.defaults.headers.common['Authorization'];
    },
    // Clear error state
    clearError: (state) => {
      state.error = null;
    },
    // Reset loading and error
    resetLoginState: (state) => {
      state.loading = false;
      state.error = null;
    },
    // Set user manually
    setUser: (state, action) => {
      state.tokenData = action.payload.tokenData;
      state.user = action.payload.user;
    },
    // Update user info only
    updateUser: (state, action) => {
      state.user = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      // Login
      .addCase(loginUser.pending, (state) => { state.loading = true; state.error = null; })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload.user;
        state.tokenData = { id: action.payload.user._id, token: action.payload.token };
        if (action.payload.rememberMe) { // Assuming loginUser payload includes rememberMe
          localStorage.setItem('token', action.payload.token);
        } else {
          sessionStorage.setItem('token', action.payload.token);
        }
        axios.defaults.headers.common['Authorization'] = `Bearer ${action.payload.token}`;
        state.error = null;
      })
      .addCase(loginUser.rejected, (state, action) => { state.loading = false; state.error = action.payload; })

      // Register
      .addCase(registerUser.pending, (state) => { state.loading = true; state.error = null; })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload.user;
        state.tokenData = { id: action.payload.user._id, token: action.payload.token };
        state.error = null;
      })
      .addCase(registerUser.rejected, (state, action) => { state.loading = false; state.error = action.payload; })

      // Fetch user info
      .addCase(fetchUserInfo.pending, (state) => { state.loading = true; state.error = null; })
      .addCase(fetchUserInfo.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload.user;
        state.error = null;
      })
      .addCase(fetchUserInfo.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      
        if (
          typeof action.payload === 'string' &&
          (action.payload.toLowerCase().includes('token') ||
           action.payload.toLowerCase().includes('jwt'))
        ) {
          state.user = null;
          state.tokenData = null;
          localStorage.removeItem('token');
          sessionStorage.removeItem('token');
          delete axios.defaults.headers.common['Authorization'];
        }
      })

      // Update user profile
      .addCase(updateUserProfile.pending, (state) => { state.loading = true; state.error = null; })
      .addCase(updateUserProfile.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload;
        state.error = null;
      })
      .addCase(updateUserProfile.rejected, (state, action) => { state.loading = false; state.error = action.payload; });
  },
});

export const { logout, clearError, resetLoginState, setUser, updateUser } = userSlice.actions;
export default userSlice.reducer;
