import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const API_URL = 'http://localhost:8080/api/v1/admin';

const getToken = (getState) => {
    const state = getState();
    return state.user?.tokenData?.token || null;
};

const initialState = {
    stats: null,
    users: [],
    totalUsers: 0,  // For pagination
    user: null, // New state for single user
    userSubscriptions: [],
    reports: [],
    totalReports: 0,
    reportedItems: [],
    pendingReportsCount: 0,
    contactMessages: [],
    totalMessages: 0,  // For pagination
    loading: false,
    error: null,
};


export const fetchDashboardStats = createAsyncThunk(
    'admin/fetchDashboardStats',
    async (_, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.get(`${API_URL}/dashboard-stats`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data.data;
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to fetch dashboard stats');
        }
    }
);


export const fetchUsers = createAsyncThunk(
    'admin/fetchUsers',
    async (params = {}, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.get(`${API_URL}/users`, {
                headers: { Authorization: `Bearer ${token}` },
                params,
            });
            return response.data;  // TODO: check
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to fetch users');
        }
    }
);

export const deleteUser = createAsyncThunk(
    'admin/deleteUser',
    async (userId, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            await axios.delete(`${API_URL}/users/${userId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return userId; // Return the user ID for successful deletion
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to delete user');
        }
    }
);

export const fetchUserById = createAsyncThunk(
    'admin/fetchUserById',
    async (userId, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.get(`${API_URL}/users/${userId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data; // Return the user data
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to fetch user details');
        }
    }
);

export const fetchUserSubscriptions = createAsyncThunk(
    'admin/fetchUserSubscriptions',
    async (userId, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.get(`${API_URL}/users/${userId}/subscriptions`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data; // Return the user's subscriptions
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to fetch user subscriptions');
        }
    }
);

export const updateUser = createAsyncThunk(
    'admin/updateUser',
    async ({ userId, userData }, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.put(`${API_URL}/users/${userId}`, userData, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data.data; // Return the updated user data // TODO: check
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to update user');
        }
    }
);

export const fetchReports = createAsyncThunk(
    'admin/fetchReports',
    async (params = {}, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.get(`${API_URL}/reports`, {
                headers: { Authorization: `Bearer ${token}` },
                params,
            });
            return response.data; // Expecting { data: reports, totalReports: count }
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to fetch reports');
        }
    }
);

export const updateReportStatus = createAsyncThunk(
    'admin/updateReportStatus',
    async ({ reportId, status }, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.put(`${API_URL}/reports/${reportId}/status`, { status }, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data.data; // Return the updated report data
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to update report status');
        }
    }
);

export const getReportedItem = createAsyncThunk(
    'admin/getReportedItem',
    async (reportId, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.get(`${API_URL}/reports/${reportId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data; // Return the reported item data
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to fetch reported item');
        }
    }
);

export const deleteReport = createAsyncThunk(
    'admin/deleteReport',
    async (reportId, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            await axios.delete(`${API_URL}/reports/${reportId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return reportId;
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to delete report');
        }
    }
);

export const deletePostByAdmin = createAsyncThunk(
    'admin/deletePostByAdmin',
    async (postId, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            await axios.delete(`${API_URL}/posts/${postId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return postId;
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to delete post');
        }
    }
);

export const deleteCommentByAdmin = createAsyncThunk(
    'admin/deleteCommentByAdmin',
    async (postId, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            await axios.delete(`${API_URL}/commentss/${commentId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return commentId;
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to delete comment');
        }
    }
);


export const fetchPendingReportsCount = createAsyncThunk(
    'admin/fetchPendingReportsCount',
    async (_, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.get(`${API_URL}/reports/pending-count`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data.count;  // Return the count
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to fetch pending reports count');
        }
    }
);


export const fetchContactMessages = createAsyncThunk(
    'admin/fetchContactMessages',
    async (params, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.get(`${API_URL}/contact-messages`, {
                headers: { Authorization: `Bearer ${token}` },
                params
            });
            return response.data;  // Return an array of contact messages
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to fetch contact messages');
        }
    }
);

export const deleteContactMessage = createAsyncThunk(
    'admin/deleteContactMessage',
    async (messageId, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            await axios.get(`${API_URL}/contact-messages/${messageId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return messageId;  // Return an array of contact messages
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to delete contact message');
        }
    }
);

export const updateContactMessageStatus = createAsyncThunk(
    'admin/updateContactMessageStatus',
    async ({ messageId, status }, { getState, rejectWithValue }) => {
        const token = getToken(getState);
        if (!token) {
            return rejectWithValue('No authentication token found');
        }

        try {
            const response = await axios.put(`${API_URL}/contact-messages/${messageId}/status`, {status}, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data.data;  // Return the updated contact message
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Failed to update contact message status');
        }
    }
);


const adminSlice = createSlice({
    name: "admin",
    initialState,
    reducers: {
        clearError: (state) => {
            state.error = null;
        },
        clearUser: (state) => {
            state.user = null;
        },
        clearReportedItem: (state) => {
            state.reportedItem = null;
        }
    },
    extraReducers: (builder) => {
        builder
            // 1. Dashboard Stats
            .addCase(fetchDashboardStats.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchDashboardStats.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.stats = {
                    ...payload,
                    users: {
                        ...payload.users,
                        newLast30DaysDaily: payload.users.newLast30DaysDaily || [],
                    },
                    subscriptions: {
                        byStatus: payload.subscriptions.byStatus || {},
                        byPlan: payload.subscriptions.byPlan || {},
                    },
                };
            })
            .addCase(fetchDashboardStats.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            // 2. Users Management
            .addCase(fetchUsers.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchUsers.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.users = payload.data;
                state.totalUsers = payload.totalUsers;
            })
            .addCase(fetchUsers.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            .addCase(deleteUser.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(deleteUser.fulfilled, (state, { payload: userId }) => {
                state.loading = false;
                if (state.users) {
                    state.users = state.users.filter((user) => user._id !== userId);
                }
            })
            .addCase(deleteUser.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            .addCase(fetchUserById.pending, (state) => {
                state.loading = true;
                state.error = null;
                state.user = null; // Reset user state
            })
            .addCase(fetchUserById.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.user = payload;
            })
            .addCase(fetchUserById.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
                state.user = null;
            })

            .addCase(fetchUserSubscriptions.pending, (state) => {
                state.loading = true;
                state.error = null;
                state.userSubscriptions = [];
            })
            .addCase(fetchUserSubscriptions.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.userSubscriptions = payload;
            })
            .addCase(fetchUserSubscriptions.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
                state.userSubscriptions = [];
            })

            .addCase(updateUser.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(updateUser.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.user = payload;  // update single user in state

                if (state.users) {  // update user in the users list
                    const index = state.users.findIndex(u => u._id === payload._id);

                    if (index !== -1) {
                        state.users[index] = payload;
                    }
                }
            })
            .addCase(updateUser.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })


            // 3. Reports Management
            .addCase(fetchReports.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchReports.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.reports = payload.data;
                state.totalReports = payload.totalReports;
            })
            .addCase(fetchReports.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            .addCase(updateReportStatus.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(updateReportStatus.fulfilled, (state, { payload }) => {
                state.loading = false;
                if (state.reports) {
                    const index = state.reports.findIndex(report => report._id === payload._id);
                    if (index !== -1) {
                        state.reports[index] = payload; // Update the report in the array
                    }
                }
            })
            .addCase(updateReportStatus.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            .addCase(getReportedItem.pending, (state) => {
                state.loading = true;
                state.error = null;
                state.reportedItem = null; // Reset reported item state
            })
            .addCase(getReportedItem.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.reportedItem = payload;
            })
            .addCase(getReportedItem.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
                state.reportedItem = null;
            })

            .addCase(fetchPendingReportsCount.pending, (state) => {
                state.error = null;
            })
            .addCase(fetchPendingReportsCount.fulfilled, (state, { payload }) => {
                state.pendingReportsCount = payload;
            })
            .addCase(fetchPendingReportsCount.rejected, (state, { payload }) => {
                state.error = payload;
                state.pendingReportsCount = 0;
            })

            .addCase(deleteReport.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(deleteReport.fulfilled, (state, { payload: reportId }) => {
                state.loading = false;
                if (state.reports) {
                    state.reports = state.reports.filter((report) => report._id !== reportId);
                    state.totalReports -= 1;
                }
            })
            .addCase(deleteReport.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            .addCase(deletePostByAdmin.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(deletePostByAdmin.fulfilled, (state, { payload: postId }) => {
                if (state.reports) {
                    state.loading = false;
                    state.reports = state.reports.filter(report => !(report.targetType === 'post' && report.targetId === postId));
                    state.totalReports = state.reports.length;
                }
            })
            .addCase(deletePostByAdmin.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })

            .addCase(deleteCommentByAdmin.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(deleteCommentByAdmin.fulfilled, (state, { payload: commentId }) => {
                state.loading = false;
                if (state.reports) {
                    state.reports = state.reports.filter(report => !(report.targetType === 'comment' && report.targetId === commentId));
                    state.totalReports = state.reports.length;
                }
            })
            .addCase(deleteCommentByAdmin.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })




            // 4. Contact messages management
            .addCase(fetchContactMessages.pending, (state) => {
                state.loading = false;
                state.error = null;
            })
            .addCase(fetchContactMessages.fulfilled, (state, { payload}) => {
                state.loading = false;
                state.contactMessages = payload.data || [];
                state.totalMessages = payload.totalMessages || 0;
            })
            .addCase(fetchContactMessages.rejected, (state, { payload}) => {
                state.loading = false;
                state.error = payload;
            })

            .addCase(deleteContactMessage.pending, (state) => {
                state.loading = false;
                state.error = null;
            })
            .addCase(deleteContactMessage.fulfilled, (state, {payload: messageId }) => {
                state.loading = false;
                if (state.contactMessages) {
                    state.contactMessages = state.contactMessages.filter((message) => message._id !== messageId);
                }
            })
            .addCase(deleteContactMessage.rejected, (state, { payload}) => {
                state.loading = false;
                state.error = payload;
            })

            .addCase(updateContactMessageStatus.pending, (state) => {
                state.loading = false;
                state.error = null;
            })
            .addCase(updateContactMessageStatus.fulfilled, (state, {payload }) => {
                state.loading = false;
                if (state.contactMessages) {  // update in the array
                    const index = state.contactMessages.findIndex(message => message._id === payload._id);
                    if (index !== -1) {
                        state.contactMessages[index] = payload;
                    }
                }
            })
            .addCase(updateContactMessageStatus.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            });

    },
});

export const {clearError, clearUser, clearReportedItem} = adminSlice.actions;
export default adminSlice.reducer;