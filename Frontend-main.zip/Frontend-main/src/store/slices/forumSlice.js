import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const API_URL = 'http://localhost:8080/api/v1';

// Async thunks
export const fetchPosts = createAsyncThunk(
  'forum/fetchPosts',
  async ({ page = 1, limit = 10, searchQuery = '', tags = [], period = '', customRange, emotionLabel }, { rejectWithValue }) => {
    try {
      const params = {
        page,
        limit,
        search: searchQuery,
        period,
      };
      if (tags && tags.length > 0) params.tags = tags.join(',');
      if (period === 'custom' && customRange && customRange.start && customRange.end) {
        params.start = customRange.start;
        params.end = customRange.end;
      }
      // Add emotionLabel filter if provided
      if (emotionLabel && (Array.isArray(emotionLabel) ? emotionLabel.length > 0 : true)) {
        params.emotionLabel = Array.isArray(emotionLabel) ? emotionLabel.join(',') : emotionLabel;
      }
      const response = await axios.get(`${API_URL}/posts`, {
        params,
        withCredentials: true
      });
      
      // Log the entire response for debugging
      console.log('Posts API response:', {
        data: response.data,
        isPaginated: response.data && response.data.pagination,
        status: response.status,
        headers: response.headers
      });
      
      return response.data;
    } catch (error) {
      console.error('Error fetching posts:', error);
      return rejectWithValue(error.response?.data?.error || 'Failed to fetch posts');
    }
  }
);

export const fetchPostById = createAsyncThunk(
  'forum/fetchPostById',
  async (postId, { rejectWithValue }) => {
    try {
      console.log('Fetching post by ID:', postId);
      const response = await axios.get(`${API_URL}/posts/${postId}`, { withCredentials: true });
      console.log('Post API response:', response.data);
      
      // Make sure we have a valid response
      if (!response.data) {
        throw new Error('Empty response from server');
      }
      
      return response.data;
    } catch (error) {
      console.error('Error fetching post by ID:', error);
      return rejectWithValue(error.response?.data?.error || error.message || 'Failed to fetch post');
    }
  }
);

export const createPost = createAsyncThunk(
  'forum/createPost',
  async (postData, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_URL}/posts`, postData, {
        withCredentials: true
      });
      return response.data;
    } catch (error) {
      console.error('Error creating post:', error.response?.data);
      return rejectWithValue(error.response?.data?.error || 'Failed to create post');
    }
  }
);

export const fetchComments = createAsyncThunk(
  'forum/fetchComments',
  async ({ postId, page = 1, limit = 10 }, { rejectWithValue }) => {
    try {
      // Make sure postId is a valid string
      if (!postId || typeof postId !== 'string') {
        console.error('Invalid postId:', postId);
        return rejectWithValue('Invalid post ID');
      }
      
      console.log('Fetching comments for post:', postId, 'page:', page, 'limit:', limit);
      const response = await axios.get(`${API_URL}/comments/post/${postId}`, { 
        params: { page, limit },
        withCredentials: true 
      });
      console.log('Comments API response:', response.data);
      return response.data;
    } catch (error) {
      console.error('Error fetching comments:', error);
      return rejectWithValue(error.response?.data?.error || 'Failed to fetch comments');
    }
  }
);

export const createComment = createAsyncThunk(
  'forum/createComment',
   async ({ postId, content, parentComment = null }, { rejectWithValue }) => {
    try {
      // Send parentComment in the payload if present
      const payload = { content };
      if (parentComment) payload.parentComment = parentComment;
      const response = await axios.post(
        `${API_URL}/comments/${postId}`,
        payload,
        { withCredentials: true }
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.error || 'Failed to add comment');
    }
  }
);

export const fetchAllTags = createAsyncThunk(
  'forum/fetchAllTags',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_URL}/posts/tags`, { withCredentials: true });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.error || 'Failed to fetch tags');
    }
  }
);

// Modify this thunk to use the right parameter name
export const likePost = createAsyncThunk(
  'forum/likePost',
  async (postId, { rejectWithValue }) => {
    try {
      console.log('Sending like request for post:', postId);
      // Change targetID to match the parameter name in your routes
      const response = await axios.post(`${API_URL}/likes/posts/${postId}/like`, {}, { 
        withCredentials: true 
      });
      console.log('Like response:', response.data);
      return { postId, ...response.data };
    } catch (error) {
      console.error('Error liking post:', error);
      return rejectWithValue(error.response?.data?.error || 'Failed to like post');
    }
  }
);

// And also add a likeComment function
export const likeComment = createAsyncThunk(
  'forum/likeComment',
  async (commentId, { getState, rejectWithValue }) => {
    try {
      const token = getState().user?.tokenData?.token;
      const response = await axios.post(
        `${API_URL}/likes/comments/${commentId}/like`,
        {},
        {
          withCredentials: true,
          headers: token ? { Authorization: `Bearer ${token}` } : {},
        }
      );
      return { commentId, ...response.data };
    } catch (error) {
      return rejectWithValue(error.response?.data?.error || 'Failed to like comment');
    }
  }
);

export const deletePost = createAsyncThunk(
  'forum/deletePost',
  async (postId, { rejectWithValue }) => {
    try {
      const response = await axios.delete(`${API_URL}/posts/${postId}`, { withCredentials: true });
      return { postId };
    } catch (error) {
      return rejectWithValue(error.response?.data?.error || 'Failed to delete post');
    }
  }
);

export const updatePost = createAsyncThunk(
  'forum/updatePost',
  async ({ postId, postData }, { rejectWithValue }) => {
    try {
      const response = await axios.put(`${API_URL}/posts/${postId}`, postData, { withCredentials: true });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.error || 'Failed to update post');
    }
  }
);

export const deleteComment = createAsyncThunk(
  'forum/deleteComment',
  async ({ postId, commentId }, { rejectWithValue }) => {
    try {
      const response = await axios.delete(`${API_URL}/comments/${postId}/delete/${commentId}`, { withCredentials: true });
      return { commentId };
    } catch (error) {
      return rejectWithValue(error.response?.data?.error || 'Failed to delete comment');
    }
  }
);

export const updateComment = createAsyncThunk(
  'forum/updateComment',
  async ({ postId, commentId, content }, { rejectWithValue }) => {
    try {
      const response = await axios.patch(`${API_URL}/comments/${postId}/update/${commentId}`, { content }, { withCredentials: true });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.error || 'Failed to update comment');
    }
  }
);

// --- Report Post/Comment ---
export const reportContent = createAsyncThunk(
  'forum/reportContent',
  async ({ targetType, targetId, reason }, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${API_URL}/reports`,
        { targetType, targetId, reason },
        { withCredentials: true }
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.error || 'Failed to report content');
    }
  }
);

// Initial state
const initialState = {
  posts: [],
  currentPost: null,
  comments: [],
  repliesByCommentId: {}, // { [parentCommentId]: [reply1, reply2, ...] }
  allTags: [],
  totalPages: 0,
  totalItems: 0,
  currentPage: 1,
  itemsPerPage: 10,
  searchQuery: '',
  selectedTags: [],
  // General status
  status: 'idle', // 'idle' | 'loading' | 'succeeded' | 'failed'
  error: null,
  // Granular loading/error states
  isFetchingPosts: false,
  isFetchingPost: false,
  isCreatingPost: false,
  isUpdatingPost: false,
  isDeletingPost: false,
  isFetchingComments: false,
  isCreatingComment: false,
  isUpdatingComment: false,
  isDeletingComment: false,
  commentsPagination: null, // { totalPages, currentPage, totalItems, itemsPerPage }
  isReporting: false,
  reportError: null,
  reportSuccess: false,
};

// Create the slice
const forumSlice = createSlice({
  name: 'forum',
  initialState,
  reducers: {
    setSearchQuery: (state, action) => {
      state.searchQuery = action.payload;
    },
    setSelectedTags: (state, action) => {
      state.selectedTags = action.payload;
    },
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    resetForumState: () => initialState,
    clearCurrentPost: (state) => {
      state.currentPost = null;
      state.comments = [];
      state.commentsPagination = null;
      state.isFetchingComments = false;
      state.isCreatingComment = false;
      state.isUpdatingComment = false;
      state.isDeletingComment = false;
      state.error = null;
    },
    postCreated: (state, action) => {
      state.status = 'succeeded';
      state.posts = [action.payload, ...state.posts];
      state.error = null;
    },
    setLoading: (state, action) => {
      state.isFetchingPosts = action.payload;
    },
    setStatus: (state, action) => {
      state.status = action.payload;
    },
    setError: (state, action) => {
      state.status = 'failed';
      state.error = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Posts
      .addCase(fetchPosts.pending, (state) => {
        state.isFetchingPosts = true;
        state.status = 'loading';
        state.error = null;
      })
      .addCase(fetchPosts.fulfilled, (state, action) => {
        state.isFetchingPosts = false;
        state.status = 'succeeded';
        // Handle array response format (for backward compatibility)
        if (Array.isArray(action.payload)) {
            console.log('Array format detected - converting to paginated format');
            // Convert to paginated format
            state.posts = action.payload;
            state.totalPages = 1;
            state.totalItems = action.payload.length;
            state.currentPage = 1;
            state.itemsPerPage = action.payload.length;
        } 
        // Handle paginated response object (new format)
        else if (action.payload && action.payload.posts) {
            console.log('Paginated format detected');
            state.posts = action.payload.posts;
            // Get pagination info from response
            if (action.payload.pagination) {
              state.totalPages = action.payload.pagination.totalPages || 1;
              state.currentPage = action.payload.pagination.currentPage || 1;
              state.totalItems = action.payload.pagination.totalItems || 0;
              state.itemsPerPage = action.payload.pagination.itemsPerPage || 10;
              // Log pagination details for debugging
              console.log('Pagination data received:', action.payload.pagination);
            } else {
              state.totalPages = 1;
              state.totalItems = state.posts.length;
              console.warn('No pagination data in response');
            }
        } 
        // Fallback to empty array if response format is unrecognized
        else {
            console.warn('Unrecognized posts response format - using empty array');
            state.posts = [];
            state.totalPages = 0;
            state.totalItems = 0;
        }
        state.error = null;
      })
      .addCase(fetchPosts.rejected, (state, action) => {
        state.isFetchingPosts = false;
        state.status = 'failed';
        state.error = action.payload;
      })
      // Fetch Post By Id
      .addCase(fetchPostById.pending, (state) => {
        state.isFetchingPost = true;
        state.status = 'loading';
        state.error = null;
      })
      .addCase(fetchPostById.fulfilled, (state, action) => {
        state.isFetchingPost = false;
        state.status = 'succeeded';
        if (action.payload && action.payload.post) {
          state.currentPost = action.payload.post;
        } else if (action.payload && typeof action.payload === 'object') {
          state.currentPost = action.payload;
        } else {
          state.currentPost = null;
        }
        state.error = null;
      })
      .addCase(fetchPostById.rejected, (state, action) => {
        state.isFetchingPost = false;
        state.status = 'failed';
        state.error = action.payload;
      })
      // Create Post
      .addCase(createPost.pending, (state) => {
        state.isCreatingPost = true;
        state.status = 'loading';
        state.error = null;
      })
      .addCase(createPost.fulfilled, (state, action) => {
        state.isCreatingPost = false;
        state.status = 'succeeded';
        state.posts.unshift(action.payload);
        state.error = null;
      })
      .addCase(createPost.rejected, (state, action) => {
        state.isCreatingPost = false;
        state.status = 'failed';
        state.error = action.payload;
      })
      // Update Post
      .addCase(updatePost.pending, (state) => {
        state.isUpdatingPost = true;
        state.status = 'loading';
        state.error = null;
      })
      .addCase(updatePost.fulfilled, (state, action) => {
        state.isUpdatingPost = false;
        state.status = 'succeeded';
        state.posts = state.posts.map(post =>
          post._id === action.payload._id ? action.payload : post
        );
        if (state.currentPost && state.currentPost._id === action.payload._id) {
          state.currentPost = action.payload;
        }
        state.error = null;
      })
      .addCase(updatePost.rejected, (state, action) => {
        state.isUpdatingPost = false;
        state.status = 'failed';
        state.error = action.payload;
      })
      // Delete Post
      .addCase(deletePost.pending, (state) => {
        state.isDeletingPost = true;
        state.status = 'loading';
        state.error = null;
      })
      .addCase(deletePost.fulfilled, (state, action) => {
        state.isDeletingPost = false;
        state.status = 'succeeded';
        state.posts = state.posts.filter(post => post._id !== action.payload.postId);
        if (state.currentPost && state.currentPost._id === action.payload.postId) {
          state.currentPost = null;
        }
        state.error = null;
      })
      .addCase(deletePost.rejected, (state, action) => {
        state.isDeletingPost = false;
        state.status = 'failed';
        state.error = action.payload;
      })
      // Fetch Comments
      .addCase(fetchComments.pending, (state) => {
        state.isFetchingComments = true;
        state.status = 'loading';
        state.error = null;
      })
      .addCase(fetchComments.fulfilled, (state, action) => {
        state.isFetchingComments = false;
        state.status = 'succeeded';
        if (Array.isArray(action.payload)) {
          state.comments = action.payload;
          state.commentsPagination = null;
        } else if (action.payload && action.payload.comments) {
          state.comments = action.payload.comments;
          state.commentsPagination = action.payload.pagination || null;
        } else {
          state.comments = [];
          state.commentsPagination = null;
        }
        state.error = null;
      })
      .addCase(fetchComments.rejected, (state, action) => {
        state.isFetchingComments = false;
        state.status = 'failed';
        state.error = action.payload;
      })
      // Create Comment
      .addCase(createComment.pending, (state) => {
        state.isCreatingComment = true;
        state.error = null;
      })
      .addCase(createComment.fulfilled, (state, action) => {
        state.isCreatingComment = false;
        const comment = action.payload?.comment || action.payload;
        if (comment.parentComment) {
          const parentId = comment.parentComment;
          if (!state.repliesByCommentId[parentId]) {
            state.repliesByCommentId[parentId] = [];
          }
          state.repliesByCommentId[parentId].push(comment);
        } else {
          state.comments.push(comment);
        }
        state.error = null;
      })
      .addCase(createComment.rejected, (state, action) => {
        state.isCreatingComment = false;
        state.error = action.payload;
      })
      // Update Comment
      .addCase(updateComment.pending, (state) => {
        state.isUpdatingComment = true;
        state.error = null;
      })
      .addCase(updateComment.fulfilled, (state, action) => {
        state.isUpdatingComment = false;
        const updated = action.payload?.comment || action.payload;
        if (updated.parentComment) {
          const parentId = updated.parentComment;
          state.repliesByCommentId[parentId] = state.repliesByCommentId[parentId]?.map(reply =>
            reply._id === updated._id ? updated : reply
          );
        } else {
          state.comments = state.comments.map(comment =>
            comment._id === updated._id ? updated : comment
          );
        }
        state.error = null;
      })
      .addCase(updateComment.rejected, (state, action) => {
        state.isUpdatingComment = false;
        state.error = action.payload;
      })
      // Delete Comment
      .addCase(deleteComment.pending, (state) => {
        state.isDeletingComment = true;
        state.error = null;
      })
      .addCase(deleteComment.fulfilled, (state, action) => {
        state.isDeletingComment = false;
        const { commentId, parentComment } = action.payload;
        if (parentComment) {
          const parentId = parentComment;
          state.repliesByCommentId[parentId] = state.repliesByCommentId[parentId]?.filter(reply => reply._id !== commentId);
        } else {
          state.comments = state.comments.filter(comment => comment._id !== commentId);
        }
        state.error = null;
      })
      .addCase(deleteComment.rejected, (state, action) => {
        state.isDeletingComment = false;
        state.error = action.payload;
      })
      // Like Post
      .addCase(likePost.fulfilled, (state, action) => {
        const { postId, likeCount, liked } = action.payload;
        const postIndex = state.posts.findIndex(post => post._id === postId);
        if (postIndex !== -1) {
          state.posts[postIndex].likeCount = likeCount;
          state.posts[postIndex].isLiked = liked;
        }
        if (state.currentPost && state.currentPost._id === postId) {
          state.currentPost.likeCount = likeCount;
          state.currentPost.isLiked = liked;
        }
      })
      // Like Comment
      .addCase(likeComment.fulfilled, (state, action) => {
        const { commentId, likeCount, liked } = action.payload;
        const commentIndex = state.comments.findIndex(comment => comment._id === commentId);
        if (commentIndex !== -1) {
          state.comments[commentIndex].likeCount = likeCount;
          state.comments[commentIndex].isLiked = liked;
        }
      })
      // Fetch All Tags
      .addCase(fetchAllTags.fulfilled, (state, action) => {
        state.allTags = action.payload.tags;
      })
      // Report Content
      .addCase(reportContent.pending, (state) => {
        state.isReporting = true;
        state.reportError = null;
        state.reportSuccess = false;
      })
      .addCase(reportContent.fulfilled, (state, action) => {
        state.isReporting = false;
        state.reportSuccess = true;
        state.reportError = null;
      })
      .addCase(reportContent.rejected, (state, action) => {
        state.isReporting = false;
        state.reportError = action.payload;
        state.reportSuccess = false;
      });
  },
});

// Export actions and reducer
export const { 
  setSearchQuery, 
  setSelectedTags, 
  setCurrentPage, 
  resetForumState,
  clearCurrentPost,
  postCreated,
  setLoading,
  setStatus,
  setError,
} = forumSlice.actions;

export default forumSlice.reducer;