import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const API_URL = 'http://localhost:8080/api/v1';

// fetch unread count
export const fetchUnreadCount = createAsyncThunk(
  'notifications/fetchUnreadCount',
  async (_, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      const res = await axios.get(`${API_URL}/notifications/unread-count`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      return res.data.success ? res.data.data.unreadCount : 0;
    } catch {
      return rejectWithValue(0);
    }
  }
);

// fetch unread count by type
export const fetchUnreadCountByType = createAsyncThunk(
  'notifications/fetchUnreadCountByType',
  async (_, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      const [commentRes, likeRes] = await Promise.all([
        axios.get(`${API_URL}/notifications/unread-count?type=comment`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
        axios.get(`${API_URL}/notifications/unread-count?type=like`, {
          headers: { Authorization: `Bearer ${token}` },
        })
      ]);
      
      return {
        comment: commentRes.data.success ? commentRes.data.data.unreadCount : 0,
        like: likeRes.data.success ? likeRes.data.data.unreadCount : 0,
      };
    } catch {
      return rejectWithValue({ comment: 0, like: 0 });
    }
  }
);

// fetch notifications (with pagination & type)
export const fetchNotifications = createAsyncThunk(
  'notifications/fetchNotifications',
  async ({ page = 1, limit = 10, type }, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      const params = { page, limit };
      if (type) params.type = type;
      const res = await axios.get(`${API_URL}/notifications`, {
        headers: { Authorization: `Bearer ${token}` },
        params,
      });
      if (res.data.success) return res.data;
      return rejectWithValue(res.data.message || 'Failed to fetch notifications');
    } catch (err) {
      return rejectWithValue(err.response?.data?.message || 'Failed to fetch notifications');
    }
  }
);

// mark all as read
export const markAllRead = createAsyncThunk(
  'notifications/markAllRead',
  async (type, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      await axios.post(`${API_URL}/notifications/mark-read`, { type }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      return { type };
    } catch (err) {
      return rejectWithValue(err.response?.data?.message || 'Failed to mark notifications as read');
    }
  }
);

const notificationsSlice = createSlice({
  name: 'notifications',
  initialState: {
    unreadCount: 0,
    unreadCountByType: { comment: 0, like: 0 },
    notifications: [],
    pagination: null,
    status: 'idle',
    error: null,
    lastUnreadIdsByType: { comment: [], like: [] },
  },
  reducers: {
    clearNotifications(state) {
      state.notifications = [];
      state.pagination = null;
      state.lastUnreadIdsByType = { comment: [], like: [] };
    },
    clearUnreadCountByType(state, action) {
      const type = action.payload;
      if (type === 'comment') {
        state.unreadCountByType.comment = 0;
      } else if (type === 'like') {
        state.unreadCountByType.like = 0;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUnreadCount.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchUnreadCount.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.unreadCount = action.payload;
      })
      .addCase(fetchUnreadCount.rejected, (state) => {
        state.status = 'failed';
      })
      .addCase(fetchUnreadCountByType.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchUnreadCountByType.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.unreadCountByType = action.payload;
      })
      .addCase(fetchUnreadCountByType.rejected, (state, action) => {
        state.status = 'failed';
        state.unreadCountByType = action.payload || { comment: 0, like: 0 };
      })
      .addCase(fetchNotifications.pending, (state) => {
        state.status = 'loading';
        state.error = null;
        // Ensure lastUnreadIdsByType is initialized on pending
        if (!state.lastUnreadIdsByType) {
          state.lastUnreadIdsByType = { comment: [], like: [] };
        }
      })
      .addCase(fetchNotifications.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
        // Ensure lastUnreadIdsByType is initialized on rejected
        if (!state.lastUnreadIdsByType) {
          state.lastUnreadIdsByType = { comment: [], like: [] };
        }
      })
      .addCase(fetchNotifications.fulfilled, (state, action) => {
        const type = action.meta.arg.type;
        state.status = 'succeeded';
        state.notifications = action.payload.data;
        state.pagination = action.payload.pagination;
        state.error = null;

        // Ensure lastUnreadIdsByType is initialized
        if (!state.lastUnreadIdsByType) {
          state.lastUnreadIdsByType = { comment: [], like: [] };
        }

        // collect unread ids for this batch BEFORE marking as read
        // This will be used to highlight notifications that were just marked as read
        state.lastUnreadIdsByType[type] = action.payload.data
          .filter((n) => n.isRead === false)
          .map((n) => n._id);
      })
      .addCase(markAllRead.fulfilled, (state, action) => {
        state.unreadCount = 0; // badge clear
        // Clear the specific type unread count
        const type = action.payload.type;
        if (type === 'comment') {
          state.unreadCountByType.comment = 0;
        } else if (type === 'like') {
          state.unreadCountByType.like = 0;
        }
        // Keep the lastUnreadIdsByType intact so components can still highlight them
        // The IDs in lastUnreadIdsByType represent notifications that were just marked as read
      });
  },
});

export const { clearNotifications, clearUnreadCountByType } = notificationsSlice.actions;
export default notificationsSlice.reducer;
