import { configureStore, combineReducers } from '@reduxjs/toolkit';
import { persistStore, persistReducer, FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER } from "redux-persist";
import storage from 'redux-persist/lib/storage';
import userReducer from './slices/userSlice';
import forumReducer from './slices/forumSlice';
import notificationsReducer from './slices/notificationsSlice';
import subReducer from './slices/subSlice';
import adminReducer from './slices/adminSlice';

const persistConfig = {
  key: 'root',
  storage,
  whitelist: ['user', 'forum', 'notifications', 'subscription'],
};

const rootReducer = combineReducers({
  user: userReducer,
  forum: forumReducer,
  notifications: notificationsReducer,
  subscription: subReducer,
  admin: adminReducer,
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({
    serializableCheck: {
      ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
    },
  }),
});

export const persistor = persistStore(store);

