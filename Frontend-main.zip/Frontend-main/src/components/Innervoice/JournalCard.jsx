import React, { useState } from "react";
import {
  Card,
  CardContent,
  Typography,
  IconButton,
  Box,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Button,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const emotionColors = {
  Enjoyment: "#4CAF50",
  Fear: "#9C27B0",
  Anger: "#F44336",
  Sadness: "#2196F3",
  Disgust: "#FF9800",
  Surprise: "#FFC107",
  Contempt: "#795548",
};

// Format date time to yyyy-mm-dd HH:mm
const formatDateTime = (dateString) => {
  const date = new Date(dateString);
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  const hour = `${date.getHours()}`.padStart(2, "0");
  const minute = `${date.getMinutes()}`.padStart(2, "0");
  return `${year}-${month}-${day} ${hour}:${minute}`;
};

const JournalCard = ({ journal, onDelete }) => {
  const navigate = useNavigate();
  const [confirmOpen, setConfirmOpen] = useState(false);

  const openConfirmDialog = (e) => {
    e.stopPropagation();
    setConfirmOpen(true);
  };

  const closeConfirmDialog = (e) => {
    e?.stopPropagation?.();
    setConfirmOpen(false);
  };

  const handleDelete = async (e) => {
    e.stopPropagation();
    try {
      await axios.delete(
        `http://localhost:8080/api/v1/premium/journals/${journal._id}`,
        {
          withCredentials: true,
        }
      );
      onDelete(journal._id);
      setConfirmOpen(false);
    } catch (err) {
      console.error("Failed to delete journal:", err);
    }
  };

  const label = Array.isArray(journal.emotionLabels)
    ? journal.emotionLabels[0]
    : journal.emotionLabels;

  return (
    <Card
      variant="outlined"
      sx={{
        width: "100%",
        maxWidth: "720px",
        mx: "auto",
        mb: 2,
        px: 2,
        py: 2,
        borderRadius: 2,
        boxShadow: 3,
        backgroundColor: "rgba(255, 255, 255, 0.95)",
        transition: "transform 0.2s ease",
        "&:hover": {
          transform: "scale(1.01)",
        },
        cursor: "pointer",
        position: "relative",
        display: "flex",
        flexDirection: "column",
      }}
      onClick={() => navigate(`/journals/${journal._id}`)}
    >
      <CardContent>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h6">
            {formatDateTime(journal.createdAt)}
          </Typography>
          <Chip
            label={label}
            sx={{
              backgroundColor: emotionColors[label] || "grey",
              color: "#fff",
              fontWeight: 500,
              px: 1.5,
              py: 0.5,
              fontSize: "0.875rem",
              maxWidth: 120,
            }}
          />
        </Box>

        <Typography variant="body2" mt={1}>
          {journal.content?.length > 100
            ? journal.content.slice(0, 100) + "..."
            : journal.content || "(No content)"}
        </Typography>
      </CardContent>

      <Box sx={{ position: "absolute", bottom: 8, right: 8 }}>
        <IconButton onClick={openConfirmDialog}>
          <DeleteIcon color="error" />
        </IconButton>
      </Box>

      <Dialog open={confirmOpen} onClose={closeConfirmDialog}>
        <DialogTitle>Delete Journal</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete this journal entry? This action
            cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={closeConfirmDialog} color="inherit">
            Cancel
          </Button>
          <Button onClick={handleDelete} color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Card>
  );
};

export default JournalCard;
