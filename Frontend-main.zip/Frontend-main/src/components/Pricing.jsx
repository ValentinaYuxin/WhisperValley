import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  Chip,
  Container,
  Divider,
  Grid,
  Typography,
} from "@mui/material";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import { useNavigate } from "react-router-dom";
import { useUser } from "../hooks/useRedux.js";
import { useSubscription } from "../hooks/useSubscription.js";
import { useSnackbar } from "notistack";
import PricingFAQ from "./Pricing/PricingFAQ.jsx";
import PricingHeader from "./Pricing/PricingHeader.jsx";

// 2 subscription plans: free, premium
const tiers = [
  {
    title: "Free",
    price: "0",
    description: [
      "Access to anonymous forum",
      "Connect with a supportive community",
      "Share experiences confidentially",
    ],
    buttonVariant: "outlined",
    planId: "free-plan",
    plan: 'free',
  },
  {
    title: "Premium",
    subheader: "Recommended",
    price: "4.99",
    description: [
      "All Free feature included",
      "Mood questionnaires",
      "Unlimited emotion journaling",
      "Tag-based emotion tracking",
      "Smart emotional trend insights",
      "Immediate feedback & suggestions",
      "Privacy first principles",
    ],
    buttonVariant: "contained",
    planId: "premium-plan",
    plan: 'premium',
  },
];

export default function Pricing() {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const { user } = useUser();

  const {
    current: subscription,
    loading,
    checkoutUrl,
    startTrial,
    upgrade,
    clearCheckoutUrl,
    hasHadTrialOrPremium,
    fetchHistory,
  } = useSubscription();

  useEffect(() => {  // TODO: check
    if (user) {
      fetchHistory();
    }
  }, [user, fetchHistory]);


  // check the latest user subs
  useEffect(() => {
    if (checkoutUrl) {
      window.location.href = checkoutUrl;
      clearCheckoutUrl();
    }
  }, [checkoutUrl, clearCheckoutUrl]);

  const handleChoosePlan = (planName) => {
    if (!user) {
      enqueueSnackbar("Please log in or register to continue.", {
        variant: "info",
      });
      navigate("/SignIn");
      return;
    }

    if (planName === "premium") {
      enqueueSnackbar("Redirecting to checkout...", {
        variant: "info",
      });

      if (hasHadTrialOrPremium) {
        upgrade("monthly");
      } else {
        startTrial();
      }
    }
  };

  const getButtonProps = (tier) => {
    if (loading) {
      return {
        text: "Loading...",
        onClick: () => {},
        disabled: true,
        variant: "contained",
        sx: { bgcolor: "#9c27b0", "&:hover": { bgcolor: "#7b1fa2" } },
      };
    }

    // user not logged in
    if (!user) {
      return {
        text: `Sign up for ${tier.title}`,
        onClick: () => handleChoosePlan(tier.plan),
        disabled: false,
        variant: tier.plan === "premium" ? "contained" : "outlined",
        sx: tier.plan === "premium"
            ? { bgcolor: "#590d82", "&:hover": { bgcolor: "#4a266a" } }
            : { color: "#590d82", borderColor: "#590d82" },
      };
    }

    // user logged in
    if (subscription?.plan === "premium") {
      if (tier.plan === "premium") {
        return {
          text: "Current Plan (Premium)",
          onClick: () => navigate("/Profile"),
          disabled: true,
          variant: "contained",
          sx: { bgcolor: "#9c27b0", "&:hover": { bgcolor: "#7b1fa2" } },
        };
      } else {
        return null;
      }
    }

    if (subscription?.status === "trialing") {
      if (tier.plan === "premium") {
        return {
          text: "Current Plan (Trial)",
          onClick: () => navigate("/Profile"),
          disabled: true,
          variant: "contained",
          sx: { bgcolor: "#9c27b0", "&:hover": { bgcolor: "#7b1fa2" } },
        };
      } else {
        return null;
      }
    }

    if (subscription?.plan === "free") {
      if (tier.plan === "premium") {
        if (hasHadTrialOrPremium) {
          return {
            text: "Already had a trial. Upgrade to Premium",
            onClick: () => handleChoosePlan(tier.plan),
            disabled: false,
            variant: "contained",
            sx: { bgcolor: "#590d82", "&:hover": { bgcolor: "#4a266a" } },
          };
        } else {
          return {
            text: "Start 7-day Free Trial",
            onClick: () => handleChoosePlan(tier.plan),
            disabled: false,
            variant: "contained",
            sx: { bgcolor: "#590d82", "&:hover": { bgcolor: "#4a266a" } },
          };
        }
      } else {
        return null;
      }
    }

    return {
      text: `Choose ${tier.title}`,
      onClick: () => handleChoosePlan(tier.plan),
      disabled: tier.plan !== "premium",
      variant: tier.plan === "premium" ? "contained" : "outlined",
      sx: tier.plan === "premium"
          ? { bgcolor: "#9c27b0", "&:hover": { bgcolor: "#7b1fa2" } }
          : { color: "#9c27b0", borderColor: "#9c27b0" },
    };
  };

  return (
    <Box
      id="pricing"
      sx={{
        pt: { xs: 6, sm: 16 },
        pb: { xs: 8, sm: 16 },
        color: "white",
        bgcolor: "#6d5b9b",
      }}
    >
      <Container
        maxWidth="xl"
        sx={{
          pb: { xs: 8, sm: 14 },
          position: "relative",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: { xs: 3, sm: 6 },
        }}
      >
        <PricingHeader user={user} subscription={subscription} />

        <Grid
          container
          spacing={6}
          sx={{ alignItems: "center", justifyContent: "center", width: "100%" }}
        >
          {tiers.map((tier) => {
            const buttonProps = getButtonProps(tier);

            return (
              <Grid
                item
                key={tier.title}
                xs={12}
                sm={6}
                md={6}
              >
                <Card
                  sx={[
                    {
                      p: 2,
                      display: "flex",
                      flexDirection: "column",
                      height: "100%",
                      gap: 4,
                      color: "#3D1F6C",
                      bgcolor: tier.title === "Free" ? "#d6c8ff" : null,
                    },
                    tier.title === "Premium" &&
                      ((theme) => ({
                        background:
                          "radial-gradient(circle at 50% 0%, #fef0ff, #d6c8ff)",
                        boxShadow: `0 8px 12px hsla(220, 20%, 42%, 0.2)`,
                      })),
                  ]}
                >
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Box
                      sx={{
                        mb: 2,
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        gap: 2,
                      }}
                    >
                      <Typography component="h3" variant="h3" sx={{ fontSize: 32, color: "#3D1F6C" }}>
                        {tier.title}
                      </Typography>
                      {tier.subheader && (
                        <Chip
                          sx={{ bgcolor: "#673ab7", color: "white" }}
                          label={tier.subheader}
                          size="small"
                        />
                      )}
                    </Box>

                    <Box
                      sx={{ display: "flex", alignItems: "baseline", mb: 2 }}
                    >
                      <Typography component="h3" variant="h2" sx={{ color: "#3D1F6C" }}>
                        €{tier.price}
                      </Typography>
                      <Typography component="h3" variant="h6" sx={{ color: "#3D1F6C" }}>
                        &nbsp; / month
                      </Typography>
                    </Box>

                    {tier.title === "Premium" && (
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "flex-end",
                          width: "100%",
                          mt: -1,
                        }}
                      >
                        <Typography
                          variant="subtitle2"
                          component="p"
                          sx={{
                            color: "#3D1F6C",
                            textAlign: "right",
                            fontSize: "1.1rem",
                          }}
                        >
                          or €49.99 / year (2 months free)
                        </Typography>
                      </Box>
                    )}

                    <Divider sx={{ mb: 2 }} />
                    {tier.description.map((line) => (
                      <Box
                        key={line}
                        sx={{ display: "flex", alignItems: "center", mb: 1 }}
                      >
                        <CheckCircleRoundedIcon
                          sx={{ color: "success.main", mr: 1, fontSize: 18 }}
                        />
                        <Typography variant="subtitle1" color="text.secondary">
                          {line}
                        </Typography>
                      </Box>
                    ))}
                  </CardContent>

                  <CardActions>
                    {buttonProps && (
                        <Button
                            fullWidth
                            variant={buttonProps.variant}
                            onClick={buttonProps.onClick}
                            disabled={buttonProps.disabled}
                            sx={buttonProps.sx}
                        >
                          {buttonProps.text}
                        </Button>
                    )}
                  </CardActions>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </Container>
      <PricingFAQ />
    </Box>
  );
}
