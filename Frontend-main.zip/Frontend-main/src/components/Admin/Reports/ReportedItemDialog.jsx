import React from "react";
import {
    Box,
    Typography,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
} from '@mui/material';
import dayjs from 'dayjs';
import { useNavigate } from 'react-router-dom';

const ReportedItemDialog = ({ open, handleClose, reportedItem, itemType, onDeleteItem}) => {
    const navigate = useNavigate();

    if (!reportedItem) return null;

    const handleViewInForum = () => {
        if (itemType === 'post') {
            navigate(`/forum/posts/${reportedItem._id}`, { state: { fromAdminReports: true } });
        } else if (itemType === 'comment') {
            navigate(`/forum/posts/${reportedItem.postId}#comment-${reportedItem._id}`, { state: { fromAdminReports: true } });
        }
        handleClose();
    }

    const handleDeleteClick = () => {
        onDeleteItem(reportedItem._id, itemType);
        handleClose();
    }

    return (
        <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
            <DialogTitle>Reported {itemType === 'post' ? 'Post' : 'Comment'} Details</DialogTitle>
            <DialogContent dividers>
                {itemType === 'post' ? (
                    <Box>
                        <Typography variant="h6">Post Content:</Typography>
                        <Typography variant="body1" sx={{ whiteSpace: 'pre-wrap' }}>{reportedItem.content}</Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                            Author: {reportedItem.user?.username || 'N/A'}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            Created At: {dayjs(reportedItem.createdAt).format('YYYY-MM-DD HH:mm')}
                        </Typography>
                    </Box>
                ) : (
                    <Box>
                        <Typography variant="h6">Comment Content:</Typography>
                        <Typography variant="body1" sx={{ whiteSpace: 'pre-wrap' }}>{reportedItem.content}</Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                            Author: {reportedItem.user?.username || 'N/A'}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            Created At: {dayjs(reportedItem.createdAt).format('YYYY-MM-DD HH:mm')}
                        </Typography>
                    </Box>
                )}
            </DialogContent>
            <DialogActions>
                <Button onClick={handleDeleteClick} color="error">
                    Delete {itemType === 'post' ? 'Post' : 'Comment'}
                </Button>
                <Button onClick={handleViewInForum} color="primary">
                    View in Forum
                </Button>
                <Button onClick={handleClose}>
                    Close
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default ReportedItemDialog;