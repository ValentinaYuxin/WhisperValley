import React from "react";
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Chip,
    Typography,
    Box,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityIcon from '@mui/icons-material/Visibility';
import dayjs from 'dayjs';

const ReportsTable = ({ reports, onView, onDelete, onUpdateStatus })=> {
    if (!reports || reports.length === 0) {
        return (
            <Box sx={{ mt: 2, p: 2, border: '1px dashed #ccc', borderRadius: 2, textAlign: 'center' }}>
                <Typography variant="body1" color="text.secondary\">
                    No reports found.
                </Typography>
            </Box>
        );
    }

    const getStatusChipStyle = (status) => {
        if (!status) return 'default';
        switch (status) {
            case 'pending':
                return { backgroundColor: '#521262', color: 'white' };
            case 'reviewed':
                return { backgroundColor: '#a6acec', color: 'white' };
            case 'dismissed':
                return { backgroundColor: '#c9d6df', color: 'white' };
            default:
                return { backgroundColor: '#9E9E9E', color: 'white' };
        }
    };

    return (
        <TableContainer>
            <Table sx={{ minWidth: 650 }} aria-label="reports table">
                <TableHead>
                    <TableRow>
                        <TableCell sx={{ fontWeight: 'bold' }}>Report ID</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Type</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Reason</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Reported By</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {reports.map((report) => (
                        <TableRow key={report._id}>
                            <TableCell>{report._id}</TableCell>
                            <TableCell>{report.targetType}</TableCell>
                            <TableCell>{report.reason}</TableCell>
                            <TableCell>{report.reportingUser?.username || 'N/A'}</TableCell>
                            <TableCell>
                                <FormControl variant="outlined" size="small" sx={{ minWidth: 120 }}>
                                    <InputLabel id={`status-select-label-${report._id}`}>Status</InputLabel>
                                    <Select
                                        labelId={`status-select-label-${report._id}`}
                                        id={`status-select-${report._id}`}
                                        value={report.status || 'pending'}
                                        onChange={(e) => onUpdateStatus(report._id, e.target.value)}
                                        renderValue={(selected) => (
                                            <Chip
                                                label={selected.
                                                toUpperCase()}
                                                size="small"
                                                sx={{ width: '100%', ...getStatusChipStyle(selected) }}
                                            />
                                        )}
                                        label='Status'
                                        variant='outlined'
                                    >
                                        <MenuItem value="pending">Pending</MenuItem>
                                        <MenuItem value="reviewed">Reviewed</MenuItem>
                                        <MenuItem value="dismissed">Dismissed</MenuItem>
                                    </Select>
                                </FormControl>
                            </TableCell>

                            <TableCell>
                                <IconButton sx={{ color: '#b9bbdf' }}
                                            onClick={()=> onView(report._id)}>
                                    <VisibilityIcon />
                                </IconButton>
                                <IconButton sx={{ color: '#7e6bc4' }}
                                            onClick={()=> onDelete(report._id)}>
                                    <DeleteIcon />
                                </IconButton>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default ReportsTable;