import React from 'react';
import {
    Typography,
    Card,
    CardContent,
    List,
    ListItem,
    ListItemText,
    Divider,
} from '@mui/material';
import SubscriptionsIcon from '@mui/icons-material/Subscriptions';
import dayjs from 'dayjs';

export default function UserSubscriptionHistoryCard({ userSubscriptions }) {
    return (
        <Card elevation={3}>
            <CardContent>
                <Typography variant="h5" gutterBottom sx={{ fontWeight: "bold", color: "#6d5b9b" }}>
                    Subscription History
                </Typography>

                {userSubscriptions && userSubscriptions.length > 0 ? (
                    <List>
                        {userSubscriptions.map((sub, index) => (
                            <React.Fragment key={sub._id}>
                                <ListItem>
                                    <SubscriptionsIcon sx={{ mr: 1, color: "#6d5b9b" }} />
                                    <ListItemText
                                        primary={`Plan: ${sub.plan} - Status: ${sub.status}`}
                                        secondary={
                                        `Start: ${dayjs(sub.startDate).format("YYYY-MM-DD")} 
                                        | End: ${sub.endDate ? dayjs(sub.endDate).format("YYYY-MM-DD") : 'N/A'}`
                                    }
                                    />
                                </ListItem>
                                {index < userSubscriptions.length - 1 && <Divider component="li" />}
                            </React.Fragment>
                        ))}
                    </List>
                ) : (
                    <Typography variant="body1">
                        No subscription history found for this user.
                    </Typography>
                )}
            </CardContent>
        </Card>
    );
}