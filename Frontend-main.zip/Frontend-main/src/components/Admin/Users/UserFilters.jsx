import React from 'react';
import {
    TextField,
    Grid,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
} from '@mui/material';

const UserFilters = ({
                         searchTerm,
                         handleSearchChange,
                         roleFilter,
                         handleRoleFilterChange,
                         subscriptionFilter,
                         handleSubscriptionFilterChange,
                     }) => {
    return (
        <Grid container justifyContent="flex-end" spacing={2} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={8} md={6} lg={4}>
                <Grid container spacing={2}>
                    <Grid item xs={12}>
                        <TextField
                            fullWidth
                            label="Search by ID, Username, Email"
                            variant="outlined"
                            value={searchTerm}
                            onChange={handleSearchChange}
                        />
                    </Grid>
                </Grid>
            </Grid>

            <Grid item xs={12} sm={4} md={3} lg={2}>
                <FormControl fullWidth variant="outlined">
                    <InputLabel>Role</InputLabel>
                    <Select
                        value={roleFilter}
                        onChange={handleRoleFilterChange}
                        label="Role"
                    >
                        <MenuItem value="all">All Roles</MenuItem>
                        <MenuItem value="user">User</MenuItem>
                        <MenuItem value="admin">Admin</MenuItem>
                    </Select>
                </FormControl>
            </Grid>

            <Grid item xs={12} sm={4} md={3} lg={2}>
                <FormControl fullWidth variant="outlined">
                    <InputLabel>Subscription</InputLabel>
                    <Select
                        value={subscriptionFilter}
                        onChange={handleSubscriptionFilterChange}
                        label="Subscription"
                    >
                        <MenuItem value="all">All Plans</MenuItem>
                        <MenuItem value="premium">Premium</MenuItem>
                        <MenuItem value="trialing">Trialing</MenuItem>
                        <MenuItem value="free">Free</MenuItem>
                    </Select>
                </FormControl>
            </Grid>
        </Grid>
    );
};

export default UserFilters;