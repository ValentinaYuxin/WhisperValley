import React from 'react';
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Button,
    Chip,
} from '@mui/material';
import dayjs from 'dayjs';

const UserTable = ({ users, currentUser, handleViewUser, handleClickOpen }) => {
    return (
        <TableContainer>
            <Table sx={{ minWidth: 650 }} aria-label="users table">
                <TableHead>
                    <TableRow>
                        <TableCell sx={{ fontWeight: 'bold' }}>User ID</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Username</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Email</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Role</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Subscription</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Joined</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {users.map((user) => (
                        <TableRow key={user._id}>
                            <TableCell>{user._id}</TableCell>
                            <TableCell>{user.username}</TableCell>
                            <TableCell>{user.email}</TableCell>
                            <TableCell>
                                <Chip
                                    label={user.role ? user.role.toUpperCase() : 'N/A'}
                                    color={user.role === 'admin' ? 'secondary' : 'default'}
                                    size="small"
                                />
                            </TableCell>
                            <TableCell>
                                {user.role === 'admin' ? (
                                    '-'
                                ) : user.subscription ? (
                                    `${user.subscription.plan} (${user.subscription.status})`
                                ) : (
                                    'Free'
                                )}
                            </TableCell>
                            <TableCell>{user.createdAt ? dayjs(user.createdAt).format('YYYY-MM-DD') : 'N/A'}</TableCell>
                            <TableCell>
                                <Button
                                    variant="contained"
                                    size="small"
                                    sx={{
                                        mr: 1,
                                        backgroundColor: '#b9bbdf',
                                        '&:hover': { backgroundColor: '#878ecd' }
                                    }}
                                    onClick={() => handleViewUser(user._id)}
                                >
                                    View
                                </Button>
                                <Button
                                    variant="contained"
                                    size="small"
                                    sx={{
                                        backgroundColor: '#4b0082',
                                        '&:hover': { backgroundColor: '#3a006a' }
                                    }}
                                    onClick={() => handleClickOpen(user._id)}
                                    disabled={user.role === 'admin' || user._id === currentUser?._id}
                                >
                                    Delete
                                </Button>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default UserTable;