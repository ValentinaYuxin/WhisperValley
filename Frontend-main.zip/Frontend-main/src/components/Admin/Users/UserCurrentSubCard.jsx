import React from 'react';
import {
    Typography,
    Card,
    CardContent,
    List,
    ListItem,
    ListItemText,
    Divider,
    Button,
    Box,
} from '@mui/material';
import dayjs from 'dayjs';

export default function UserCurrentSubscriptionCard({ user, onGrantPremium, onCancelSubscription }) {
    return (
        <Card elevation={3}>
            <CardContent>
                <Typography variant="h5" gutterBottom sx={{ fontWeight: "bold", color: "#6d5b9b" }}>
                    Subscription Information
                </Typography>
                {user.subscription ? (
                    <List>
                        <ListItem>
                            <ListItemText primary="Plan" secondary={user.subscription.plan} />
                        </ListItem>
                        <Divider component="li" />
                        <ListItem>
                            <ListItemText primary="Status" secondary={user.subscription.status} />
                        </ListItem>
                        <Divider component="li" />
                        <ListItem>
                            <ListItemText
                                primary="StartDate"
                                secondary={dayjs(user.subscription.startDate).format("YYYY-MM-DD")} />
                        </ListItem>
                        <Divider component="li" />
                        <ListItem>
                            <ListItemText
                                primary="EndDate"
                                secondary={user.subscription.endDate ? dayjs(user.subscription.endDate).format("YYYY-MM-DD") : 'N/A'}
                            />
                        </ListItem>
                    </List>
                ) : (
                    <Typography variant="body1">No active subscription (Free User)</Typography>
                )}

                <Box sx={{ mt: 2, display: 'flex', justifyContent:'flex-end', gap: 2 }}>
                    <Button variant="contained" color="secondary" onClick={() => onGrantPremium(user._id)}>
                        Grant Premium
                    </Button>
                    {user.subscription && user.subscription.status !== 'cancelled' && (
                        <Button variant="contained" color="error" onClick={() => onCancelSubscription(user._id)}>
                            Cancel Subscription
                        </Button>
                    )}
                </Box>
            </CardContent>
        </Card>
    );
}