import React from 'react';
import {
    Typography,
    Card,
    CardContent,
    List,
    ListItem,
    ListItemText,
    Divider,
    Button,
    Box,
} from '@mui/material';
import dayjs from 'dayjs';

export default function UserBasicInfoCard({ user, onEditUser }) {
    return (
        <Card elevation={3}>
            <CardContent>
                <Typography variant="h5" gutterBottom sx={{ fontWeight: "bold", color: "#6d5b9b" }}>
                    Basic Information
                </Typography>

                <List>
                    <ListItem>
                        <ListItemText primary="Username" secondary={user.username} />
                    </ListItem>
                    <Divider component="li" />
                    <ListItem>
                        <ListItemText primary="Email" secondary={user.email} />
                    </ListItem>
                    <Divider component="li" />
                    <ListItem>
                        <ListItemText primary="Role" secondary={user.role} />
                    </ListItem>
                    <Divider component="li" />
                    <ListItem>
                        <ListItemText
                            primary="JoinedDate"
                            secondary={dayjs(user.createdAt).format("YYYY-MM-DD HH:mm")} />
                    </ListItem>
                    <Divider component="li" />
                    <ListItem>
                        <ListItemText
                            primary="LastUpdated"
                            secondary={dayjs(user.updatedAt).format("YYYY-MM-DD HH:mm")}
                        />
                    </ListItem>
                </List>

                <Box sx={{ mt: 2, display: 'flex', justifyContent:'flex-end' }}>
                    <Button
                        variant="contained"
                        color="primary"
                        sx={{ mr: 1, backgroundColor: '#b9bbdf', '&:hover': { backgroundColor:'#878ecd' } }}
                        onClick={() => onEditUser(user._id)}
                    >
                        Edit User
                    </Button>
                </Box>
            </CardContent>
        </Card>
    );
}