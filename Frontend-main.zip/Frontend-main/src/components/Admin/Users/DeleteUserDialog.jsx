import React from 'react';
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
} from '@mui/material';

const DeleteUserDialog = ({ open, handleClose, handleDelete }) => {
    return (
        <Dialog open={open} onClose={handleClose}>
            <DialogTitle>{"Confirm Deletion"}</DialogTitle>
            <DialogContent>
                <DialogContentText>
                    Are you sure you want to delete this user? This action cannot be undone.
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button
                    onClick={handleClose}
                    sx={{
                            backgroundColor: '#b9bbdf',
                            color: '#fff',
                            '&:hover': { backgroundColor: '#878ecd' }
                }}
                >
                    Cancel
                </Button>
                <Button
                    onClick={handleDelete}
                    autoFocus
                    sx={{
                        backgroundColor: '#4b0082',
                        color: '#fff',
                        '&:hover': { backgroundColor: '#3a006a' }
                    }}
                >
                    Delete
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default DeleteUserDialog;