import React, { useEffect } from "react";
import {
    Box,
    CssBaseline,
    Drawer,
    List,
    ListItem,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Toolbar,
    Typography,
    Divider,
    AppBar,
    IconButton,
    Button,
    Badge,
} from "@mui/material";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import DashboardIcon from "@mui/icons-material/Dashboard";
import PeopleIcon from "@mui/icons-material/People";
import ReportIcon from "@mui/icons-material/Report";
import RateReviewIcon from "@mui/icons-material/RateReview";
import HomeIcon from "@mui/icons-material/Home";
import LogoutIcon from "@mui/icons-material/Logout";
import EmailIcon from "@mui/icons-material/Email";
import { useDispatch } from "react-redux";
import { logout } from "../../store/slices/userSlice";
import { useAdmin } from "../../hooks/useAdmin.js";

const drawerWidth = 240;

const adminNavItems = [
    { text: "Dashboard", icon: <DashboardIcon />, path: "/admin/dashboard" },
    { text: "Users", icon: <PeopleIcon />, path: "/admin/users" },
    { text: "Reports", icon: <ReportIcon />, path: "/admin/reports" },
    { text: "Contact Messages", icon: <EmailIcon />, path: "/admin/contact-messages" },
];

export default function AdminLayout() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { pendingReportsCount, fetchPendingReportsCount } = useAdmin();

    useEffect(() => {
        fetchPendingReportsCount();
        const interval = setInterval(() => {
            fetchPendingReportsCount();
        }, 60000);  // refetch every minute
        return () => clearInterval(interval);
    }, [fetchPendingReportsCount]);

    const handleLogout = () => {
        dispatch(logout());
        navigate("/signin");
    };

    return (
        <Box sx={{ display: "flex" }}>
            <CssBaseline />
            <AppBar
                position="fixed"
                sx={{
                    width: `calc(100% - ${drawerWidth}px)`,
                    ml: `${drawerWidth}px`,
                    backgroundColor: "#6d5b9b",  // Admin header color
                }}
            >
                <Toolbar>
                    <IconButton
                        color="inherit"
                        aria-label="back to homepage"
                        onClick={() => navigate("/")}
                        sx={{ mr: 2 }}
                    >
                        <HomeIcon />
                    </IconButton>
                    <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 1 }}>
                        Admin Panel
                    </Typography>
                </Toolbar>
            </AppBar>

            <Drawer
                variant="permanent"
                sx={{
                    width: drawerWidth,
                    flexShrink: 0,
                    ["& .MuiDrawer-paper"]: {
                        width: drawerWidth,
                        boxSizing: "border-box",
                        backgroundColor: "#f2eefc",  // Light purple background
                        borderRight: "1px solid #d6c8ff",
                    },
                }}
            >
                <Toolbar />
                <Divider />

                {/*flexGrow to push logout to bottom*/}
                <Box sx={{ overflow: "auto", flexGrow: 1 }}>
                    <List>
                        {adminNavItems.map((item) => (
                            <ListItem key={item.text} disablePadding>
                                <ListItemButton
                                    component={NavLink}
                                    to={item.path}
                                    sx={{
                                        color:  '#4b0082',
                                        '& .MuiListItemIcon-root': { color: '#6d5b9b', },
                                        '&.active': {
                                            backgroundColor: 'rgba(109, 91, 155, 0.1)',
                                            borderRight: '3px solid #4b0082',
                                            fontWeight: 'bold',
                                        },
                                        '&:hover': {
                                            backgroundColor: 'rgba(109, 91, 155, 0.05)',
                                        },
                                    }}
                                >
                                    {item.text === "Reports" ? (
                                        <ListItemIcon>
                                            <Badge badgeContent={pendingReportsCount} color="error">
                                                {item.icon}
                                            </Badge>
                                        </ListItemIcon>
                                    ) : (
                                        <ListItemIcon>{item.icon}</ListItemIcon>
                                    )}
                                    <ListItemText primary={item.text} />
                                </ListItemButton>
                            </ListItem>
                        ))}
                    </List>
                </Box>
                <Divider />
                <List>
                    <ListItem disablePadding>
                        <ListItemButton onClick={handleLogout} sx={{
                            color: '#4b0082',
                            '& .MuiListItemIcon-root': { color: '#6d5b9b', },
                            '&:hover': { backgroundColor: 'rgba(109, 91, 155, 0.05)', },
                        }}
                        >
                            <ListItemIcon><LogoutIcon /></ListItemIcon>
                            <ListItemText primary="Logout" />
                        </ListItemButton>
                    </ListItem>
                </List>
            </Drawer>
            <Box
                component="main"
                sx={{ flexGrow: 1, backgroundColor: '#fafafa', p: 3 }}
            >
                <Toolbar />
                <Outlet />
            </Box>
        </Box>
    );
}