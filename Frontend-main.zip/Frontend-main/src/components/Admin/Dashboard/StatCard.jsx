import React from 'react';
import { Typography, Box, Paper } from '@mui/material';

const StatCard = ({ title, value, icon, color, textColor }) => (
    <Paper
        elevation={3}
        sx={{
            p: 3,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            borderRadius: 2,
            backgroundColor: color || '#fff',
            color: textColor || 'inherit',
        }}
    >
        <Box>
            <Typography variant="h6" color="text.secondary">
                {title}
            </Typography>
            <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                {value}
            </Typography>
        </Box>
        <Box sx={{ color: 'text.secondary' }}>{icon}</Box>
    </Paper>
);

export default StatCard;