import React from "react";
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Typography,
    Box,
} from '@mui/material';
import dayjs from 'dayjs';

const ViewMessageDialog = ({ open, onClose, message }) => {
    if (!message) return null;

    return (
        <Dialog
            open={open}
            onClose={onClose}
            maxWidth="sm"
            fullWidth
            aria-labelledby="view-message-dialog-title"
        >
            <DialogTitle id="view-message-dialog-title">Contact Message Details</DialogTitle>
            <DialogContent dividers>
                <Box>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>Email:</Typography>
                    <Typography variant="body1" sx={{ mb: 1}}>{message.email}</Typography>

                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>Subject:</Typography>
                    <Typography variant="body1" sx={{ mb: 1}}>{message.subject}</Typography>

                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>Message:</Typography>
                    <Typography variant="body1" sx={{ whiteSpace: 'pre-wrap', mb: 1 }}>{message.message}</Typography>

                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>Received At:</Typography>
                    <Typography variant="body1">{dayjs(message.createdAt).format('YYYY-MM-DD HH:mm')}</Typography>
                </Box>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Close</Button>
            </DialogActions>
        </Dialog>
    );
};

export default ViewMessageDialog;