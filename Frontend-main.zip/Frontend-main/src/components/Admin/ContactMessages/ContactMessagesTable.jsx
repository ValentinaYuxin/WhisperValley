import React from "react";
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Chip,
    Typography,
    Box,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityIcon from '@mui/icons-material/Visibility';
import dayjs from 'dayjs';

const ContactMessagesTable = ({ messages, onView, onDelete, onUpdateStatus }) => {
    if (!messages || messages.length === 0) {
        return (
            <Box sx={{ mt: 2, p: 2, border: '1px dashed #ccc', borderRadius: 2, textAlign: 'center' }}>
                <Typography variant="body1" color="text.secondary">No contact messages found.</Typography>
            </Box>
        );
    }

    const getStatusChipStyle = (status) => {
        if (!status) return 'default';
        switch (status) {
            case 'new':
                return { backgroundColor: '#521262', color: 'white' };
            case 'read':
                return { backgroundColor: '#a6acec', color: 'white' };
            case 'resolved':
                return { backgroundColor: '#a56cc1', color: 'white' };
            case 'archived':
                return { backgroundColor: '#c9d6df', color: 'white' };
            default:
                return { backgroundColor: '#9E9E9E', color: 'white' };
        }
    };

    return (
        <TableContainer>
            <Table sx={{ minWidth: 650 }} aria-label="contact messages table">
                <TableHead>
                    <TableRow>
                        <TableCell sx={{ fontWeight: 'bold' }}>Email</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Subject</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Received At</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {messages.map((message) => (
                        <TableRow key={message._id}>
                            <TableCell>{message.email}</TableCell>
                            <TableCell>{message.subject}</TableCell>
                            <TableCell>{dayjs(message.createdAt).format('YYYY-MM-DD HH:mm')}</TableCell>
                            <TableCell>
                                <FormControl variant="outlined" size="small" sx={{ minWidth: 120 }}>
                                    <InputLabel id={`status-select-label-${message._id}`}>Status</InputLabel>
                                    <Select
                                        labelId={`status-select-label-${message._id}`}
                                        id={`status-select-${message._id}`}
                                        value={message.status || 'new'}
                                        onChange={(e) => onUpdateStatus(message._id, e.target.value)}
                                        renderValue={(selected) => (
                                            <Chip
                                                label={selected.toUpperCase()}
                                                size="small"
                                                sx={{ width: '100%', ...getStatusChipStyle(selected) }}
                                            />
                                        )}
                                        label='Status'
                                        variant='outlined'
                                    >
                                        <MenuItem value="new">New</MenuItem>
                                        <MenuItem value="read">Read</MenuItem>
                                        <MenuItem value="resolved">Resolved</MenuItem>
                                        <MenuItem value="archived">Archived</MenuItem>
                                    </Select>
                                </FormControl>
                            </TableCell>

                            <TableCell>
                                <IconButton sx={{ color: '#b9bbdf' }} onClick={()=> onView(message)}>
                                    <VisibilityIcon />
                                </IconButton>
                                <IconButton sx={{ color: '#7e6bc4' }} onClick={()=> onDelete(message._id)}>
                                    <DeleteIcon />
                                </IconButton>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default ContactMessagesTable;