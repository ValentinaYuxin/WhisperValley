// File: src/components/forum/Comment.jsx

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Avatar,
  Paper,
  IconButton,
  Button,
} from "@mui/material";
import PersonIcon from "@mui/icons-material/Person";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import ThumbUpOutlinedIcon from "@mui/icons-material/ThumbUpOutlined";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { useDispatch } from "react-redux";
import { likeComment } from "../../store/slices/forumSlice";
import ThreeDotMenu from "./ThreeDotMenu";

import InputComment from "./InputComment";

import { formatDate } from "../../utils/formatDate";

const Comment = ({
  comment,
  currentUser,
  onUpdate,
  onDelete,
  onReport,
  currentPost,
  depth = 0,
  repliesByCommentId,
  onSubmitReply = () => Promise.resolve({ success: false }),
}) => {
  const dispatch = useDispatch();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [showReplyInput, setShowReplyInput] = React.useState(false);
  const [replyText, setReplyText] = React.useState("");
  const [isReplying, setIsReplying] = React.useState(false);
  // Auto-expand replies for top-level comments, collapse for deeper
  const [showReplies, setShowReplies] = React.useState(() => depth === 0);
  const isOwner = comment.isOwner || false;

  const handleMenuOpen = (e) => {
    setAnchorEl(e.currentTarget);
  };
  const handleMenuClose = () => setAnchorEl(null);

  const handleLike = () => {
    try {
      dispatch(likeComment(normalizedComment._id));
    } catch (error) {
      console.error("Error liking comment:", error);
    }
  };

  // Normalize comment object for replies (handle missing fields)
  // Use formatDate for all timestamps (comments, posts, replies)
 
  // Always normalize date for comments and replies using formatDate
  const normalizedComment = {
    id: comment._id || comment.id,
    _id: comment._id || comment.id,
    username: comment.author || comment.username || "Anonymous",
    userId: comment.userId || comment.user,
    avatar: comment.avatar || "",
    // Use createdAt if timestamp is missing, fallback to empty string
    timestamp: formatDate(comment.createdAt || comment.timestamp || ""),
    text: comment.content || comment.text || "",
    likeCount: comment.likeCount || 0,
    isLiked: comment.isLiked || false,
    isOwner: comment.isOwner,
    parentComment: comment.parentComment || null,
    replies: (comment.replies || []).map(reply => ({
      ...reply,
      // Use createdAt if timestamp is missing for replies
      timestamp: formatDate(reply.createdAt || reply.timestamp || "")
    })),
  };

  // Get replies for this comment
  const replies =
    (repliesByCommentId && repliesByCommentId[normalizedComment._id]) || [];
  // Handle reply submit
  const handleReplySubmit = async (e) => {
    e.preventDefault();
    if (!replyText.trim() || isReplying) return;
    setIsReplying(true);
    let result = { success: false };
    if (typeof onSubmitReply === "function") {
      result = await onSubmitReply(comment._id, replyText);
    }
    // Always reset reply input and enable button after submit
    setReplyText("");
    setShowReplyInput(false);
    setShowReplies(true); // Show replies after submitting a reply
    setIsReplying(false);
    window.location.reload(); // Force reload to show latest replies
  };

  return (
    <Paper
      elevation={0}
      sx={{
        p: 2,
        backgroundColor: "rgba(249, 249, 249, 0.8)",
        borderRadius: 2,
        border: "1px solid rgba(0, 0, 0, 0.08)",
        position: "relative",
        mb: 1,
        ml: depth > 0 ? 2 : 0,
      }}
    >
      <Box sx={{ display: "flex", alignItems: "flex-start" }}>
        <Avatar
          sx={{
            mr: 2,
            bgcolor: "#fff",
            width: 36,
            height: 36,
            fontSize: "0.9rem",
            border: "2px solid #9c27b0",
          }}
        >
          <PersonIcon fontSize="medium" sx={{ color: "#9c27b0" }} />
        </Avatar>

        <Box sx={{ flexGrow: 1 }}>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mb: 1,
            }}
          >
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: "bold" }}>
                {normalizedComment.username}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {normalizedComment.timestamp}
              </Typography>
            </Box>

            <Box sx={{ display: "flex", alignItems: "center" }}>
              <IconButton
                size="small"
                onClick={handleLike}
                color={comment.isLiked ? "secondary" : "default"}
              >
                {comment.isLiked ? (
                  <ThumbUpIcon fontSize="small" />
                ) : (
                  <ThumbUpOutlinedIcon fontSize="small" />
                )}
              </IconButton>
              <Typography variant="body2" color="text.secondary">
                {comment.likeCount || 0}
              </Typography>
              <IconButton size="small" onClick={handleMenuOpen} sx={{ ml: 1 }}>
                <MoreVertIcon fontSize="small" />
              </IconButton>
              <ThreeDotMenu
                anchorEl={anchorEl}
                isOwner={isOwner}
                onClose={handleMenuClose}
                onUpdate={() => {
                  handleMenuClose();
                  onUpdate && onUpdate(normalizedComment);
                }}
                onDelete={() => {
                  handleMenuClose();
                  onDelete && onDelete(normalizedComment._id);
                }}
                onReport={() => {
                  handleMenuClose();
                  onReport && onReport(normalizedComment);
                }}
              />
            </Box>
          </Box>

          <Typography
            variant="body1"
            sx={{ whiteSpace: "pre-line", color: "#222" }}
          >
            {comment.text}
          </Typography>
          {/* Reply button */}
          <Box sx={{ mt: 1, display: "flex", alignItems: "center", gap: 1 }}>
            <Button
              size="small"
              variant="text"
              onClick={() => setShowReplyInput((prev) => !prev)}
              sx={{
                textTransform: "none",
                fontSize: "0.95rem",
                color: "#9c27b0",
                fontWeight: 700,
                "&:hover": {
                  bgcolor: "rgba(156,39,176,0.08)",
                  color: "#7B1FA2",
                },
              }}
            >
              {showReplyInput ? "Cancel" : "Reply"}
            </Button>
            {/* Toggle replies button */}
            {replies.length > 0 && (
              <Button
                size="small"
                variant="text"
                onClick={() => setShowReplies((prev) => !prev)}
                sx={{
                  textTransform: "none",
                  fontSize: "0.95rem",
                  color: "#9c27b0", // Always purple when hiding replies
                  fontWeight: showReplies ? 700 : 400,
                  "&:hover": {
                    bgcolor: "rgba(156,39,176,0.08)",
                    color: "#7B1FA2",
                  },
                }}
              >
                {showReplies
                  ? `Hide replies`
                  : `View ${replies.length} repl${
                      replies.length === 1 ? "y" : "ies"
                    }`}
              </Button>
            )}
          </Box>
          {/* Inline reply input */}
          {showReplyInput && (
            <Box sx={{ mt: 1, mb: 1 }}>
              <InputComment
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                onSubmit={handleReplySubmit}
                isSubmitting={isReplying}
                error={null}
              />
            </Box>
          )}
        </Box>
      </Box>

      {/* Recursively render replies, hidden by default except for top-level */}
      {replies.length > 0 && showReplies && (
        <Box
          sx={{ pl: 4, borderLeft: "2px solid rgba(142,36,170,0.15)", mt: 1 }}
        >
          {replies
            .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
            .map((reply) => (
              <Comment
                key={reply._id}
                comment={{
                  ...reply,
                  text: reply.content || reply.text,
                  username: reply.author || reply.username || "Anonymous",
                  timestamp: reply.timestamp || reply.createdAt || "",
                }}
                currentUser={currentUser}
                onUpdate={onUpdate}
                onDelete={onDelete}
                onReport={onReport}
                currentPost={currentPost}
                depth={depth + 1}
                repliesByCommentId={repliesByCommentId}
                onSubmitReply={onSubmitReply}
              />
            ))}
        </Box>
      )}
      {/* Fallback UI if replies exist but not shown */}
      {replies.length > 0 && !showReplies && (
        <Box sx={{ pl: 4, color: "text.secondary", fontSize: "0.9rem", mt: 1 }}>
          {/* Optionally show a message or icon if replies exist but are hidden */}
          {/* Example: <Typography variant="caption">Replies hidden</Typography> */}
        </Box>
      )}
    </Paper>
  );
};

export default Comment;
