import { Box } from "@mui/material";

const ForumContainer = ({ children }) => (
  <Box maxWidth="md" mx="auto" px={2} py={4}>
    {children}
  </Box>
);

export default ForumContainer;
