import { Typography, Box } from "@mui/material";

const ForumHeader = ({ totalItems }) => (
  <Box mb={2}>
    <Typography variant="h4" fontWeight={700}>
      Forum
    </Typography>
    <Typography variant="subtitle1" color="text.secondary">
      {totalItems} posts
    </Typography>
  </Box>
);

export default ForumHeader;
