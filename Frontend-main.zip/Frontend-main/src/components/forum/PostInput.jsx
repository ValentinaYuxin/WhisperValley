import React, { useState } from "react";
import { Paper, Box, Typography, TextField, Button } from "@mui/material";
import EmojiSelector from "./EmojiSelector.jsx";
import EmotionalLabels from "./EmotionalLabes.jsx";
import TagInput from "./TagInput.jsx";

const PostInput = ({ onSubmit }) => {
  const [emoji, setEmoji] = useState("😊");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [title, setTitle] = useState("");
  const [emotion, setEmotion] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState([]);
  const [newTag, setNewTag] = useState("");

  const handleAddTag = () => {
    const trimmed = newTag.trim();
    if (trimmed && !tags.includes(trimmed)) {
      setTags([...tags, trimmed]);
      setNewTag("");
    }
  };

  const handleEmojiClick = (emojiData) => {
    setEmoji(emojiData.emoji);
    setShowEmojiPicker(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !emotion || !content) return;
    onSubmit({ emoji, title, emotion, content, tags });
    setTitle("");
    setEmotion("");
    setContent("");
    setTags([]);
    setNewTag("");
  };

  return (
    <Paper elevation={3} sx={{ p: 3, mb: 3, borderRadius: 3 }}>
      <Typography variant="h6" fontWeight={600} mb={2}>
        Create a Post
      </Typography>
      <EmojiSelector
        emoji={emoji}
        showEmojiPicker={showEmojiPicker}
        setShowEmojiPicker={setShowEmojiPicker}
        handleEmojiClick={handleEmojiClick}
      />
      <TextField
        label="Title"
        variant="outlined"
        fullWidth
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        sx={{ mb: 2 }}
      />
      <EmotionalLabels emotion={emotion} setEmotion={setEmotion} />
      <TextField
        label="Content"
        variant="outlined"
        fullWidth
        multiline
        minRows={3}
        value={content}
        onChange={(e) => setContent(e.target.value)}
        sx={{ mb: 2 }}
      />
      <TagInput
        tags={tags}
        newTag={newTag}
        setNewTag={setNewTag}
        handleAddTag={handleAddTag}
      />
      <Box display="flex" justifyContent="flex-end">
        <Button variant="contained" onClick={handleSubmit}>
          Post
        </Button>
      </Box>
    </Paper>
  );
};

export default PostInput;
