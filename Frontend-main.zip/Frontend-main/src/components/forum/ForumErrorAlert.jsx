import { Alert } from "@mui/material";

const ForumErrorAlert = ({ error }) => (
  error ? <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert> : null
);

export default ForumErrorAlert;
