import React from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, Typography } from "@mui/material";

/**
 * ReportModal - Reusable modal for reporting posts or comments
 * @param {object} props
 * @param {boolean} props.open - Whether the modal is open
 * @param {function} props.onClose - Function to close the modal
 * @param {function} props.onSubmit - Function to submit the report (calls with reason)
 * @param {string} props.reason - The current reason value
 * @param {function} props.setReason - Function to set the reason
 * @param {string} [props.error] - Optional error message
 * @param {string} [props.targetType] - 'post' or 'comment'
 */
const ReportModal = ({ open, onClose, onSubmit, reason, setReason, error, targetType }) => (
  <Dialog open={open} onClose={onClose} PaperProps={{ sx: { zIndex: 2000 } }}>
    <DialogTitle>Report {targetType === 'comment' ? 'Comment' : 'Post'}</DialogTitle>
    <DialogContent>
      <Typography mb={2}>
        Please provide a reason for reporting this {targetType === 'comment' ? 'comment' : 'post'}.
      </Typography>
      <TextField
        autoFocus
        margin="dense"
        label="Reason"
        type="text"
        fullWidth
        multiline
        minRows={3}
        value={reason}
        onChange={e => setReason(e.target.value)}
        error={!!error}
        helperText={error}
        sx={{
          '& label': {
            color: '#9C27B0', // label always purple
          },
          '& label.Mui-focused': {
            color: '#9C27B0', // label stays purple when focused
          },
          '& .MuiOutlinedInput-root': {
            '& input': {
              color: '#222', // user input text always black
            },
            '& textarea': {
              color: '#222', // user input text always black
            },
            '& fieldset': {
              borderColor: '#9C27B0', // always purple
            },
            '&:hover fieldset': {
              borderColor: '#9C27B0', // always purple
            },
            '&.Mui-focused fieldset': {
              borderColor: '#9C27B0', // always purple
            },
          },
        }}
      />
    </DialogContent>
    <DialogActions>
      <Button
        onClick={onClose}
        variant="outlined"
        sx={{
          color: '#9C27B0',
          borderColor: '#9C27B0',
          '&:hover': { borderColor: '#7B1FA2', backgroundColor: '#F3E5F5', color: '#7B1FA2' }
        }}
      >
        Cancel
      </Button>
      <Button
        variant="contained"
        onClick={onSubmit}
        disabled={!reason.trim()}
        sx={{ backgroundColor: '#9C27B0', color: '#fff', '&:hover': { backgroundColor: '#7B1FA2' } }}
      >
        Submit
      </Button>
    </DialogActions>
  </Dialog>
);

export default ReportModal;
