import { Box, TextField, IconButton } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";

const ForumSearchBar = ({ searchQuery, setSearchQuery, onSearch }) => (
  <Box mb={2} display="flex" alignItems="center">
    <TextField
      value={searchQuery}
      onChange={e => setSearchQuery(e.target.value)}
      placeholder="Search posts..."
      size="small"
      sx={{ flex: 1 }}
      onKeyDown={e => e.key === "Enter" && onSearch()}
    />
    <IconButton onClick={onSearch} sx={{ ml: 1 }}>
      <SearchIcon />
    </IconButton>
  </Box>
);

export default ForumSearchBar;
