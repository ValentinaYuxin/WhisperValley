// File: src/components/forum/PostCard.jsx

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Box,
  Typography,
  Chip,
  Stack,
  Card,
  CardContent,
  Tooltip,
  IconButton,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField
} from "@mui/material";
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { formatDate } from "../../utils/formatDate";
import CommentModal from "./CommentModal";
import { useForum } from '../../hooks/useForum';

// Helper function to get emotion color
const getEmotionColor = (emotion) => {
  const emotionColors = {
    Enjoyment: "#4CAF50", // Green
    Fear: "#F44336", // Red
    Anger: "#FF5722", // Deep Orange
    Sadness: "#2196F3", // Blue
    Disgust: "#9C27B0", // Purple
    Surprise: "#FFC107", // Amber
    Neutral: "#9E9E9E", // Grey
  };
  return emotionColors[emotion] || "#9E9E9E"; // Default to grey if emotion not found
};

/**
 * PostCard - A reusable component to display post information
 * 
 * @param {Object} post - The post object containing post details
 * @param {Function} onTagSelect - Function to handle tag selection
 * @returns {JSX.Element} - The rendered PostCard component
 */
const PostCard = ({ post, onTagSelect, onClick, isOwner }) => {
  if (!post) return null;

  const navigate = useNavigate();
  const { createComment, fetchComments, fetchPostById } = useForum();
  const [anchorEl, setAnchorEl] = useState(null);
  const [commentModalOpen, setCommentModalOpen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [commentValue, setCommentValue] = useState("");

  const handleCardClick = (e) => {
    if (commentModalOpen || anchorEl || reportModalOpen) return;
    if (
      e.target.closest('.MuiChip-root') ||
      e.target.closest('.post-menu') ||
      e.target.closest('.comment-btn')
    ) {
      return;
    }
    if (post && post._id) {
      navigate(`/forum/posts/${post._id}`);
    } else {
      console.error('Cannot navigate: Invalid post ID', post);
    }
  };

  // Refactored handler: works with or without event
  const handleCommentClick = (e) => {
    e?.stopPropagation?.();
    setCommentModalOpen(true);
  };
  const handleCommentModalClose = () => setCommentModalOpen(false);

  const handleReportClick = (e) => {
    e?.stopPropagation?.();
    setReportModalOpen(true);
    handleMenuClose();
  };
  const handleReportModalClose = () => setReportModalOpen(false);
  const handleReportSubmit = () => {
    setReportModalOpen(false);
    setReportReason("");
  };
  const handleCommentSubmit = async (e) => {
    e?.preventDefault?.();
    console.log("Submitting comment:", commentValue, "for post:", post._id);
    if (!commentValue.trim()) return;
    const result = await createComment({
      postId: post._id,
      content: commentValue.trim()
    });
    console.log("Comment result:", result);
    if (result.success) {
      setCommentValue("");
      setCommentModalOpen(false);
      await fetchComments(post._id);
      await fetchPostById(post._id);
    } else {
      alert(result.error || "Failed to add comment");
    }
  };

  return (
    <Card
      sx={{
        borderRadius: 3,
        transition: "transform 0.2s, box-shadow 0.2s",
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        backdropFilter: 'blur(10px)',
        position: 'relative',
        "&:hover": {
          transform: "translateY(-4px)",
          boxShadow: "0 12px 28px rgba(0, 0, 0, 0.1)",
          cursor: 'pointer',
          backgroundColor: 'rgba(255, 255, 255, 0.95)'
        }
      }}
      onClick={handleCardClick}
    >
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 2 }}>
          {/* Left: Emoji box (if present) */}
          {post.emoji && post.emotionLabel && (
            <Tooltip title={post.emotionLabel}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  bgcolor: `${getEmotionColor(post.emotionLabel)}20`,
                  border: 1,
                  borderColor: getEmotionColor(post.emotionLabel),
                  mr: 2,
                  p: 0.5,
                  borderRadius: 2,
                  minWidth: 48,
                  justifyContent: 'center',
                }}
              >
                <Typography variant="h6" sx={{ mr: 1 }}>
                  {post.emoji}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {post.emotionLabel}
                </Typography>
              </Box>
            </Tooltip>
          )}
          {/* Center: Title */}
          <Link
            to={`/forum/posts/${post._id}`}
            style={{ textDecoration: "none", color: "inherit", flexGrow: 1 }}
          >
            <Typography
              variant="h5"
              component="h2"
              sx={{
                fontWeight: 600,
                color: '#333',
                display: '-webkit-box',
                overflow: 'hidden',
                WebkitBoxOrient: 'vertical',
                WebkitLineClamp: 2,
              }}
            >
              {post.title}
            </Typography>
          </Link>
          {/* Right: 3-dot menu */}
          {/* Remove the three-dot menu from PostCard in the forum list */}
        </Box>
        <Typography
          variant="body2"
          color="text.secondary"
          sx={{ mb: 2 }}
        >
          Posted by {post.author || "Anonymous"} • {formatDate(post.createdAt)}
        </Typography>
        <Typography
          variant="body2"
          sx={{
            mb: 2,
            display: '-webkit-box',
            overflow: 'hidden',
            WebkitBoxOrient: 'vertical',
            WebkitLineClamp: 3,
            color: "#333"
          }}
        >
          {post.content}
        </Typography>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          {/* Tags */}
          <Box sx={{ minWidth: 120 }}>
            {post.tags?.length > 0 ? (
              <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap" }}>
                {post.tags.slice(0, 3).map((tag, i) => (
                  <Chip
                    key={i}
                    label={tag}
                    size="small"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      onTagSelect?.(tag);
                    }}
                    className="MuiChip-root"
                  />
                ))}
                {post.tags.length > 3 && (
                  <Chip
                    label={`+${post.tags.length - 3}`}
                    size="small"
                    variant="outlined"
                  />
                )}
              </Stack>
            ) : null}
          </Box>

          {/* Stats */}
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Typography variant="body2" color="text.secondary">
              {post.likeCount || 0} likes
            </Typography>
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{ cursor: "pointer", textDecoration: "underline", userSelect: "none" }}
              onClick={handleCommentClick}
              className="comment-btn"
            >
              {typeof post.commentCount === "number"
                ? post.commentCount
                : post.comments?.length || 0}{" "}
              comments
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {post.views || 0} views
            </Typography>
          </Box>
        </Box>
      </CardContent>
      {/* Comment Modal */}
      <CommentModal
        open={commentModalOpen}
        onClose={() => setCommentModalOpen(false)}
        onSubmit={handleCommentSubmit}
        value={commentValue}
        onChange={e => setCommentValue(e.target.value)}
      />
      {/* Report Modal */}
      <Dialog open={reportModalOpen} onClose={handleReportModalClose}>
        <DialogTitle>Report Post</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Reason for report"
            type="text"
            fullWidth
            multiline
            minRows={3}
            value={reportReason}
            onChange={e => setReportReason(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleReportModalClose}>Cancel</Button>
          <Button
            color="secondary"
            variant="contained"
            onClick={handleReportSubmit}
            disabled={!reportReason.trim()}
          >
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Card>
  );
};

export default PostCard;


