import React from "react";
import { Box, Chip, Typography, FormHelperText } from "@mui/material";

// These must match exactly what the backend expects in the enum
const emotions = [
  "Contempt",
  "Sadness",
  "Fear",
  "Anger",
  "Disgust",
  "Surprise",
  "Enjoyment"
];

const emotionColors = {
  "Enjoyment": "#4CAF50", // Green
  "Fear": "#9C27B0", // Purple
  "Anger": "#F44336", // Red
  "Sadness": "#2196F3", // Blue
  "Disgust": "#FF9800", // Orange
  "Surprise": "#FFC107", // Amber
  "Contempt": "#795548", // Brown
};

const EmotionalLabels = ({ emotion, setEmotion, error = false, helperText = "" }) => {
  return (
    <Box mb={3}>
      <Typography fontWeight={600} mb={1} color={error ? "error" : "inherit"}>
        Select your emotion label (required)
      </Typography>
      <Box display="flex" flexWrap="wrap" gap={1}>
        {emotions.map((emo) => (
          <Chip
            key={emo}
            label={emo}
            variant={emotion === emo ? "filled" : "outlined"}
            color={error ? "error" : "primary"}
            onClick={() => setEmotion(emo)}
            sx={{
              bgcolor: emotion === emo ? emotionColors[emo] : "transparent",
              borderColor: emotionColors[emo],
              color: emotion === emo ? "white" : emotionColors[emo],
              "&:hover": {
                bgcolor: `${emotionColors[emo]}22`  // Adding transparency
              }
            }}
          />
        ))}
      </Box>
      {error && (
        <FormHelperText error>{helperText}</FormHelperText>
      )}
    </Box>
  );
};

export default EmotionalLabels;

