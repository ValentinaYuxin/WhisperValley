import { CircularProgress, Box } from "@mui/material";

const ForumLoading = ({ isLoading }) => (
  isLoading ? (
    <Box display="flex" justifyContent="center" py={4}>
      <CircularProgress />
    </Box>
  ) : null
);

export default ForumLoading;
