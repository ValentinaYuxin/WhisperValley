import { Box, Typography } from "@mui/material";

const ForumEmptyState = ({ show }) => (
  show ? (
    <Box textAlign="center" py={6}>
      <Typography variant="h6" color="text.secondary">
        No posts found.
      </Typography>
    </Box>
  ) : null
);

export default ForumEmptyState;
