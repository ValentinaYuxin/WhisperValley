import { Box, Chip, Typography } from "@mui/material";

const ForumTagFilter = ({ tags, selectedTags, onTagSelect }) => (
  <Box mb={2}>
    <Typography variant="subtitle2" mb={1}>
      Filter by tags:
    </Typography>
    <Box display="flex" flexWrap="wrap" gap={1}>
      {tags && tags.map(tag => (
        <Chip
          key={tag}
          label={tag}
          color="default"
          onClick={() => onTagSelect(tag)}
          variant={Array.isArray(selectedTags) && selectedTags.includes(tag) ? "filled" : "outlined"}
          sx={Array.isArray(selectedTags) && selectedTags.includes(tag) ? {
            bgcolor: '#9c27b0',
            color: '#fff',
            fontWeight: 500,
            '&:hover': { bgcolor: '#8e24aa' }
          } : { fontWeight: 500 }}
        />
      ))}
    </Box>
  </Box>
);

export default ForumTagFilter;
