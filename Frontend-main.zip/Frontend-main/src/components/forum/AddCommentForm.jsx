// File: src/components/forum/AddCommentForm.jsx

import React, { useState } from "react";
import { Box, Button, TextField, CircularProgress, Alert } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { createComment } from "../../store/slices/forumSlice";
import { handleCommentSubmit } from "../../utils/commentHandlers";

const AddCommentForm = ({ postId, onSuccess, onError }) => {
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const dispatch = useDispatch();
  const isCreatingComment = useSelector(state => state.forum.isCreatingComment);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    await handleCommentSubmit({
      text,
      postId,
      dispatch,
      createCommentThunk: createComment,
      onSuccess: () => {
        setText("");
        setError("");
        if (onSuccess) onSuccess();
      },
      onError: (msg) => {
        setError(msg);
        if (onError) onError(msg);
      }
    });
  };

  return (
    <Box
      mt={2}
      component="form"
      onSubmit={handleSubmit}
      sx={{
        border: "1px solid #eee",
        borderRadius: 2,
        backgroundColor: "transparent",
        p: 2,
        boxShadow: 'none',
        minHeight: 0,
      }}
    >
      <TextField
        placeholder="Add Comment"
        fullWidth
        multiline
        minRows={2}
        value={text}
        onChange={(e) => setText(e.target.value)}
        variant="outlined"
        InputProps={{
          style: { background: 'transparent' },
        }}
        disabled={isCreatingComment}
        error={!!error}
        helperText={error}
      />
      <Box mt={1} display="flex" justifyContent="flex-end">
        <Button type="submit" variant="contained" disabled={isCreatingComment || !text.trim()}>
          {isCreatingComment ? <CircularProgress size={22} color="inherit" /> : "Comment"}
        </Button>
      </Box>
    </Box>
  );
};

export default AddCommentForm;
