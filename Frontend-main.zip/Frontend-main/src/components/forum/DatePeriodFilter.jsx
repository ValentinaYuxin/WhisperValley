import React, { useMemo } from "react";
import { Box, ToggleButton, ToggleButtonGroup, TextField, Typography, FormHelperText } from "@mui/material";

const PRESETS = [
  { label: "3 days", value: "3d" },
  { label: "7 days", value: "7d" },
  { label: "30 days", value: "30d" },
  { label: "Custom", value: "custom" },
];

export default function DatePeriodFilter({ period, setPeriod, customRange, setCustomRange, posts }) {
  // Find earliest post date for min limit
  const minDate = useMemo(() => {
    if (!posts || posts.length === 0) return "";
    // Find the earliest createdAt
    return posts.reduce((min, p) => {
      const d = p.createdAt ? p.createdAt.slice(0, 10) : "";
      return (!min || (d && d < min)) ? d : min;
    }, "");
  }, [posts]);

  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const safeCustomRange = customRange || { start: '', end: '' };

  const handleChange = (event, newValue) => {
    if (newValue !== null && newValue !== period) {
      setPeriod(newValue);
      // Reset custom range if switching away from custom
      if (newValue !== 'custom') {
        setCustomRange({ start: '', end: '' });
      }
    }
  };

  // Validation logic
  const isInvalid =
    period === "custom" &&
    ((safeCustomRange.start && safeCustomRange.end && safeCustomRange.start > safeCustomRange.end) ||
      (safeCustomRange.start && minDate && safeCustomRange.start < minDate) ||
      (safeCustomRange.start && safeCustomRange.start > today) ||
      (safeCustomRange.end && minDate && safeCustomRange.end < minDate) ||
      (safeCustomRange.end && safeCustomRange.end > today));
  let errorMsg = "";
  if (period === "custom") {
    if (safeCustomRange.start && safeCustomRange.end && safeCustomRange.start > safeCustomRange.end) {
      errorMsg = 'Start date must be before end date.';
    } else if ((safeCustomRange.start && safeCustomRange.start > today) || (safeCustomRange.end && safeCustomRange.end > today)) {
      errorMsg = 'Dates cannot be in the future.';
    } else if ((safeCustomRange.start && minDate && safeCustomRange.start < minDate) || (safeCustomRange.end && minDate && safeCustomRange.end < minDate)) {
      errorMsg = `Dates cannot be before the first post (${minDate})`;
    }
  }

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 2, flexWrap: 'wrap' }}>
      <Typography variant="body2" sx={{ minWidth: 80 }}>Period:</Typography>
      <ToggleButtonGroup
        value={period}
        exclusive
        onChange={handleChange}
        size="small"
        color="secondary"
        sx={{ flexWrap: 'wrap' }}
      >
        {PRESETS.map((preset) => (
          <ToggleButton key={preset.value} value={preset.value} sx={{ minWidth: 80 }}>
            {preset.label}
          </ToggleButton>
        ))}
      </ToggleButtonGroup>
      {period === "custom" && (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1, flexWrap: 'wrap' }}>
          <TextField
            type="date"
            size="small"
            value={safeCustomRange.start}
            onChange={(e) => setCustomRange(r => ({ ...r, start: e.target.value }))}
            sx={{ width: 140 }}
            inputProps={{ min: minDate, max: today }}
            error={isInvalid}
          />
          <Typography variant="body2">to</Typography>
          <TextField
            type="date"
            size="small"
            value={safeCustomRange.end}
            onChange={(e) => setCustomRange(r => ({ ...r, end: e.target.value }))}
            sx={{ width: 140 }}
            inputProps={{ min: minDate, max: today }}
            error={isInvalid}
          />
          {isInvalid && (
            <FormHelperText error>{errorMsg}</FormHelperText>
          )}
        </Box>
      )}
    </Box>
  );
}
