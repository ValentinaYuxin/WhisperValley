import React, { useRef, useEffect, useCallback } from "react";
import { Box, CircularProgress } from "@mui/material";
import PostCard from "./PostCard";

const ForumPostList = ({ posts, onTagSelect, onPostClick, isLoading, hasMore, onLoadMore }) => {
  const listRef = useRef();
  const handleScroll = useCallback(() => {
    if (!listRef.current || isLoading || !hasMore) return;
    const { scrollTop, scrollHeight, clientHeight } = listRef.current;
    if (scrollHeight - scrollTop - clientHeight < 200) {
      onLoadMore && onLoadMore();
    }
  }, [isLoading, hasMore, onLoadMore]);

  useEffect(() => {
    const ref = listRef.current;
    if (!ref) return;
    ref.addEventListener("scroll", handleScroll);
    return () => ref.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  return (
    <Box
      ref={listRef}
      mb={3}
      sx={{
        borderRadius: 2,
        background: 'rgba(255,255,255,0.7)',
        px: { xs: 0, sm: 2 },
        py: 2,
        minHeight: 400,
        width: '100%',
        boxSizing: 'border-box',
        overflowY: 'auto',
        maxHeight: '70vh',
      }}
    >
      {posts && posts.length > 0 && posts.map(post => (
        <PostCard
          key={post._id || post.id}
          post={post}
          isOwner={post.isOwner}
          onTagSelect={onTagSelect}
          onClick={onPostClick}
        />
      ))}
      {isLoading && (
        <Box display="flex" justifyContent="center" py={2}>
          <CircularProgress />
        </Box>
      )}
    </Box>
  );
};

export default ForumPostList;
