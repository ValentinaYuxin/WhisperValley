import React from 'react';
import { Box } from '@mui/material';
import Footer from '../Footer';

const ForumBackground = ({ children }) => {
  return (
    <Box sx={{ 
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      minHeight: '100vh',
    }}>
      {/* Fixed background */}
      <Box sx={{ 
        position: 'fixed', 
        top: 0, 
        left: 0, 
        right: 0,
        bottom: 0, 
        zIndex: -1,
        backgroundImage: 'url(/bg.png)', // Make sure this file exists in your public folder
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        // Fallback in case image fails to load
        bgcolor: '#f8f9fa',
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(255, 255, 255, 0.3)', // Optional: slightly lighten background
          zIndex: -1
        }
      }} />

      {/* Content container */}
      <Box sx={{ 
        position: 'relative',
        zIndex: 1,
        paddingTop: '64px', // Space for header
        flex: '1 0 auto', // Allow content to grow and fill available space
      }}>
        {children}
      </Box>
      
      {/* Footer */}
      <Box sx={{ flexShrink: 0 }}>
        <Footer />
      </Box>
    </Box>
  );
};

export default ForumBackground;