import React from "react";
import { Box, Chip, Typography } from "@mui/material";

const EMOTION_LABELS = [
  'Contempt',
  'Sadness',
  'Fear',
  'Anger',
  'Disgust',
  'Surprise',
  'Enjoyment',
];

const EmotionLabelFilter = ({ selected, onSelect }) => (
  <Box mb={2}>
    <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
      Filter by Emotion
    </Typography>
    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
      {EMOTION_LABELS.map(label => (
        <Chip
          key={label}
          label={label}
          color="default"
          onClick={() => onSelect(selected === label ? null : label)}
          sx={{
            fontWeight: 500,
            bgcolor: selected === label ? '#9c27b0' : undefined,
            color: selected === label ? '#fff' : undefined,
            '&:hover': selected === label ? { bgcolor: '#8e24aa' } : undefined
          }}
        />
      ))}
    </Box>
  </Box>
);

export default EmotionLabelFilter;
