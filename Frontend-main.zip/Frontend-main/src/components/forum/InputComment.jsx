import React from 'react';
import { Box, TextField, Button, Avatar, Stack, CircularProgress } from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import SendIcon from '@mui/icons-material/Send';
import { useSelector } from 'react-redux';

// Create a proper component that matches how it's used in PostOverview.jsx
export default function InputComment({ value, onChange, onSubmit, isSubmitting, avatarUrl, avatarText, error }) {
  // Ensure the component correctly handles the submit action
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!value.trim() || isSubmitting) return;
    
    console.log('Submitting comment:', value);
    onSubmit(e);
  };

  // Retrieve avatar from Redux user profile, fallback to icon
  const user = useSelector(state => state.user.user);
  const resolvedAvatarUrl = (user?.avatar && user.avatar.trim() !== '') ? user.avatar : undefined;

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
      <Stack direction="row" spacing={2} alignItems="flex-start">
        <Avatar 
          sx={{ width: 40, height: 40, bgcolor: '#fff', border: '2px solid #9c27b0' }} 
        >
          <PersonIcon fontSize="medium" sx={{ color: '#9c27b0' }} />
        </Avatar>
        <TextField
          fullWidth
          multiline
          minRows={2}
          maxRows={4}
          placeholder="Write your comment here..."
          value={value}
          onChange={onChange}
          variant="outlined"
          disabled={isSubmitting}
          error={!!error}
          helperText={error}
          sx={{
            '& .MuiOutlinedInput-root': {
              borderRadius: 2,
            }
          }}
        />
        <Button 
          type="submit"
          variant="contained" 
          color="primary"
          disabled={!value?.trim() || isSubmitting}
          sx={{ 
            minWidth: 'auto',
            height: 40,
            bgcolor: '#8e24aa',
            '&:hover': { bgcolor: '#6a1b9a' }
          }}
        >
          {isSubmitting ? <CircularProgress size={22} color="inherit" /> : <SendIcon />}
        </Button>
      </Stack>
    </Box>
  );
}