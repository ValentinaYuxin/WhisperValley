import React from "react";
import { Box, IconButton, Typography } from "@mui/material";
import AddIcon from "@mui/icons-material/Add"; // Using plus icon
import EmojiPicker from "emoji-picker-react";

const EmojiSelector = ({ emoji, showEmojiPicker, setShowEmojiPicker, handleEmojiClick }) => {
  return (
    <>
      <Box display="flex" alignItems="center" gap={2} mb={3}>
        <Typography fontSize="2rem">{emoji}</Typography>
        <IconButton onClick={() => setShowEmojiPicker(!showEmojiPicker)} color="primary">
          <AddIcon />
        </IconButton>
        <Typography>
          Choose an emoji that best represents how you're feeling right now.
        </Typography>
      </Box>

      {showEmojiPicker && (
        <Box display="flex" justifyContent="center" mb={3}>
          <EmojiPicker
            onEmojiClick={(e) => handleEmojiClick(e)}
            height={400}
            width={320}
            emojiStyle="native"
            lazyLoadEmojis={true}
          />
        </Box>
      )}
    </>
  );
};

export default EmojiSelector;
