// File: src/components/forum/PostForm.jsx
import React, { useState } from "react";
import {
  Box,
  Button,
  TextField,
  Typography,
  Snackbar,
  Paper
} from "@mui/material";

import EmojiSelector from "./EmojiSelector.jsx";
import EmotionalLabels from "./EmotionalLabes.jsx";
import TagInput from "./TagInput.jsx";

const PostForm = () => {
  const [emoji, setEmoji] = useState("😊");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [title, setTitle] = useState("");
  const [emotion, setEmotion] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState([]);
  const [newTag, setNewTag] = useState("");
  const [showSnackbar, setShowSnackbar] = useState(false);

  const handleAddTag = () => {
    const trimmed = newTag.trim();
    if (trimmed && !tags.includes(trimmed)) {
      setTags([...tags, trimmed]);
      setNewTag("");
    }
  };

  const handleEmojiClick = (emojiData) => {
    setEmoji(emojiData.emoji);
    setShowEmojiPicker(false);
  };

  const handleSubmit = () => {
    if (!title || !emotion || !content) {
      alert("Please fill in all required fields.");
      return;
    }
    console.log({ emoji, title, emotion, content, tags });
    setShowSnackbar(true);
  };

  return (
    <Paper
      elevation={6}
      sx={{
        maxWidth: "800px",
        mx: "auto",
        borderRadius: 4,
        p: { xs: 3, sm: 5 },
        backgroundColor: "rgba(255, 255, 255, 0.95)",
        backdropFilter: "blur(10px)",
      }}
    >
      <Typography
        variant="h5"
        fontWeight={600}
        textAlign="center"
        mb={3}
        sx={{ fontStyle: "italic" }}
      >
        Share What’s On Your Mind ?
      </Typography>

      <EmojiSelector
        emoji={emoji}
        showEmojiPicker={showEmojiPicker}
        setShowEmojiPicker={setShowEmojiPicker}
        handleEmojiClick={handleEmojiClick}
      />

      <TextField
        label="Title"
        variant="outlined"
        fullWidth
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        sx={{ mb: 3 }}
      />

      <EmotionalLabels emotion={emotion} setEmotion={setEmotion} />

      <Box mb={3}>
        <Typography fontWeight={600} mb={1}>
          Content
        </Typography>
       <TextField
  variant="outlined"
  fullWidth
  multiline
  minRows={5}
  maxRows={15}
  placeholder="Share your thoughts here..."
  value={content}
  onChange={(e) => setContent(e.target.value)}
  sx={{
    width: "100%",
    "& .MuiInputBase-root": {
      alignItems: "flex-start", // aligns text at the top
    },
  }}
/>
      </Box>

      <TagInput
        tags={tags}
        newTag={newTag}
        setNewTag={setNewTag}
        handleAddTag={handleAddTag}
      />

      <Box display="flex" justifyContent="flex-end">
        <Button variant="contained" size="large" onClick={handleSubmit}>
          Send
        </Button>
      </Box>

      <Snackbar
        open={showSnackbar}
        autoHideDuration={4000}
        onClose={() => setShowSnackbar(false)}
        message="Post submitted successfully!"
      />
    </Paper>
  );
};

export default PostForm;
