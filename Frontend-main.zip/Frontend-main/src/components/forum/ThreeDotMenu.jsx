import React from "react";
import { Menu, MenuItem } from "@mui/material";

/**
 * ThreeDotMenu - A reusable menu for post/comment actions
 * @param {object} props
 * @param {HTMLElement} props.anchorEl - The anchor element for the menu
 * @param {boolean} props.isOwner - Whether the current user is the owner
 * @param {function} props.onClose - Function to close the menu
 * @param {function} [props.onUpdate] - Function to update (if owner)
 * @param {function} [props.onDelete] - Function to delete (if owner)
 * @param {function} [props.onReport] - Function to report (if not owner)
 */
const ThreeDotMenu = ({ anchorEl, isOwner, onClose, onUpdate, onDelete, onReport }) => (
  <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={onClose}>
    {isOwner ? (
      [
        <MenuItem key="update" onClick={onUpdate}>Update</MenuItem>,
        <MenuItem key="delete" onClick={onDelete}>Delete</MenuItem>
      ]
    ) : (
      <MenuItem key="report" onClick={onReport}>Report</MenuItem>
    )}
  </Menu>
);

export default ThreeDotMenu;
