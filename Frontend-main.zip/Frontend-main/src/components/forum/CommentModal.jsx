import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
} from "@mui/material";

const CommentModal = ({ open, onClose, onSubmit, value, onChange }) => (
  <Dialog open={open} onClose={onClose} PaperProps={{ sx: { zIndex: 2000 } }}>
    <DialogTitle>Add a Comment</DialogTitle>
    <DialogContent>
      <TextField
        autoFocus
        margin="dense"
        label="Comment"
        color="secondary"
        type="text"
        fullWidth
        multiline
        minRows={3}
        value={value}
        onChange={onChange}
      />
    </DialogContent>
    <DialogActions>
      <Button color="secondary" onClick={onClose}>
        Cancel
      </Button>
      <Button
        color="secondary"
        variant="contained"
        onClick={onSubmit}
        disabled={!value.trim()}
      >
        Submit
      </Button>
    </DialogActions>
  </Dialog>
);

export default CommentModal;
