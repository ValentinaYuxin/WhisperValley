import { Skeleton, Card, CardContent } from "@mui/material";

const PostSkeleton = () => (
  <Card sx={{ borderRadius: 3, mb: 2 }}>
    <CardContent>
      <Skeleton variant="rectangular" height={32} sx={{ mb: 2 }} />
      <Skeleton variant="text" height={24} sx={{ mb: 1 }} />
      <Skeleton variant="text" height={18} width="80%" />
      <Skeleton variant="text" height={18} width="60%" />
    </CardContent>
  </Card>
);

export default PostSkeleton;