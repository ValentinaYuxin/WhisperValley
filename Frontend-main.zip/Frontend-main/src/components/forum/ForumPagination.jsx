import { Pagination, Box } from "@mui/material";

const ForumPagination = ({ totalPages, currentPage, onPageChange }) => (
  totalPages > 1 ? (
    <Box display="flex" justifyContent="center" mt={3}>
      <Pagination
        count={totalPages}
        page={currentPage}
        onChange={(e, page) => onPageChange(page)}
        color="primary"
        sx={{
          '& .MuiPaginationItem-root': {
            color: '#6a1b9a', // purple text
            borderRadius: 2,
            fontWeight: 500,
            '&.Mui-selected': {
              bgcolor: '#8e24aa', // purple background for selected
              color: '#fff',
              '&:hover': {
                bgcolor: '#6a1b9a',
              }
            },
            '&:hover': {
              bgcolor: 'rgba(142, 36, 170, 0.1)',
            }
          }
        }}
      />
    </Box>
  ) : null
);

export default ForumPagination;
