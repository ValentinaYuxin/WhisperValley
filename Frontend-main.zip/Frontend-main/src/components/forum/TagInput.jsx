import React, { useCallback } from "react";
import { Box, TextField, Button, Chip, Stack, Typography } from "@mui/material";
import { useDispatch } from "react-redux";
import axios from "axios";
import { setStatus, setError } from "../slices/uiSlice";
import { postCreated } from "../slices/postSlice";
import { API_URL } from "../config";

const TagInput = ({ tags, newTag, setNewTag, handleAddTag, onRemoveTag }) => {
  const dispatch = useDispatch();

  const createPost = useCallback(
    async (postData) => {
      dispatch(setStatus("loading"));

      try {
        const response = await axios.post(`${API_URL}/posts`, postData, {
          withCredentials: true,
        });

        dispatch(postCreated(response.data));
        return response.data;
      } catch (error) {
        const errorMessage = error.response?.data?.error || "Failed to create post";
        dispatch(setError(errorMessage));
        return null;
      }
    },
    [dispatch]
  );

  return (
    <Box mb={3}>
      <Typography fontWeight={600} mb={1}>
        Add tags (optional)
      </Typography>
      <Stack direction="row" spacing={1} sx={{ mb: 2, flexWrap: "wrap" }}>
        {tags.map((tag, index) => (
          <Chip
            key={index}
            label={tag}
            onDelete={() => onRemoveTag && onRemoveTag(tag)}
            sx={{
              mb: 1,
              bgcolor: "rgba(142, 36, 170, 0.1)",
              color: "#8e24aa",
              "&:hover": { bgcolor: "rgba(142, 36, 170, 0.2)" },
            }}
          />
        ))}
      </Stack>
      <Box display="flex" gap={1}>
        <TextField
          size="small"
          placeholder="Type a tag and press Enter"
          value={newTag}
          onChange={(e) => setNewTag(e.target.value)}
          onKeyPress={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              handleAddTag();
            }
          }}
          fullWidth
        />
        <Button
          variant="outlined"
          onClick={handleAddTag}
          disabled={!newTag.trim()}
          sx={{
            color: "#8e24aa",
            borderColor: "#8e24aa",
            "&:hover": {
              borderColor: "#6a1b9a",
              backgroundColor: "rgba(142, 36, 170, 0.08)",
            },
          }}
        >
          Add
        </Button>
      </Box>
    </Box>
  );
};

export default TagInput;
