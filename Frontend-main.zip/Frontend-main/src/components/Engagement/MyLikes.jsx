import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Divider,
  RadioGroup,
  FormControlLabel,
  Radio,
  Pagination,
} from "@mui/material";
import axios from "axios";
import dayjs from "dayjs";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export default function MyLikes() {
  const [likes, setLikes] = useState([]);
  const [filter, setFilter] = useState("all");
  const [page, setPage] = useState(1);
  const likesPerPage = 10;

  const token = useSelector((state) => state.user.tokenData?.token);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchLikes = async () => {
      if (!token) {
        setLikes([]);
        return;
      }

      try {
        const res = await axios.get(
          "http://localhost:8080/api/v1/profiles/liked-posts",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        if (res.data.success) {
          const allLikes = res.data.data;
          const now = dayjs();

          let filtered = allLikes;
          if (filter === "7days") {
            filtered = allLikes.filter((like) =>
              dayjs(like.likedAt).isAfter(now.subtract(7, "day"))
            );
          } else if (filter === "30days") {
            filtered = allLikes.filter((like) =>
              dayjs(like.likedAt).isAfter(now.subtract(30, "day"))
            );
          }

          setLikes(filtered);
          setPage(1);
        }
      } catch (err) {
        console.error("Failed to fetch likes:", err);
        setLikes([]);
      }
    };

    fetchLikes();
  }, [filter, token]);

  // Pagination slice
  const indexOfLast = page * likesPerPage;
  const indexOfFirst = indexOfLast - likesPerPage;
  const currentLikes = likes.slice(indexOfFirst, indexOfLast);

  const handlePageChange = (event, value) => {
    setPage(value);
    const container = document.getElementById("likes-container");
    if (container) container.scrollIntoView({ behavior: "smooth" });
  };

  const handlePostClick = (postId) => {
    if (postId) {
      navigate(`/forum/posts/${postId}`);
    }
  };

  return (
    <Box id="likes-container">
      <Typography variant="h5" fontWeight="bold" color="secondary" mb={2}>
        My Likes
      </Typography>

      <Box mb={3}>
        <Typography variant="subtitle1" fontWeight="bold" mb={1}>
          Filter by Date
        </Typography>
        <RadioGroup
          row
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <FormControlLabel
            value="all"
            control={<Radio color="secondary" />}
            label="All Time"
          />
          <FormControlLabel
            value="7days"
            control={<Radio color="secondary" />}
            label="Past 7 Days"
          />
          <FormControlLabel
            value="30days"
            control={<Radio color="secondary" />}
            label="Past 30 Days"
          />
        </RadioGroup>
      </Box>

      {currentLikes.length === 0 ? (
        <Typography>No liked posts found.</Typography>
      ) : (
        currentLikes.map((like) => (
          <Card
            key={like._id}
            sx={{ mb: 3, cursor: "pointer" }}
            onClick={() => handlePostClick(like._id)}
          >
            <CardContent>
              {/* Related Posts */}
              <Typography variant="subtitle1" fontWeight="bold" mb={1}>
                {like.title || "No title"}
              </Typography>
              <Typography variant="body2" color="black" mb={1}>
                {like.author || "Unknown Author"}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                {like.content
                  ? like.content.length > 100
                    ? like.content.slice(0, 100) + "..."
                    : like.content
                  : ""}
              </Typography>

              <Divider sx={{ mb: 1 }} />
              <Typography variant="caption" color="gray">
                Liked on {new Date(like.likedAt).toLocaleString()}
              </Typography>
            </CardContent>
          </Card>
        ))
      )}

      {likes.length > likesPerPage && (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
          <Pagination
            count={Math.ceil(likes.length / likesPerPage)}
            page={page}
            onChange={handlePageChange}
            color="secondary"
            shape="rounded"
            siblingCount={1}
            boundaryCount={1}
          />
        </Box>
      )}
    </Box>
  );
}
