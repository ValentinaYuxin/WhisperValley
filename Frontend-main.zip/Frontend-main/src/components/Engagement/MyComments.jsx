import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Divider,
  RadioGroup,
  FormControlLabel,
  Radio,
  Pagination,
} from "@mui/material";
import axios from "axios";
import dayjs from "dayjs";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export default function MyComments() {
  const [comments, setComments] = useState([]);
  const [filter, setFilter] = useState("all");
  const [page, setPage] = useState(1);
  const postsPerPage = 10;

  // Get the auth token from Redux store for API requests
  const token = useSelector((state) => state.user.tokenData?.token);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchComments = async () => {
      if (!token) {
        // If no token (not logged in), clear comments
        setComments([]);
        return;
      }

      try {
        // Fetch all comments made by the user
        const res = await axios.get(
          "http://localhost:8080/api/v1/profiles/comments",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        if (res.data.success) {
          const allComments = res.data.data;
          const now = dayjs();

          // Filter comments based on selected filter option
          let filtered = allComments;
          if (filter === "7days") {
            filtered = allComments.filter((c) =>
              dayjs(c.createdAt).isAfter(now.subtract(7, "day"))
            );
          } else if (filter === "30days") {
            filtered = allComments.filter((c) =>
              dayjs(c.createdAt).isAfter(now.subtract(30, "day"))
            );
          }

          setComments(filtered);
          setPage(1); // Reset to first page on filter change
        }
      } catch (err) {
        console.error("Failed to fetch comments:", err);
        setComments([]);
      }
    };

    fetchComments();
  }, [filter, token]);

  // Calculate indices for slicing comments array to current page
  const indexOfLast = page * postsPerPage;
  const indexOfFirst = indexOfLast - postsPerPage;
  const currentComments = comments.slice(indexOfFirst, indexOfLast);

  // Handler for page number change in pagination
  const handlePageChange = (event, value) => {
    setPage(value);
    const container = document.getElementById("comments-container");
    if (container) container.scrollIntoView({ behavior: "smooth" });
  };

  // Navigate to post detail page when clicking a comment card
  const handlePostClick = (postId) => {
    if (postId) {
      navigate(`/forum/posts/${postId}`);
    }
  };

  return (
    <Box id="comments-container">
      <Typography variant="h5" fontWeight="bold" color="secondary" mb={2}>
        My Comments
      </Typography>

      <Box mb={3}>
        <Typography variant="subtitle1" fontWeight="bold" mb={1}>
          Filter by Date
        </Typography>
        <RadioGroup
          row
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <FormControlLabel
            value="all"
            control={<Radio color="secondary" />}
            label="All Time"
          />
          <FormControlLabel
            value="7days"
            control={<Radio color="secondary" />}
            label="Past 7 Days"
          />
          <FormControlLabel
            value="30days"
            control={<Radio color="secondary" />}
            label="Past 30 Days"
          />
        </RadioGroup>
      </Box>

      {/* Display message if no comments found */}
      {currentComments.length === 0 ? (
        <Typography>No comments found.</Typography>
      ) : (
        // Render each comment card
        currentComments.map((comment) => (
          <Card
            key={comment._id}
            sx={{
              mb: 3,
              backgroundColor: "#fefefe",
              borderRadius: 2,
              boxShadow: 1,
              cursor: comment.post?._id ? "pointer" : "default",
            }}
            onClick={() => handlePostClick(comment.post?._id)}
          >
            <CardContent>
              {/* Comment content */}
              <Typography variant="body1" mb={1}>
                {comment.content}
              </Typography>

              <Divider sx={{ my: 2 }} />

              <Typography variant="subtitle2" color="black" gutterBottom>
                📌 Post: <strong>{comment.post?.title || "N/A"}</strong> by{" "}
                <em>{comment.post?.author || "Unknown"}</em>
              </Typography>

              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                {comment.post?.content
                  ? comment.post.content.length > 100
                    ? comment.post.content.slice(0, 100) + "..."
                    : comment.post.content
                  : ""}
              </Typography>

              <Typography variant="caption" color="gray" display="block">
                Commented on {new Date(comment.createdAt).toLocaleString()}
              </Typography>
            </CardContent>
          </Card>
        ))
      )}

      {/* Pagination control if comments exceed postsPerPage */}
      {comments.length > postsPerPage && (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
          <Pagination
            count={Math.ceil(comments.length / postsPerPage)}
            page={page}
            onChange={handlePageChange}
            color="secondary"
            shape="rounded"
            siblingCount={1}
            boundaryCount={1}
          />
        </Box>
      )}
    </Box>
  );
}
