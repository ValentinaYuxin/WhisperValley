import React from "react";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import { styled } from "@mui/material/styles";
import { useUser } from "../hooks/useRedux";
import { useSubscription } from "../hooks/useSubscription.js";
import NotificationDropdown from "../components/Notification/NotificationDropdown";
import LockOutlineIcon from "@mui/icons-material/LockOutline";
import Avatar from "@mui/material/Avatar";
import Tooltip from "@mui/material/Tooltip";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Container from "@mui/material/Container";
import Drawer from "@mui/material/Drawer";
import Divider from "@mui/material/Divider";
import MenuIcon from "@mui/icons-material/Menu";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";

// Added for logout confirmation dialog
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogActions from "@mui/material/DialogActions";

// Styled toolbar with a frosted glass effect
const StyledToolbar = styled(Toolbar)({
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  flexShrink: 0,
  borderRadius: "15px",
  backdropFilter: "blur(20px)",
  backgroundColor: "rgba(255, 255, 255, 0.7)",
  boxShadow: "0px 1px 3px rgba(0, 0, 0, 0.2)",
  padding: "0px 12px",
});

export default function Header({ unreadCount = 0 }) {
  const { user, logout } = useUser();
  const { current: sub } = useSubscription();
  const navigate = useNavigate();

  const [anchorElUser, setAnchorElUser] = React.useState(null);

  const [drawerOpen, setDrawerOpen] = React.useState(false);

  const [anchorElInnerVoice, setAnchorElInnerVoice] = React.useState(null);

  const [logoutDialogOpen, setLogoutDialogOpen] = React.useState(false);

  const handleOpenInnerVoiceMenu = (event) =>
    setAnchorElInnerVoice(event.currentTarget);
  const handleCloseInnerVoiceMenu = () => setAnchorElInnerVoice(null);
  const handleOpenUserMenu = (event) => setAnchorElUser(event.currentTarget);
  const handleCloseUserMenu = () => setAnchorElUser(null);

  // Logout handler with confirmation
  const handleLogout = () => {
    setLogoutDialogOpen(false); // close the dialog first
    logout(); // clear user state
    handleCloseUserMenu();
    navigate("/signin");
  };

  // Get full avatar URL (supports relative and absolute URLs)
  const getFullAvatarUrl = (avatarPath) => {
    if (!avatarPath) return "";
    if (avatarPath.startsWith("http")) return avatarPath;
    return `http://localhost:8080${avatarPath}`;
  };

  const subPlan = sub ? sub.plan : "free";

  const navLinks = user
    ? [
        { title: "Home", url: "/" },
        { title: "Forum", url: "/forum" },
        {
          title: "Inner voice",
          url: subPlan === "premium" ? "/innervoice" : "/pricing",
          locked: subPlan !== "premium",
        },
        { title: "Pricing", url: "/pricing" },
        { title: "FAQ", url: "/#faq" },
        { title: "Contact", url: "/contact" },
      ]
    : [
        { title: "Home", url: "/" },
        { title: "Features", url: "/#features" },
        { title: "Pricing", url: "/pricing" },
        { title: "FAQ", url: "/#faq" },
        { title: "Contact", url: "/contact" },
      ];

  return (
    <AppBar
      position="fixed"
      sx={{
        boxShadow: 0,
        bgcolor: "transparent",
        backgroundImage: "none",
        mt: "25px",
      }}
    >
      <Container maxWidth="lg">
        <StyledToolbar>
          {/* ===== Logo ===== */}
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 2,
              cursor: "pointer",
            }}
            onClick={() => navigate("/")}
          >
            <img src="/logo.png" alt="Logo" style={{ height: 40 }} />
          </Box>

          {/* ===== Desktop navigation ===== */}
          <Box
            sx={{
              display: { xs: "none", lg: "flex" },
              gap: 3,
              justifyContent: "center",
              flexGrow: 1,
            }}
          >
            <Button component={RouterLink} to="/" sx={navBtnStyle}>
              Home
            </Button>

            {user ? (
              <>
                <Button component={RouterLink} to="/forum" sx={navBtnStyle}>
                  Forum
                </Button>

                {subPlan?.toLowerCase() === "premium" ? (
                  <>
                    <Button
                      sx={navBtnStyle}
                      endIcon={<MenuIcon />}
                      onClick={handleOpenInnerVoiceMenu}
                    >
                      Inner voice
                    </Button>
                    <Menu
                      anchorEl={anchorElInnerVoice}
                      open={Boolean(anchorElInnerVoice)}
                      onClose={handleCloseInnerVoiceMenu}
                      PaperProps={{ sx: { borderRadius: 2, mt: 1 } }}
                    >
                      <MenuItem
                        onClick={() => {
                          navigate("/dashboard");
                          handleCloseInnerVoiceMenu();
                        }}
                        sx={menuItemStyle}
                      >
                        Dashboard
                      </MenuItem>
                      <MenuItem
                        onClick={() => {
                          navigate("/journals");
                          handleCloseInnerVoiceMenu();
                        }}
                        sx={menuItemStyle}
                      >
                        Journal
                      </MenuItem>
                    </Menu>
                  </>
                ) : (
                  <Button component={RouterLink} to="/pricing" sx={navBtnStyle}>
                    Inner voice
                    <LockOutlineIcon
                      fontSize="small"
                      color="secondary"
                      sx={{
                        position: "absolute",
                        top: 2,
                        right: -2,
                        fontSize: 16,
                      }}
                    />
                  </Button>
                )}

                <Button component={RouterLink} to="/pricing" sx={navBtnStyle}>
                  Pricing
                </Button>
                <Button component={RouterLink} to="/#faq" sx={navBtnStyle}>
                  FAQ
                </Button>
                <Button component={RouterLink} to="/contact" sx={navBtnStyle}>
                  Contact
                </Button>
              </>
            ) : (
              <>
                <Button component={RouterLink} to="/#features" sx={navBtnStyle}>
                  Features
                </Button>
                <Button component={RouterLink} to="/pricing" sx={navBtnStyle}>
                  Pricing
                </Button>
                <Button component={RouterLink} to="/#faq" sx={navBtnStyle}>
                  FAQ
                </Button>
                <Button component={RouterLink} to="/contact" sx={navBtnStyle}>
                  Contact
                </Button>
              </>
            )}
          </Box>

          {/* ===== Right section (avatar or sign in) ===== */}
          <Box
            sx={{
              display: { xs: "none", lg: "flex" },
              gap: 1,
              alignItems: "center",
            }}
          >
            {user ? (
              <>
                {/* Notification bell with dropdown */}
                <NotificationDropdown unreadCount={unreadCount} />
                {/* Avatar and menu */}
                <Tooltip title={user.username || "User"}>
                  <IconButton onClick={handleOpenUserMenu}>
                    <Avatar
                      alt={user.username || "U"}
                      src={getFullAvatarUrl(user.avatar)}
                      sx={{ width: 45, height: 45 }}
                    >
                      {(!user.avatar || user.avatar === "") && user.avatarEmoji}
                    </Avatar>
                  </IconButton>
                </Tooltip>
                {/* Avatar menu */}
                <Menu
                  sx={{ mt: "45px" }}
                  anchorEl={anchorElUser}
                  anchorOrigin={{ vertical: "top", horizontal: "center" }}
                  keepMounted
                  transformOrigin={{ vertical: "top", horizontal: "center" }}
                  open={Boolean(anchorElUser)}
                  onClose={handleCloseUserMenu}
                  PaperProps={{ sx: { borderRadius: 3, mt: 1 } }}
                >
                  {["Profile", "My Posts", "My Engagements", "Logout"].map(
                    (setting) => (
                      <MenuItem
                        key={setting}
                        onClick={() => {
                          if (setting === "Logout") {
                            // Open confirmation dialog
                            setLogoutDialogOpen(true);
                            handleCloseUserMenu();
                          } else {
                            navigate(
                              `/${setting.toLowerCase().replace(/\s+/g, "")}`
                            );
                          }
                        }}
                        sx={menuItemStyle}
                      >
                        <Typography>{setting}</Typography>
                      </MenuItem>
                    )
                  )}
                </Menu>
              </>
            ) : (
              <>
                <Button
                  variant="text"
                  size="medium"
                  component={RouterLink}
                  to="/signin"
                  sx={{
                    color: "#6a1b9a",
                    fontSize: "1rem",
                    "&:hover": {
                      borderRadius: 8,
                      backgroundColor: "rgba(155, 89, 182, 0.1)",
                    },
                  }}
                >
                  Sign in
                </Button>
                <Button
                  variant="contained"
                  size="medium"
                  component={RouterLink}
                  to="/signup"
                  sx={{
                    borderRadius: 8,
                    backgroundColor: "#6a1b9a",
                    fontSize: "1rem",
                    paddingY: "4px",
                    paddingX: "12px",
                    "&:hover": {
                      backgroundColor: "#8e44ad",
                    },
                  }}
                >
                  Get Started
                </Button>
              </>
            )}
          </Box>

          {/* ===== Mobile menu icon ===== */}
          <Box sx={{ display: { xs: "flex", lg: "none" } }}>
            <IconButton onClick={() => setDrawerOpen(true)}>
              <MenuIcon sx={{ color: "#6a1b9a" }} />
            </IconButton>
          </Box>
        </StyledToolbar>
      </Container>

      {/* ===== Drawer (mobile menu) ===== */}
      <Drawer
        anchor="top"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        PaperProps={{ sx: { p: 2, backgroundColor: "#f3e5f5" } }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <img src="/logo.png" alt="Logo" style={{ height: 40 }} />
          <IconButton onClick={() => setDrawerOpen(false)}>
            <CloseRoundedIcon />
          </IconButton>
        </Box>
        <Box sx={{ mt: 2 }}>
          {navLinks.map((link) => (
            <MenuItem
              key={link.title}
              onClick={() => {
                navigate(link.url);
                setDrawerOpen(false);
              }}
              sx={{
                color: "#4a148c",
                borderRadius: 2,
                position: "relative",
                "&:hover": { bgcolor: "#6a1b9a", color: "white" },
              }}
            >
              {link.title}
              {link.locked && (
                <LockOutlineIcon
                  fontSize="small"
                  color="secondary"
                  sx={{
                    position: "absolute",
                    right: 8,
                    top: "50%",
                    transform: "translateY(-50%)",
                    fontSize: 16,
                  }}
                />
              )}
            </MenuItem>
          ))}
        </Box>
        <Divider sx={{ my: 2 }} />
        {user ? (
          <MenuItem
            onClick={() => {
              navigate("/profile");
              setDrawerOpen(false);
            }}
            sx={{
              color: "#4a148c",
              borderRadius: 8,
              "&:hover": { bgcolor: "#6a1b9a", color: "white" },
            }}
          >
            Profile
          </MenuItem>
        ) : null}
        {user ? (
          <MenuItem
            onClick={() => {
              setLogoutDialogOpen(true); // open dialog in mobile too
              setDrawerOpen(false);
            }}
            sx={{
              color: "#4a148c",
              borderRadius: 8,
              "&:hover": { bgcolor: "#6a1b9a", color: "white" },
            }}
          >
            Logout
          </MenuItem>
        ) : (
          <>
            <MenuItem
              onClick={() => {
                navigate("/signup");
                setDrawerOpen(false);
              }}
              sx={{
                color: "#4a148c",
                borderRadius: 2,
                "&:hover": { bgcolor: "#6a1b9a", color: "white" },
              }}
            >
              Sign up
            </MenuItem>
            <MenuItem
              onClick={() => {
                navigate("/signin");
                setDrawerOpen(false);
              }}
              sx={{
                color: "#4a148c",
                borderRadius: 2,
                "&:hover": { bgcolor: "#6a1b9a", color: "white" },
              }}
            >
              Sign in
            </MenuItem>
          </>
        )}
      </Drawer>

      {/* ===== Logout confirmation dialog ===== */}
      <Dialog
        open={logoutDialogOpen}
        onClose={() => setLogoutDialogOpen(false)}
      >
        <DialogTitle
          sx={{ color: "#4b0082", fontWeight: "bold", textAlign: "center" }}
        >
          Are you sure you want to log out?
        </DialogTitle>
        <DialogActions sx={{ justifyContent: "center", pb: 2 }}>
          <Button
            variant="outlined"
            onClick={() => setLogoutDialogOpen(false)}
            sx={{
              color: "#4b0082",
              borderColor: "#4b0082",
              textTransform: "none",
              mr: 1.5,
              "&:hover": {
                borderColor: "#6a1b9a",
                backgroundColor: "#f3e8ff",
              },
            }}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={handleLogout}
            sx={{
              backgroundColor: "#4b0082",
              textTransform: "none",
              "&:hover": {
                backgroundColor: "#6a1b9a",
              },
            }}
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </AppBar>
  );
}

// ===== Shared button styles =====
const navBtnStyle = {
  position: "relative",
  textTransform: "none",
  fontSize: "1.1rem",
  color: "#6a1b9a",
  borderRadius: "16px",
  whiteSpace: "nowrap",
  "&:hover": {
    backgroundColor: "rgba(155, 89, 182, 0.15)",
  },
};

const menuItemStyle = {
  color: "#4a148c",
  "&:hover": {
    backgroundColor: "#6a1b9a",
    color: "white",
  },
};

const unreadBadgeStyle = {
  position: "absolute",
  top: -4,
  right: -4,
  minWidth: 16,
  height: 16,
  bgcolor: "#e53935",
  color: "#fff",
  borderRadius: "50%",
  fontSize: 11,
  fontWeight: 700,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  px: 0.5,
  zIndex: 1,
};
