import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Menu,
  MenuItem,
  IconButton,
  Badge,
  Box,
  Typography,
  CircularProgress,
  Avatar,
  ListItemAvatar,
  ListItemText,
  Divider,
} from "@mui/material";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import CommentIcon from "@mui/icons-material/ChatBubbleOutline";
import ThumbUpIcon from "@mui/icons-material/ThumbUpAltOutlined";
import StarIcon from "@mui/icons-material/StarOutline";
import { useNavigate } from "react-router-dom";
import { useNotifications } from "../../hooks/useNotifications";

export default function NotificationDropdown({ unreadCount }) {
  const { notifications = [], status, fetchNotifications } = useNotifications();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const navigate = useNavigate();

  const handleOpen = (event) => setAnchorEl(event.currentTarget);
  const handleClose = () => setAnchorEl(null);

  useEffect(() => {
    if (open) {
      fetchNotifications({ page: 1, limit: 7 });
    }
  }, [open, fetchNotifications]);

  // handle click notification
  const handleNotificationClick = (notif) => {
    handleClose();
    // navigate to different pages depending on notification type
    if (notif.type === "like") {
      navigate("/notification?tab=Received Likes");
    } else if (notif.type === "comment") {
      navigate("/notification?tab=Received Comments");
    } else {
      navigate("/notification");
    }
  };

  // handle click view all
  const handleViewAll = () => {
    handleClose();
    // Find first unread notification
    const firstUnread = notifications.find((n) => n.isRead === false);
    if (firstUnread) {
      // Go to page according to first unread type
      if (firstUnread.type === "like") {
        navigate("/notification?tab=Received Likes");
      } else if (firstUnread.type === "comment") {
        navigate("/notification?tab=Received Comments");
      } else {
        navigate("/notification?tab=Received Comments");
      }
    } else {
      // No unread notifications, default to Received Comments
      navigate("/notification?tab=Received Comments");
    }
  };

  return (
    <Box>
      <IconButton onClick={handleOpen} sx={{ position: "relative" }}>
        <Badge badgeContent={unreadCount} color="error">
          <NotificationsNoneIcon sx={{ color: "#6a1b9a", fontSize: 22 }} />
        </Badge>
      </IconButton>
      <Menu
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          sx: {
            borderRadius: 3,
            minWidth: 360,
            maxWidth: 420,
            p: 0,
            boxShadow: 6,
          },
        }}
        MenuListProps={{ sx: { p: 0 } }}
      >
        <Box
          sx={{
            px: 2,
            py: 1.5,
            borderBottom: "1px solid #eee",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Typography variant="subtitle1" fontWeight={700} color="#6a1b9a">
            Notifications
          </Typography>
          {status === "loading" && (
            <CircularProgress size={18} sx={{ ml: 1 }} />
          )}
        </Box>
        {notifications.length === 0 ? (
          <MenuItem disabled sx={{ py: 3, justifyContent: "center" }}>
            No notifications
          </MenuItem>
        ) : (
          notifications.flatMap((notif, idx) => [
            <MenuItem
              key={notif._id}
              onClick={() => handleNotificationClick(notif)}
              sx={{
                alignItems: "flex-start",
                gap: 2,
                bgcolor: notif.isRead ? "#fff" : "#ede7f6",
                borderLeft: notif.isRead
                  ? "4px solid transparent"
                  : "4px solid #6a1b9a",
                py: 1.5,
                px: 2,
                transition: "background 0.2s",
                "&:hover": { bgcolor: "#f3e5f5" },
                minHeight: 64,
              }}
            >
              <ListItemAvatar>
                <Avatar
                  sx={{
                    width: 40,
                    height: 40,
                    bgcolor:
                      notif.type === "like"
                        ? "#e1bee7"
                        : notif.type === "comment"
                        ? "#d1a4f8"
                        : "#ffe082",
                    color: "#6a1b9a",
                    fontWeight: 700,
                  }}
                >
                  {notif.type === "like" ? (
                    <ThumbUpIcon fontSize="small" />
                  ) : notif.type === "comment" ? (
                    <CommentIcon fontSize="small" />
                  ) : (
                    <StarIcon fontSize="small" />
                  )}
                </Avatar>
              </ListItemAvatar>
              <ListItemText
                primary={
                  <Typography
                    variant="body2"
                    fontWeight={notif.isRead ? 400 : 700}
                    sx={{ color: notif.isRead ? "#333" : "#6a1b9a" }}
                  >
                    {notif.type === "comment" ? (
                      <>
                        <b>{notif.senderName}</b> commented: {notif.content}
                      </>
                    ) : notif.type === "like" ? (
                      <>
                        <b>{notif.senderName}</b>{" "}
                        {notif.targetType === "Comment"
                          ? "liked your comment"
                          : "liked your post"}
                      </>
                    ) : null}
                  </Typography>
                }
                secondary={
                  <>
                    {notif.post && notif.post.title && (
                      <Typography
                        component="span"
                        variant="caption"
                        color="text.secondary"
                        sx={{ display: "block" }}
                      >
                        Post: {notif.post.title}
                      </Typography>
                    )}
                    <Typography
                      component="span"
                      variant="caption"
                      color="text.secondary"
                    >
                      {new Date(notif.createdAt).toLocaleString()}
                    </Typography>
                  </>
                }
              />
            </MenuItem>,
            idx < notifications.length - 1 ? (
              <Divider key={`divider-${notif._id}`} sx={{ my: 0, mx: 2 }} />
            ) : null,
          ])
        )}
        <Divider sx={{ my: 0 }} />
        <MenuItem
          onClick={handleViewAll}
          sx={{
            justifyContent: "center",
            fontWeight: 700,
            color: "#6a1b9a",
            py: 1.5,
            fontSize: 16,
          }}
        >
          View all
        </MenuItem>
      </Menu>
    </Box>
  );
}
