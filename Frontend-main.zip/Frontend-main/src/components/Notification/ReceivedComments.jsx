import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Divider,
  Pagination,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useNotifications } from "../../hooks/useNotifications";

export default function ReceivedComments() {
  const [page, setPage] = useState(1);
  const limit = 10;
  const navigate = useNavigate();
  const {
    notifications = [],
    pagination,
    status,
    lastUnreadIdsByType = { comment: [], like: [] },
    fetchNotifications,
    markAllRead,
  } = useNotifications();

  useEffect(() => {
    // Fetch comment-type notifications
    fetchNotifications({ page, limit, type: "comment" })
      .unwrap()
      .then(() => {
        markAllRead("comment");
      })
      .catch((err) => {
        console.error("Failed to fetch comment notifications:", err);
      });
  }, [page, fetchNotifications, markAllRead]);

  const handleClick = (postId) => {
    if (postId) navigate(`/forum/posts/${postId}`);
  };

  // Handle pagination change
  const handlePageChange = (e, value) => {
    setPage(value);
    document
      .getElementById("notification-container")
      ?.scrollIntoView({ behavior: "smooth" });
  };

  // Determine if a notification should be highlighted
  // These are notifications that were unread when fetched and then marked as read
  const commentIds = Array.isArray(lastUnreadIdsByType?.comment)
    ? lastUnreadIdsByType.comment
    : [];
  const isHighlighted = (id) => commentIds.includes(id);

  return (
    <Box id="notification-container">
      <Typography variant="h5" fontWeight="bold" color="secondary" mb={2}>
        Received Comments
      </Typography>

      {status === "loading" && <Typography>Loading...</Typography>}
      {status !== "loading" && notifications.length === 0 && (
        <Typography>No one has commented on your posts yet.</Typography>
      )}

      {notifications.map((n) => (
        <Card
          key={n._id}
          sx={{
            mb: 3,
            borderRadius: 2,
            boxShadow: 1,
            cursor: n.post?._id ? "pointer" : "default",
            backgroundColor: isHighlighted(n._id) ? "#f3e8ff" : "#fefefe",
          }}
          onClick={() => handleClick(n.post?._id)}
        >
          <CardContent>
            <Typography variant="subtitle2" gutterBottom>
              🧑 <strong>{n.senderName}</strong> commented:
            </Typography>
            <Typography variant="body1">{n.content}</Typography>
            <Divider sx={{ my: 2 }} />
            <Typography variant="body2" color="text.secondary">
              📌 On Post: <strong>{n.post?.title || "N/A"}</strong>
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {n.post?.content ? n.post.content.slice(0, 100) + "..." : ""}
            </Typography>
            <Typography variant="caption" display="block" mt={1} color="gray">
              {new Date(n.createdAt).toLocaleString()}
            </Typography>
          </CardContent>
        </Card>
      ))}

      {pagination?.pages > 1 && (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 4, pb: 4 }}>
          <Pagination
            count={pagination.pages}
            page={page}
            onChange={handlePageChange}
            color="secondary"
            shape="rounded"
            siblingCount={1}
            boundaryCount={1}
          />
        </Box>
      )}
    </Box>
  );
}
