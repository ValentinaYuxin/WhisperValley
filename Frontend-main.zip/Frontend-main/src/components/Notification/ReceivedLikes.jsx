import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Divider,
  Pagination,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useNotifications } from "../../hooks/useNotifications";

export default function ReceivedLikes() {
  const [page, setPage] = useState(1);
  const limit = 10;
  const navigate = useNavigate();
  const {
    notifications = [],
    pagination,
    status,
    lastUnreadIdsByType = { comment: [], like: [] },
    fetchNotifications,
    markAllRead,
  } = useNotifications();

  // Fetch like-type notifications on page change
  useEffect(() => {
    fetchNotifications({ page, limit, type: "like" })
      .unwrap()
      .then(() => {
        markAllRead("like");
      })
      .catch((err) => {
        console.error("Failed to fetch like notifications:", err);
      });
  }, [page, fetchNotifications, markAllRead]);

  const handleClick = (postId) => {
    if (postId) navigate(`/forum/posts/${postId}`);
  };

  // Handle pagination change
  const handlePageChange = (e, value) => {
    setPage(value);
    document
      .getElementById("likes-notification-container")
      ?.scrollIntoView({ behavior: "smooth" });
  };

  // Determine if a notification should be highlighted
  const likeIds = Array.isArray(lastUnreadIdsByType?.like)
    ? lastUnreadIdsByType.like
    : [];
  const isHighlighted = (id) => likeIds.includes(id);

  return (
    <Box id="likes-notification-container">
      <Typography variant="h5" fontWeight="bold" color="secondary" mb={3}>
        Received Likes
      </Typography>

      {status === "loading" && <Typography>Loading...</Typography>}

      {status !== "loading" && notifications.length === 0 && (
        <Typography>No likes received yet.</Typography>
      )}

      {notifications.map((n) => {
        // Determine the text depending on targetType (Post or Comment)
        const likeTargetText =
          n.targetType === "Comment" ? "liked your comment" : "liked your post";

        return (
          <Card
            key={n._id}
            sx={{
              mb: 3,
              borderRadius: 2,
              boxShadow: 1,
              cursor: n.post?._id ? "pointer" : "default",
              backgroundColor: isHighlighted(n._id) ? "#f3e8ff" : "#fefefe",
            }}
            onClick={() => handleClick(n.post?._id)}
          >
            <CardContent>
              <Typography variant="subtitle2" gutterBottom>
                👍 <strong>{n.senderName}</strong> {likeTargetText}
              </Typography>

              <Divider sx={{ my: 2 }} />

              <Typography variant="body2" color="text.secondary">
                📌 On Post: <strong>{n.post?.title || "N/A"}</strong>
              </Typography>

              <Typography variant="caption" color="text.secondary">
                {n.post?.content ? n.post.content.slice(0, 100) + "..." : ""}
              </Typography>

              {/* Timestamp */}
              <Typography variant="caption" display="block" mt={1} color="gray">
                {new Date(n.createdAt).toLocaleString()}
              </Typography>
            </CardContent>
          </Card>
        );
      })}

      {/* Pagination */}
      {pagination?.pages > 1 && (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 4, pb: 4 }}>
          <Pagination
            count={pagination.pages}
            page={page}
            onChange={handlePageChange}
            color="secondary"
            shape="rounded"
            siblingCount={1}
            boundaryCount={1}
          />
        </Box>
      )}
    </Box>
  );
}
