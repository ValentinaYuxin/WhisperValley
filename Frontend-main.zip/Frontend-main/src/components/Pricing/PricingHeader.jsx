import React from 'react';
import { Box, Typography } from '@mui/material';

const PricingHeader = ({ user, subscription }) => {
    let title = "Unlock Your Emotional Potential";
    let descriptionTop = "Whispering Valley offers a private, powerful space for self-discovery. ";
    let descriptionBottom = "Experience the full potential of our Premium features with a 7-day free trial.";

    if (user) {
        title = `Hi ${user.username} 👋`;

        if (subscription) {
            if (subscription.plan === 'premium') {
                descriptionTop = "You're sparkling in Premium mode! 💎";
                descriptionBottom = "Enjoy unlimited journaling and smart emotional insights.";
            } else if (subscription.status === 'trialing') {
                descriptionTop = "Your 7-day free trial is in full swing! 🎉";
                descriptionBottom = "Make the most of your Premium perks while they last.";
            } else if (subscription.plan === 'free') {
                descriptionTop = "You're currently on the Free plan 🌱";
                descriptionBottom = "Upgrade anytime to unlock mood tracking and deeper insights!";
            }
        } else {
            descriptionTop = "Welcome aboard! 🚀";
            descriptionBottom = "Explore the plans below and find the best fit for your emotional journey.";
        }
    }

    return (
        <Box
            sx={{
                width: { sm: "100%", md: "60%" },
                textAlign: { sm: "left", md: "center" },
            }}
        >
            <Typography component="h2" variant="h4" gutterBottom sx={{ fontSize: 40 }}>
                {title}
            </Typography>
            <Typography variant="body1" sx={{ color: "white", fontSize: 20, mb: 1 }}>
                {descriptionTop}
            </Typography>
            <Typography variant="body1" sx={{ color: "white", fontSize: 20 }}>
                {descriptionBottom}
            </Typography>
        </Box>
    );
};

export default PricingHeader;