import * as React from "react";
import {
    Accordion,
    AccordionDetails,
    AccordionSummary,
    Box,
    Container,
    Link,
    Typography,
    Paper,
    Divider,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

export default function PricingFAQ() {
    const [expanded, setExpanded] = React.useState([]);

    const handleChange = (panel) => (event, isExpanded) => {
        setExpanded(
            isExpanded
                ? [...expanded, panel]
                : expanded.filter((item) => item !== panel)
        );
    };

    const subFAQs = [
        {
            id: "e1",
            question: "What happens after my 7-day free trial?",
            answer:
                "When your free trial wraps up, you'll smoothly transition to our Premium plan — no interruptions, just continued support! " +
                "You can cancel anytime before the 7 days are up if you decide to stick with Free.",
        },
        {
            id: "e2",
            question: "Can I cancel my subscription anytime?",
            answer:
                "Of course! You're always in control. Cancel anytime — and your current plan will remain active until the end of your billing period. No surprise goodbyes!",
        },
        {
            id: "e3",
            question: "How do I upgrade or downgrade my plan?",
            answer:
                "Super easy! Head over to your Profile settings after logging in — you’ll find all your subscription options ready for a change.",
        },
        {
            id: "e4",
            question: "What if I already have a free plan and want to upgrade to Premium?",
            answer:
                "That’s amazing to hear! Just tap on the Premium option and follow the prompts to start your trial or full plan. " +
                "Don’t worry — all your data stay right where they are.",
        },
    ];

    const paymentFAQs = [
        {
            id: "p1",
            question: "What payment methods do you accept?",
            answer:
                "We accept all major credit cards, such as Visa and Mastercard. Whatever works best for you.",
        },
        {
            id: "p2",
            question: "Is my payment information secure?",
            answer:
                "Absolutely. We partner with Stripe to handle payments securely and never store your card info ourselves. Your privacy and safety come first.",
        },
    ];

    const techFAQs = [
        {
            id: "p1",
            question: "Do I need an account to subscribe?",
            answer:
                "Yes, creating an account lets us keep your emotions and insights private and personalized just for you. " +
                "Think of it as your own emotional cloud diary.",
        },
        {
            id: "p2",
            question: "What happens to my data if I cancel my Premium subscription?",
            answer:
                "We’ll miss you but your data stays safe. Your account switches to Free, and while Premium features go on pause, your past reflections and entries remain accessible.",
        },
    ];

    const renderFAQGroup = (title, faqs, withDivider = false) => (
        <Box sx={{ mb: 8 }}>
            {withDivider && (
                <Divider sx={{ my: 6, borderColor: "#e1d5f5", borderBottomWidth: "2px", width: "100%",}}/>
            )}
            <Typography variant="h6" sx={{ fontWeight: "bold", mb: 2, mt: 4, color: "white", }}>
                {title}
            </Typography>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
                {faqs.map(({ id, question, answer }) => (
                    <Paper
                        key={id}
                        elevation={3}
                        sx={{
                            borderRadius: "32px",
                            px: { xs: 2, sm: 4 },
                            py: { xs: 1.5, sm: 2 },
                            bgcolor: "#d6c8ff",
                            transition: "box-shadow 0.3s ease",
                            "&:hover": { boxShadow: 6, },
                        }}
                    >
                        <Accordion
                            disableGutters
                            square
                            expanded={expanded.includes(id)}
                            onChange={handleChange(id)}
                            elevation={0}
                            sx={{
                                bgcolor: "transparent",
                                boxShadow: "none",
                                border: "none",
                                "&:before": {
                                    display: "none",
                                },
                            }}
                        >
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon sx={{ color: "#3D1F6C" }} />}
                                aria-controls={`${id}-content`}
                                id={`${id}-header`}
                                sx={{ px: 0, "&:hover": { backgroundColor: "transparent", }, }}
                            >
                                <Typography
                                    component="span"
                                    variant="subtitle2"
                                    sx={{ fontSize: "1.125rem", fontWeight: 600, color: "#3D1F6C" }}
                                >
                                    {question}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ px: 0 }}>
                                <Typography
                                    variant="body2"
                                    sx={{
                                        fontSize: "1rem",
                                        lineHeight: 1.75,
                                        maxWidth: { sm: "100%", md: "80%" },
                                        // color: "#3D1F6C"
                                    }}
                                >
                                    {answer}
                                </Typography>
                            </AccordionDetails>
                        </Accordion>
                    </Paper>
                ))}
            </Box>
        </Box>
    );

    return (
        <Container
            id="faq"
            sx={{
                pt: { xs: 4, sm: 12 },
                pb: { xs: 8, sm: 16 },
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: { xs: 3, sm: 6 },
            }}
        >
            <Typography
                component="h2"
                variant="h4"
                sx={{
                    fontSize: 40,
                    // fontWeight: "bold",
                    color: "white",
                    width: { sm: "100%", md: "60%" },
                    textAlign: { sm: "left", md: "center" },
                }}
            >
                Frequently asked questions
            </Typography>

            <Box sx={{ width: "100%" }}>
                {renderFAQGroup("General Subscriptions Questions", subFAQs)}
                {renderFAQGroup("Payment and Security Questions", paymentFAQs, true)}
                {/*{renderFAQGroup("Account and Data Questions", techFAQs, true)}*/}
            </Box>
        </Container>
    );
}