import React from "react";
import { Box, Typography, LinearProgress, Tooltip } from "@mui/material";
import EmojiEventsIcon from "@mui/icons-material/EmojiEvents";
import HelpOutlineIcon from "@mui/icons-material/HelpOutline";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
dayjs.extend(utc);
dayjs.extend(timezone);

const TASKS = {
  posts_10: { label: "Publish 10 Posts", goal: 10 },
  posts_20: { label: "Publish 20 Posts", goal: 20 },
  posts_50: { label: "Publish 50 Posts", goal: 50 },
  posts_100: { label: "Publish 100 Posts", goal: 100 },
  posts_500: { label: "Publish 500 Posts", goal: 500 },
  posts_1000: { label: "Publish 1000 Posts", goal: 1000 },
  posts_5000: { label: "Publish 5000 Posts", goal: 5000 },

  likes_10: { label: "Get 10 Likes", goal: 10 },
  likes_20: { label: "Get 20 Likes", goal: 20 },
  likes_50: { label: "Get 50 Likes", goal: 50 },
  likes_100: { label: "Get 100 Likes", goal: 100 },
  likes_500: { label: "Get 500 Likes", goal: 500 },
  likes_1000: { label: "Get 1000 Likes", goal: 1000 },

  comments_10: { label: "Receive 10 Comments", goal: 10 },
  comments_20: { label: "Receive 20 Comments", goal: 20 },
  comments_50: { label: "Receive 50 Comments", goal: 50 },
  comments_100: { label: "Receive 100 Comments", goal: 100 },
  comments_500: { label: "Receive 500 Comments", goal: 500 },
  comments_1000: { label: "Receive 1000 Comments", goal: 1000 },

  days_10: { label: "Post 10 Consecutive Days", goal: 10 },
  days_20: { label: "Post 20 Consecutive Days", goal: 20 },
  days_30: { label: "Post 30 Consecutive Days", goal: 30 },
  days_60: { label: "Post 60 Consecutive Days", goal: 60 },
  days_90: { label: "Post 90 Consecutive Days", goal: 90 },
  days_120: { label: "Post 120 Consecutive Days", goal: 120 },
  days_300: { label: "Post 300 Consecutive Days", goal: 300 },
  days_500: { label: "Post 500 Consecutive Days", goal: 500 },
};

/**
 * TaskProgress component displays user's progress for four main achievement categories:
 * posts published, likes received, comments received, and consecutive posting days.
 *
 * For each category, only the next uncompleted task is shown.
 * If all tasks in a category are completed, the highest-level task will be displayed.
 *
 * @param {object} props - Component props
 * @param {object} props.overview - User statistics including posts, likes, comments, and consecutiveDays
 */
export default function TaskProgress({ overview }) {
  if (!overview) return null;

  // Extract current progress numbers from overview, defaulting to zero
  const postCount = overview.posts || 0;
  const likesCount = overview.likes || 0;
  const commentsCount = overview.comments || 0;
  const consecutiveDays = overview.consecutiveDays || 0;

  // Helper function to map taskId prefixes to their current progress values
  const getValueByTaskId = (taskId) => {
    if (taskId.startsWith("posts_")) return postCount;
    if (taskId.startsWith("likes_")) return likesCount;
    if (taskId.startsWith("comments_")) return commentsCount;
    if (taskId.startsWith("days_")) return consecutiveDays;
    return 0;
  };

  // Group tasks by their category prefix for easier handling
  const groupedTasks = { posts: [], likes: [], comments: [], days: [] };
  Object.entries(TASKS).forEach(([taskId, task]) => {
    if (taskId.startsWith("posts_")) groupedTasks.posts.push([taskId, task]);
    else if (taskId.startsWith("likes_"))
      groupedTasks.likes.push([taskId, task]);
    else if (taskId.startsWith("comments_"))
      groupedTasks.comments.push([taskId, task]);
    else if (taskId.startsWith("days_")) groupedTasks.days.push([taskId, task]);
  });

  // For each category, select the next incomplete task or the last one if all completed
  const tasksToShow = [];
  Object.entries(groupedTasks).forEach(([key, tasksArray]) => {
    tasksArray.sort((a, b) => a[1].goal - b[1].goal);
    const nextTask =
      tasksArray.find(
        ([taskId, task]) => getValueByTaskId(taskId) < task.goal
      ) || tasksArray[tasksArray.length - 1];
    tasksToShow.push(nextTask);
  });

  // Define different colors for trophy icons by category for visual clarity
  const trophyColors = {
    posts: "#FFD700",
    likes: "#FF69B4",
    comments: "#1E90FF",
    days: "#32CD32",
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: 2,
        boxShadow: 2,
        borderRadius: 2,
        maxWidth: { xs: "100%", sm: 400 },
        width: "100%",
        margin: "0 auto",
      }}
    >
      {/* Title row with help tooltip */}
      <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
        <Typography variant="h6" fontWeight="bold" mr={1}>
          Achievements
        </Typography>

        <Tooltip
          title={
            <Box
              sx={{
                border: "1px solid #4b0082",
                backgroundColor: "#fff",
                color: "#000",
                p: 1,
                fontSize: 13,
                maxWidth: 240,
                borderRadius: 1,
              }}
            >
              Achieving milestones earns you points. Points can be used to
              change your username. More benefits coming soon!
            </Box>
          }
          arrow
          placement="right"
          componentsProps={{
            tooltip: {
              sx: {
                backgroundColor: "transparent",
                boxShadow: "none",
                padding: 0,
                overflow: "visible",
              },
            },
            arrow: {
              sx: {
                color: "#fff",
                "&:before": {
                  border: "1px solid #4b0082",
                  backgroundColor: "#fff",
                  content: '""',
                  position: "absolute",
                  width: 12,
                  height: 12,
                  transform: "rotate(45deg)",
                  zIndex: 1,
                  top: 0,
                  left: 0,
                },
              },
            },
          }}
        >
          <HelpOutlineIcon
            sx={{
              color: "#4b0082",
              cursor: "pointer",
            }}
          />
        </Tooltip>
      </Box>

      {/* Render next pending task per category */}
      {tasksToShow.map(([taskId, { label, goal }]) => {
        const value = getValueByTaskId(taskId);
        const isComplete = value >= goal;
        const progress = Math.min(value / goal, 1);
        const category = taskId.split("_")[0];
        const trophyColor = trophyColors[category] || "#FFD700";

        return (
          <Box key={taskId} sx={{ mb: 2, width: "100%" }}>
            <Box sx={{ display: "flex", alignItems: "center", mb: 0.5 }}>
              <EmojiEventsIcon sx={{ color: trophyColor, mr: 1 }} />
              <Typography
                variant="subtitle1"
                sx={{
                  fontWeight: "bold",
                  textDecoration: isComplete ? "line-through" : "none",
                  color: isComplete ? "text.disabled" : "text.primary",
                }}
              >
                {label}
              </Typography>
              <Typography
                variant="body2"
                sx={{ ml: "auto", fontWeight: "bold" }}
              >
                {`${Math.min(value, goal)}/${goal}`}
              </Typography>
            </Box>
            <LinearProgress
              variant="determinate"
              value={progress * 100}
              sx={{
                height: 8,
                borderRadius: 5,
                backgroundColor: "#ddd",
                "& .MuiLinearProgress-bar": {
                  backgroundColor: isComplete ? "#4caf50" : trophyColor,
                },
              }}
            />
            {isComplete && (
              <Typography variant="caption" color="success.main" sx={{ ml: 1 }}>
                completed
              </Typography>
            )}
          </Box>
        );
      })}
    </Box>
  );
}
