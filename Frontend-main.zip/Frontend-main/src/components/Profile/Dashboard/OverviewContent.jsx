import React, { useEffect, useState } from "react";
import { Box, Typography } from "@mui/material";
import ArticleIcon from "@mui/icons-material/Article";
import ForumIcon from "@mui/icons-material/Forum";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import TollIcon from "@mui/icons-material/Toll";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import { useSelector } from "react-redux";

import PostsCalendar from "./PostsCalendar";
import EmojiRanking from "./EmojiRanking";
import TaskProgress from "./TaskProgress";
import NavigationBlocks from "./NavigationBlocks";
import WeatherSummary from "./WeatherSummary";

export default function OverviewContent() {
  const [overview, setOverview] = useState(null);
  const [selectedDate, setSelectedDate] = useState(dayjs());
  const navigate = useNavigate();

  const token = useSelector((state) => state.user.tokenData?.token);

  useEffect(() => {
    const fetchOverview = async () => {
      if (!token) return;
      try {
        const res = await axios.get(
          "http://localhost:8080/api/v1/profiles/overview",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (res.data.success) setOverview(res.data.data);
      } catch (error) {
        console.error("Failed to fetch overview:", error);
      }
    };
    fetchOverview();
  }, [token]);

  const handleNavigate = (label) => {
    if (label === "Received Comments")
      navigate(`/notification?tab=${encodeURIComponent("Received Comments")}`);
    else if (label === "Received Likes")
      navigate(`/notification?tab=${encodeURIComponent("Received Likes")}`);
  };

  const stats = overview
    ? [
        {
          label: "Day",
          value: overview.day,
          icon: <CalendarTodayIcon sx={{ fontSize: 26, color: "#fff" }} />,
          background: "#4b0082",
          color: "#fff",
        },
        {
          label: "Posts",
          value: overview.posts,
          icon: <ArticleIcon sx={{ fontSize: 26, color: "#4b0082" }} />,
          background: "#fff",
          color: "#000",
        },
        {
          label: "Received Comments",
          value: overview.comments,
          icon: <ForumIcon sx={{ fontSize: 26, color: "#4b0082" }} />,
          background: "#fff",
          color: "#000",
        },
        {
          label: "Received Likes",
          value: overview.likes,
          icon: <ThumbUpIcon sx={{ fontSize: 26, color: "#4b0082" }} />,
          background: "#fff",
          color: "#000",
        },
      ]
    : [];

  return (
    <>
      {/* Header with dashboard title, weather, and points */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          mb: 3,
          px: { xs: 2, sm: 3, md: 4 },
          flexWrap: "wrap",
          gap: 1,
          justifyContent: "space-between",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Typography variant="h4" fontWeight="bold">
            Dashboard
          </Typography>
          <WeatherSummary />
        </Box>

        {/* Points display on the right */}
        {overview && (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1,
              padding: "4px 12px",
              borderRadius: "20px",
              border: "2px solid #6a1b9a",
              boxShadow: "0 2px 5px rgba(106, 27, 154, 0.4)",
              minWidth: 100,
              cursor: "default",
              userSelect: "none",
            }}
          >
            <TollIcon sx={{ fontSize: 28, color: "#6a1b9a" }} />
            <Typography
              sx={{ fontWeight: "bold", fontSize: 16, color: "#6a1b9a" }}
            >
              {overview.point || 0}
            </Typography>
          </Box>
        )}
      </Box>

      {/* Stats cards */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2, 1fr)",
            md: "repeat(4, 1fr)",
          },
          gap: 3,
          mt: 6,
          px: { xs: 2, sm: 3, md: 4 },
          width: "100%",
          boxSizing: "border-box",
        }}
      >
        {stats.map((stat) => (
          <Box
            key={stat.label}
            onClick={() => {
              if (stat.label === "Posts") navigate("/myposts");
              else if (stat.label === "Received Comments")
                handleNavigate("Received Comments");
              else if (stat.label === "Received Likes")
                handleNavigate("Received Likes");
            }}
            sx={{
              position: "relative",
              backgroundColor: stat.background,
              color: stat.color,
              borderRadius: 2,
              height: 120,
              boxShadow: 2,
              p: 3,
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              cursor:
                stat.label === "Posts" ||
                stat.label === "Received Comments" ||
                stat.label === "Received Likes"
                  ? "pointer"
                  : "default",
              "&:hover": {
                boxShadow:
                  stat.label === "Posts" ||
                  stat.label === "Received Comments" ||
                  stat.label === "Received Likes"
                    ? 4
                    : 2,
              },
            }}
          >
            <Typography
              variant="subtitle2"
              sx={{
                position: "absolute",
                top: 12,
                left: 12,
                fontWeight: "bold",
                color: stat.color,
              }}
            >
              {stat.label}
            </Typography>

            <Box sx={{ position: "absolute", top: 12, right: 12 }}>
              {stat.icon}
            </Box>

            <Typography
              variant="h3"
              fontWeight="bold"
              sx={{ mt: 1, color: stat.color }}
            >
              {stat.value}
            </Typography>
          </Box>
        ))}
      </Box>

      {/* Lower dashboard modules */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "1fr",
            md: "1fr 1fr",
            lg: "repeat(4, 1fr)",
          },
          gap: 3,
          mt: 10,
          px: 0,
          mx: "auto",
          maxWidth: { xs: 300, sm: 300, md: 620, lg: 1240 },
          alignItems: "start",
          width: "100%",
          boxSizing: "border-box",
          justifyItems: "center",
          justifyContent: "center",
        }}
      >
        <Box sx={{ width: "100%", maxWidth: 400, mx: "auto", mb: 2 }}>
          <PostsCalendar
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            postDates={overview?.postCreatedAts || []}
          />
        </Box>

        <Box sx={{ width: "100%", maxWidth: 400, mx: "auto", mb: 2 }}>
          <EmojiRanking monthlyEmojis={overview?.monthlyEmojis || []} />
        </Box>

        <Box sx={{ width: "100%", maxWidth: 400, mx: "auto", mb: 2 }}>
          <TaskProgress overview={overview} />
        </Box>

        <Box sx={{ width: "100%", maxWidth: 400, mx: "auto", mb: 2 }}>
          <NavigationBlocks onNavigate={handleNavigate} />
        </Box>
      </Box>
    </>
  );
}
