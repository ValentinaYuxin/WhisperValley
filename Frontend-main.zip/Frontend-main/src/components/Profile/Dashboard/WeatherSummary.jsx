import React, { useEffect, useState } from "react";
import { Typography } from "@mui/material";
import WbSunnyIcon from "@mui/icons-material/WbSunny";
import CloudIcon from "@mui/icons-material/Cloud";
import GrainIcon from "@mui/icons-material/Grain";
import AcUnitIcon from "@mui/icons-material/AcUnit";

function getWeatherIcon(desc) {
  if (!desc) return null;
  const d = desc.toLowerCase();
  if (d.includes("sunny") || d.includes("clear"))
    return <WbSunnyIcon sx={{ fontSize: 24, color: "#fbc02d", mr: 0.5 }} />;
  if (d.includes("cloud") || d.includes("overcast"))
    return <CloudIcon sx={{ fontSize: 24, color: "#90a4ae", mr: 0.5 }} />;
  if (d.includes("rain") || d.includes("drizzle"))
    return <GrainIcon sx={{ fontSize: 24, color: "#2196f3", mr: 0.5 }} />;
  if (d.includes("snow") || d.includes("sleet"))
    return <AcUnitIcon sx={{ fontSize: 24, color: "#81d4fa", mr: 0.5 }} />;
  return <WbSunnyIcon sx={{ fontSize: 24, color: "#fbc02d", mr: 0.5 }} />;
}

export default function WeatherSummary() {
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const apiKey = "ec458c285df241c0a12151857250607"; // WeatherAPI key
        const city = "Munich";
        const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`;
        const res = await fetch(url);
        const data = await res.json();

        if (data.current) {
          setWeather({
            city: data.location.name,
            temp: Math.round(data.current.temp_c),
            desc: data.current.condition.text,
          });
        }
      } catch {
        setWeather(null);
      }
    };

    fetchWeather();
  }, []);

  if (!weather) return null;

  return (
    <Typography
      variant="body2"
      sx={{ display: "flex", alignItems: "center", color: "#555", ml: 3 }}
    >
      {getWeatherIcon(weather.desc)}
      {`${weather.city}: ${weather.desc}, ${weather.temp}°C`}
    </Typography>
  );
}
