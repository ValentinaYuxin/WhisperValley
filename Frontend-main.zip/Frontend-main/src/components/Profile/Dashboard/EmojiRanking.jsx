import { Box, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";

export default function EmojiRanking({ monthlyEmojis }) {
  const navigate = useNavigate();
  const emojiCount = monthlyEmojis.reduce((acc, emoji) => {
    acc[emoji] = (acc[emoji] || 0) + 1;
    return acc;
  }, {});

  const topEmojis = Object.entries(emojiCount).sort(([, a], [, b]) => b - a);

  const containerStyle = {
    p: 3,
    borderRadius: 3,
    width: "100%",
    maxWidth: { xs: "100%", sm: 220 },
    mx: "auto",
    background: "linear-gradient(135deg, #f3e8ff 0%, #faf5ff 100%)",
    boxShadow: "0 4px 10px rgba(0,0,0,0.08)",
  };

  const titleStyle = {
    color: "#4b0082",
    fontWeight: "bold",
    textAlign: "center",
    mb: 2,
    fontSize: 20,
    letterSpacing: 0.5,
  };

  if (topEmojis.length === 0) {
    return (
      <Box sx={{ ...containerStyle, maxWidth: { xs: "100%", sm: 300 } }}>
        <Typography variant="h6" sx={titleStyle}>
          Emoji Ranking
        </Typography>
        <Typography align="center" color="text.secondary" sx={{ mb: 2 }}>
          You haven't posted anything this month.
        </Typography>
        <Typography
          align="center"
          sx={{
            color: "#4b0082",
            fontWeight: "bold",
            textDecoration: "underline",
            cursor: "pointer",
          }}
          onClick={() => navigate("/forum")}
        >
          Write a post
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={containerStyle}>
      <Typography variant="h6" sx={titleStyle}>
        Emoji Ranking
      </Typography>
      {topEmojis.map(([emoji, count], index) => (
        <Box
          key={emoji}
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mt: 1,
            fontSize: 22,
            fontWeight: "bold",
            color: "#4b0082",
            px: 1,
            py: 0.3,
            backgroundColor: index % 2 === 0 ? "#f3e8ff" : "transparent",
            borderRadius: 1,
          }}
        >
          <span>
            {index + 1}. {emoji}
          </span>
          <span
            style={{
              fontSize: 16,
              fontWeight: 500,
              color: "#6a1b9a",
            }}
          >
            {count}×
          </span>
        </Box>
      ))}
    </Box>
  );
}
