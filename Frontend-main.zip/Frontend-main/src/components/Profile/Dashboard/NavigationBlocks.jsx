import { Box, Typography } from "@mui/material";
import CommentIcon from "@mui/icons-material/Comment";
import FavoriteIcon from "@mui/icons-material/Favorite";
import EditNoteIcon from "@mui/icons-material/EditNote";
import { useNavigate } from "react-router-dom";

export default function NavigationBlocks() {
  const navigate = useNavigate();

  const purpleTheme = {
    background: "#4b0082",
    color: "#fff",
    hover: "#5c1692",
  };

  const lightPurpleTheme = {
    background: "#e6ccff",
    color: "#4b0082",
    hover: "#d1b3ff",
  };

  const blocks = [
    {
      label: "My Comments",
      theme: purpleTheme,
      icon: <CommentIcon sx={{ fontSize: 40 }} />,
      path: "/myengagements?tab=My Comments",
      height: 100,
    },
    {
      label: "My Likes",
      theme: purpleTheme,
      icon: <FavoriteIcon sx={{ fontSize: 40 }} />,
      path: "/myengagements?tab=My Likes",
      height: 100,
    },
    {
      label: "Write a Post",
      theme: lightPurpleTheme,
      icon: <EditNoteIcon sx={{ fontSize: 30 }} />,
      path: "/forum",
      height: 80,
    },
  ];

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: 4,
        width: "100%",
        maxWidth: { xs: "100%", sm: 180 },
        mx: "auto",
      }}
    >
      {blocks.map(
        ({
          label,
          theme: { background, color, hover },
          icon,
          path,
          height,
        }) => (
          <Box
            key={label}
            onClick={() => navigate(path)}
            sx={{
              cursor: "pointer",
              backgroundColor: background,
              color,
              borderRadius: 3,
              height: height,
              width: "100%",
              boxShadow: 2,
              p: 3,
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              fontSize: 20,
              fontWeight: "bold",
              userSelect: "none",
              transition: "all 0.3s ease-in-out",
              "&:hover": {
                backgroundColor: hover,
                boxShadow: 4,
                transform: "translateY(-2px)",
              },
            }}
          >
            <Typography variant="subtitle1" sx={{ textAlign: "center", mb: 1 }}>
              {label}
            </Typography>
            {icon}
          </Box>
        )
      )}
    </Box>
  );
}
