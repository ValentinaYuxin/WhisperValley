import React from "react";
import { Box, Typography } from "@mui/material";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DateCalendar } from "@mui/x-date-pickers/DateCalendar";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { useNavigate } from "react-router-dom";

dayjs.extend(utc);
dayjs.extend(timezone);

export default function PostsCalendar({
  selectedDate,
  setSelectedDate,
  postDates,
}) {
  const navigate = useNavigate();

  // Pre-compute postDates adjusted to your timezone (e.g. UTC+2)
  const adjustedPostDates = React.useMemo(() => {
    return postDates.map((d) =>
      dayjs.utc(d).add(2, "hour").format("YYYY-MM-DD")
    );
  }, [postDates]);

  return (
    <Box
      sx={{
        maxWidth: { xs: "100%", sm: 300 },
        width: "100%",
        mx: "auto",
        overflowX: "auto",
      }}
    >
      <Typography variant="h5" fontWeight="bold" mb={2} textAlign="center">
        Posts Calendar
      </Typography>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DateCalendar
          value={selectedDate}
          onChange={(newValue) => {
            setSelectedDate(newValue);
            const dateStr = dayjs(newValue).format("YYYY-MM-DD");
            // If this date has posts, navigate to MyPosts with query param
            if (adjustedPostDates.includes(dateStr)) {
              navigate(`/myposts?date=${dateStr}`);
            }
          }}
          slots={{
            // Customize each day cell
            day: (props) => {
              const { day, selected } = props;
              const dateStr = dayjs(day).format("YYYY-MM-DD");
              const isPostDay = adjustedPostDates.includes(dateStr);

              return (
                <Box
                  sx={{
                    position: "relative",
                    width: 36,
                    height: 36,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    borderRadius: "50%",
                    bgcolor: selected ? "#9370DB" : "transparent",
                    color: selected ? "#fff" : "inherit",
                    "&:hover": {
                      backgroundColor: selected ? "#4b0082" : "#eee",
                    },
                    cursor: "pointer",
                  }}
                  // When clicked, also navigate if it's a post day
                  onClick={() => {
                    setSelectedDate(day);
                    if (isPostDay) {
                      navigate(`/myposts?date=${dateStr}`);
                    }
                  }}
                >
                  <Typography variant="body2">{day.date()}</Typography>
                  {isPostDay && (
                    <Box
                      sx={{
                        position: "absolute",
                        bottom: 4,
                        width: 6,
                        height: 6,
                        borderRadius: "50%",
                        backgroundColor: "#4b0082",
                      }}
                    />
                  )}
                </Box>
              );
            },
          }}
        />
      </LocalizationProvider>
    </Box>
  );
}
