import { useEffect, useState } from "react";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Divider,
  RadioGroup,
  FormControlLabel,
  Radio,
  Button,
  Pagination,
} from "@mui/material";
import { styled, alpha } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import SearchIcon from "@mui/icons-material/Search";
import axios from "axios";
import dayjs from "dayjs";
import { useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";

// Styled components for the search bar
const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: "16px",
  backgroundColor: alpha(theme.palette.secondary.main, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.secondary.main, 0.25),
  },
  marginTop: theme.spacing(3),
  width: "100%",
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  color: theme.palette.secondary.main,
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: theme.palette.secondary.main,
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("md")]: {
      width: "20ch",
    },
  },
}));

export default function MyPosts() {
  const [posts, setPosts] = useState([]);
  const [filter, setFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(1);
  const [postsPerPage] = useState(12);

  // Read token from Redux
  const token = useSelector((state) => state.user.tokenData?.token);
  const navigate = useNavigate();
  const location = useLocation();

  // Read date from URL query string
  const queryParams = new URLSearchParams(location.search);
  const dateFilter = queryParams.get("date"); // e.g. "2025-07-12"

  // Fetch posts on mount and when filter or date changes
  useEffect(() => {
    const fetchMyPosts = async () => {
      if (!token) return;

      try {
        const res = await axios.get(
          "http://localhost:8080/api/v1/profiles/posts",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (res.data.success) {
          let filtered = res.data.data;
          const now = dayjs();

          // Filter by last X days
          if (filter === "7days") {
            filtered = filtered.filter((p) =>
              dayjs(p.createdAt).isAfter(now.subtract(7, "day"))
            );
          } else if (filter === "30days") {
            filtered = filtered.filter((p) =>
              dayjs(p.createdAt).isAfter(now.subtract(30, "day"))
            );
          }

          if (dateFilter) {
            filtered = filtered.filter(
              (p) => dayjs(p.createdAt).format("YYYY-MM-DD") === dateFilter
            );
          }

          setPosts(filtered);
          setPage(1);
        }
      } catch (error) {
        console.error("Failed to fetch posts:", error);
        setPosts([]);
      }
    };
    fetchMyPosts();
  }, [filter, token, dateFilter]);

  // Search filter
  const filteredBySearch = posts.filter((post) =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Pagination
  const indexOfLastPost = page * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = filteredBySearch.slice(
    indexOfFirstPost,
    indexOfLastPost
  );

  const handlePageChange = (event, value) => {
    setPage(value);
    const container = document.getElementById("posts-container");
    if (container) {
      container.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handlePostClick = (postId) => {
    navigate(`/forum/posts/${postId}`);
  };

  return (
    <Box
      sx={{
        pt: 7,
        backgroundColor: "#f3e8ff",
        minHeight: "100vh",
        height: "100vh",
        overflowY: "auto",
      }}
    >
      <Box sx={{ px: 4, pb: 2, position: "relative", zIndex: 2000 }}>
        <Button
          startIcon={<ArrowBackIosNewIcon fontSize="small" />}
          onClick={() => window.history.back()}
          sx={{
            alignSelf: "flex-start",
            mb: 1,
            color: "#4b0082",
            fontSize: 15,
            textTransform: "none",
          }}
        >
          Back
        </Button>
      </Box>
      <Box sx={{ display: "flex", px: 4, gap: 4, height: "100%" }}>
        {/* Sidebar */}
        <Box sx={{ minWidth: 200, height: "100%", overflowY: "auto" }}>
          <Typography variant="h6" fontWeight="bold" color="secondary" mb={2}>
            Filter by Date
          </Typography>
          <RadioGroup
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <FormControlLabel
              value="all"
              control={<Radio color="secondary" />}
              label="All Time"
            />
            <FormControlLabel
              value="7days"
              control={<Radio color="secondary" />}
              label="Past 7 Days"
            />
            <FormControlLabel
              value="30days"
              control={<Radio color="secondary" />}
              label="Past 30 Days"
            />
          </RadioGroup>

          {/* Search bar */}
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search by Title…"
              inputProps={{ "aria-label": "search" }}
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setPage(1);
              }}
            />
          </Search>

          {/* Show currently selected date filter */}
          {dateFilter && (
            <Typography variant="body2" sx={{ mt: 2, color: "#6a1b9a" }}>
              Showing posts from: <b>{dateFilter}</b>
            </Typography>
          )}
        </Box>

        {/* Main posts section */}
        <Box
          sx={{
            flexGrow: 1,
            height: "100%",
            overflowY: "auto",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            variant="h4"
            fontWeight="bold"
            mb={4}
            color="secondary"
            sx={{ ml: 1 }}
          >
            My Posts
          </Typography>

          {/* Posts grid */}
          <Box
            id="posts-container"
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "repeat(1, 1fr)",
                sm: "repeat(2, 1fr)",
                md: "repeat(3, 1fr)",
                lg: "repeat(4, 1fr)",
              },
              gap: 3,
              flexGrow: 1,
              overflowY: "auto",
              mb: 2,
            }}
          >
            {currentPosts.length === 0 ? (
              <Typography>No posts found.</Typography>
            ) : (
              currentPosts.map((post) => (
                <Card
                  key={post._id}
                  sx={{
                    height: 180,
                    backgroundColor: "white",
                    borderRadius: 3,
                    boxShadow: 2,
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    cursor: "pointer",
                  }}
                  onClick={() => handlePostClick(post._id)}
                >
                  <CardContent>
                    <Typography
                      variant="subtitle1"
                      fontWeight="bold"
                      gutterBottom
                    >
                      {post.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {post.content || "No content"}
                    </Typography>
                  </CardContent>
                  <Divider />
                  <Typography
                    variant="caption"
                    sx={{ px: 2, py: 1, color: "gray" }}
                  >
                    Posted on {new Date(post.createdAt).toLocaleString()}
                  </Typography>
                </Card>
              ))
            )}
          </Box>

          {/* Pagination */}
          <Box sx={{ display: "flex", justifyContent: "center", pb: 3 }}>
            <Pagination
              count={Math.ceil(filteredBySearch.length / postsPerPage)}
              page={page}
              onChange={handlePageChange}
              color="secondary"
              shape="rounded"
              siblingCount={1}
              boundaryCount={1}
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
