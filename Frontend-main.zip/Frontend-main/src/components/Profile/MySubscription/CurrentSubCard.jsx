import React from "react";
import {
  Typography,
  Alert,
  Card,
  CardContent,
  Grid,
  Box,
} from "@mui/material";
import dayjs from "dayjs";

const getCardStyles = (plan, status) => {
  const isPremium = plan === 'premium';
  const isTrial = isPremium && status === 'trialing';

  if (isTrial) {
    return {
      backgroundColor: '#e6d6fa',  // Light purple for trial
      color: '#000',
      mainColor: '#4b0082',  // Dark purple for plan name
    };
  }

  if (isPremium) {
    return {
      backgroundColor: '#4b0082',  // Dark purple for premium
      color: '#fff',
      mainColor: '#fff',  // White for plan name
    };
  }

  // Default styles for free plan
  return {
    backgroundColor: '#fff',  // White for free plan
    color: '#000',
    mainColor: '#4b0082',  // Dark purple for plan name
  };
};

const getStatusStyle = (status) => {
  switch (status) {
    case 'active':
    case 'trialing':
      return { color: 'green', fontWeight: 'bold' };
    case 'canceling':
      return { color: 'orange', fontWeight: 'bold' };
    case 'cancelled':
    case 'past_due':
      return { color: 'red', fontWeight: 'bold' };
    default:
      return { color: 'grey', fontWeight: 'bold' };
  }
}

const InfoRow = ({ label, value, show = true }) => {
  if (!show) return null;
  return (
      <Typography variant="body1">
        <strong>{label}:</strong> {value}
      </Typography>
  );
}

const CurrentSubCard = ({ subscription }) => {
  if (!subscription || !subscription.plan) {
    return (
        <Alert severity="info" sx={{ mb: 4 }}>
          You currently have no active subscription.
        </Alert>
    );
  }

  const { plan, status, startDate, endDate, billingPeriod, paymentMethod } = subscription;
  const isPremium = plan === 'premium';
  const isTrial = isPremium && status === 'trialing';

  const styles = getCardStyles(plan, status);
  const statusStyle = getStatusStyle(status);

  return (
      <div style={{ position: 'relative', marginBottom: '40px' }}>
        <Typography variant="h5" component="h2" sx={{ mb: 2, fontWeight: 'bold' }}>
          Current Subscription
        </Typography>

        <Card sx={{
          backgroundColor: styles.backgroundColor,
          color: styles.color,
          borderRadius: 2,
          boxShadow: 2,
          p: 3,
          mb: 4
        }}>
          <CardContent sx={{ p: 0 }}>
            {/* Plan name */}
            <Typography variant="h4" fontWeight="bold" sx={{ color: styles.mainColor, mb: 3 }}>
              {isTrial ? "Premium Trial" : (isPremium ? "Premium Plan" : "Free Plan")}
            </Typography>

            {/* Details */}
            <Grid container spacing={4}>
              <Grid item xs={12} md={8}>
                {/* first column */}
                <InfoRow
                    label="Status"
                    value={<span style={statusStyle}>{(status || '').replace(/_/g, ' ').toUpperCase()}</span>}
                />
                <InfoRow
                    label="Start Date"
                    value={dayjs(startDate).format("YYYY-MM-DD")}
                />
                <InfoRow
                    label={isTrial ? "Trial Ends" : "Renews On"}
                    value={endDate ? dayjs(endDate).format("YYYY-MM-DD") : "N/A"}
                    show={isPremium}

                />
              </Grid>

              {/* second column */}
              <Grid item xs={12} sm={6}>
                <InfoRow
                    label="Billing Period"
                    value={(billingPeriod || "N/A").toUpperCase()}
                    show={isPremium}
                />
                <InfoRow
                    label='Payment Method'
                    value={(paymentMethod || 'N/A').toUpperCase()}
                    show={isPremium}
                />
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </div>
  );
};

export default CurrentSubCard;