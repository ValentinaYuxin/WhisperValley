import React from 'react';
import {
    Typography,
    Box,
    Card,
    CardContent,
    Button,
    CircularProgress,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper
} from "@mui/material";
import DownloadIcon from '@mui/icons-material/Download';
import dayjs from 'dayjs';

const InvoiceHistory = ({ invoices, loading }) => {
    return (
        <div style={{ position: 'relative', marginBottom: '30px' }}>
            <Typography variant="h5" component="h2" sx={{ mb: 2, fontWeight: 'bold' }}>
                Invoice History
            </Typography>

            <Card sx={{ backgroundColor: '#fff', borderRadius: 2, boxShadow: 2 }}>
                <CardContent>
                    {loading && !invoices.length ? (
                        <CircularProgress/>
                    ) :  !invoices.length ? (
                        <Typography variant="body1" color="text.secondary">
                            You have no billing history yet.
                        </Typography>
                    ) : (
                        <TableContainer component={Paper} elevation={0}>
                            <Table sx={{ minWidth: 650 }} aria-label="billing history table">
                                <TableHead>
                                    <TableRow>
                                        <TableCell>Date</TableCell>
                                        <TableCell>Description</TableCell>
                                        <TableCell>Amount</TableCell>
                                        <TableCell>Status</TableCell>
                                        <TableCell align="right">Invoice</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {invoices.map((invoice) => (
                                        <TableRow key={invoice.id}>
                                            <TableCell>{dayjs.unix(invoice.created).format('YYYY-MM-DD')}</TableCell>
                                            <TableCell>{invoice.description}</TableCell>
                                            <TableCell>€{(invoice.amountPaid / 100).toFixed(2)}</TableCell>
                                            <TableCell>{invoice.status}</TableCell>
                                            <TableCell align="right">
                                                <Button
                                                    variant="outlined"
                                                    startIcon={<DownloadIcon />}
                                                    href={invoice.invoicePdf}
                                                    target="_blank"
                                                    rel="noopenernoreferrer"
                                                >
                                                    Download PDF
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default InvoiceHistory;