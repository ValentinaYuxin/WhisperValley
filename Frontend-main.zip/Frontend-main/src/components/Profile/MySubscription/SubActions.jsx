import React from 'react';
import {Typography, Button, Box, Grid, Card, CardContent, Stack} from "@mui/material";

const SubActions = ({ subscription, onUpgrade, onCancel, onChangePlan, hasHadTrialOrPremium }) => {
    // Guard against rendering with invalid data
    if (!subscription || !subscription.plan) return null;

    const status = subscription?.status;
    const plan = subscription?.plan;

    // Determine the user's current status

    const isFree = plan === 'free';
    const isTrial = status === 'trialing';
    const isPremiumActive = plan === 'premium' && status === 'active';
    const isCanceling = plan === 'premium' && status === 'canceling';
    const isCanceled = plan === 'premium' && status === 'cancelled';

    // Dynamic text based on user status
    const getActionTitle = () => {
        if (isFree) return hasHadTrialOrPremium ? "Upgrade to Premium" : "Start Your Journey";
        if (isTrial) return "You're on a Trial Plan";
        if (isPremiumActive) return "Premium Plan (Active)";
        if (isCanceling) return "Premium Plan (Canceling)";
        if (isCanceled) return "Subscription Ended";
        return "Manage Subscription";
    };

    const getActionDescription = () => {
        if (isFree)
            return hasHadTrialOrPremium
                ? "Subscribe to unlock premium features with instant access."
                : "Upgrade to unlock all premium features with a 7-day free trial!";
        if (isTrial)
            return `Your trial is active. 
            Your plan will automatically convert to a paid subscription at the end of the trial period. 
            If you cancel, your trial will end immediately.`;
        if (isPremiumActive)
            return "You can change your billing cycle or set your subscription to cancel at the end of the current period.";
        if (isCanceling)
            return "Your subscription is set to cancel at the end of the current billing period. You can reactivate it before it expires.";
        if (isCanceled)
            return "Your premium access has been ended. Subscribe again to unlock premium features.";
        return "";
    };

    // Render the correct buttons based on user status
    const renderButtons = () => {
        if (isFree) {
            return (
                <Button
                    variant="contained"
                    sx={{ backgroundColor: '#6d5b9b', color: '#fff', '&:hover': { backgroundColor: '#3D1F6C' } }}
                    onClick={() => onUpgrade()}
                >
                    {hasHadTrialOrPremium ? "Subscribe to Premium" : "Start 7-Day Trial"}
                </Button>
            );
        }

        if (isTrial) {
            return <Button
                variant="outlined"
                sx={{ color: '#3D1F6C', borderColor: '#3D1F6C', '&:hover': { borderColor: '#3D1F6C', color: '#3D1F6C' } }}
                onClick={onCancel}
            >
                Cancel Trial
            </Button>;
        }

        if (isPremiumActive) {
            return (
                <Stack direction="row" spacing={2}>
                    <Button
                        variant="outlined"
                        sx={{ color: '#6d5b9b', borderColor: '#6d5b9b', '&:hover': { borderColor: '#6d5b9b', color: '#6d5b9b' } }}
                        onClick={onChangePlan}
                    >
                        Change Billing Cycle
                    </Button>
                    <Button
                        variant="outlined"
                        sx={{ ml: 2, color: '#3D1F6C', borderColor: '#3D1F6C', '&:hover': { borderColor: '#3D1F6C', color: '#3D1F6C' } }}
                        onClick={onCancel}
                    >
                        Cancel Subscription
                    </Button>
                </Stack>
            );
        }

        if (isCanceling) {
            return <Button
                variant="contained"
                sx={{ backgroundColor: '#1976d2', color: '#fff', '&:hover': { backgroundColor: '#1565c0' } }}
                onClick={onChangePlan}
            >
                Change Billing Cycle
            </Button>
        }

        if (isCanceled) {
            return <Button
                variant="contained"
                sx={{ backgroundColor: '#1976d2', color: '#fff', '&:hover': { backgroundColor: '#1565c0' } }}
                onClick={onUpgrade}
            >
                Subscribe to Premium Again
            </Button>;
        }
        return null;
    };

    return (
        <div style={{ position: 'relative', marginBottom: '40px' }}>
            <Typography variant="h5" component="h2" sx={{ mb: 2, fontWeight: 'bold' }}>
                Manage Subscription
            </Typography>

            <Card sx={{ backgroundColor: '#fff', borderRadius: 2, boxShadow: 2, p: 3 }}>
                <CardContent>
                    <Grid container alignItems="center" spacing={2}>
                        <Grid item xs={12} md={8}>
                            <Typography variant="h6" component="h3">
                                {getActionTitle()}
                            </Typography>
                            <Typography variant="body1" color="text.secondary">
                                {getActionDescription()}
                            </Typography>
                        </Grid>
                        <Grid item xs={12} md={4} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                            {renderButtons()}
                        </Grid>
                    </Grid>
                </CardContent>
            </Card>
        </div>
    );
};

export default SubActions;