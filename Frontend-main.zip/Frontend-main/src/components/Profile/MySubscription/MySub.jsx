import React, { useEffect } from 'react';
import { useSubscription } from "../../../hooks/useSubscription.js";
import CurrentSubCard from './CurrentSubCard.jsx';
import SubActions from "./SubActions.jsx";
import InvoiceHistory from "./InvoiceHistory.jsx";
import SubscriptionHistory from "./SubscriptionHistory.jsx";
import { Alert, Box, CircularProgress, Typography } from '@mui/material';

const MySub = () => {
    const {
        current: sub,
        invoices,
        history,
        loading,
        error,
        checkoutUrl,
        fetchCurrent,
        fetchInvoices,
        fetchHistory,
        startTrial,
        upgrade,
        cancelSubscription,
        clearCheckoutUrl,
        hasHadTrialOrPremium,
    } = useSubscription();

    // redirect the user to Stripe for payment automatically
    useEffect(() => {
        if (checkoutUrl) {
            window.location.href = checkoutUrl;
            clearCheckoutUrl();
        }
    }, [checkoutUrl, clearCheckoutUrl]);

    useEffect(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const paymentSuccess = urlParams.get('payment_success');

        if (paymentSuccess === 'true') {
            setTimeout(() => {
                fetchCurrent();
                fetchInvoices();
                fetchHistory();
            }, 1000);
            window.history.replaceState({}, document.title, window.location.pathname);
        } else {
            fetchCurrent();
            fetchInvoices();
            fetchHistory();
        }
    }, [fetchCurrent, fetchInvoices, fetchHistory]);

    // --- API Call Handlers ---
    const handleUpgrade = () => {
        if (sub && sub.plan === 'free') {
            if (hasHadTrialOrPremium) {
                upgrade("monthly");
            } else {
                startTrial();
            }
        }
    };

    // cancel trial or premium subscription at period end
    const handleCancel = async () => {
        console.log('Cancel button clicked', sub?.status, sub?.stripeSubscriptionId);

        if (sub && sub.stripeSubscriptionId && (sub.status === 'active' || sub.status === 'trialing')) {
            await cancelSubscription();
            fetchCurrent();
            fetchHistory();
            fetchInvoices();  //
        } else {
            console.error('Cannot cancel: No active or trialing subscription ID found.');
        }
    };

    const handleChangePlan = () => {  // TODO: change
        console.log('Change plan clicked');
    }

    if (loading && !sub)
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
                <CircularProgress />
                <Typography variant="h6" sx={{ ml: 2 }}>
                    Loading your subscription details...
                </Typography>
            </Box>
        );

    if (error) return <Alert severity="error" sx={{ m: 3 }}>Error: {error}</Alert>;

    return (
        <Box
            sx={{
                p: 3,
                maxWidth: 1200,
                mx: 'auto',
                display: 'flex',
                flexDirection: 'column',
                gap: 3,  // vertical gap between components
            }}
        >
            <Typography variant="h4" component="h1" sx={{ mb: 1, fontWeight: 'bold' }}>
                My Subscription
            </Typography>

            <Box sx={{ display: 'flex', flexDirection: 'row', gap: 4, mb: 2 }}>
                <Box flex={1} className="current-sub-section">
                    <CurrentSubCard subscription={sub} />
                </Box>

                <Box flex={1} className="management-actions-section">
                    <SubActions
                        subscription={sub}
                        onUpgrade={handleUpgrade}
                        onCancel={handleCancel}
                        onChangePlan={handleChangePlan}
                        hasHadTrialOrPremium={hasHadTrialOrPremium}
                    />
                </Box>
            </Box>

            <Box className="subscription-history-section">
                <SubscriptionHistory history={history} loading={loading} />
            </Box>

            <Box className="billing-history-section">
                <InvoiceHistory invoices={invoices} loading={loading} />
            </Box>
        </Box>
    );
};

export default MySub;