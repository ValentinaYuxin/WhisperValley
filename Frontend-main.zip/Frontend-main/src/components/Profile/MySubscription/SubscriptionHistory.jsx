import React from 'react';
import {
    Typography,
    Box,
    Card,
    CardContent,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Chip
} from "@mui/material";
import dayjs from 'dayjs';

const getStatusChipColor = (status) => {
    switch (status) {
        case 'active':
        case 'trialing':
            return { backgroundColor: '#3D1F6C', color: 'white' };
        case 'cancelled':
        case 'expired':
        case 'unpaid':
            return { backgroundColor: '#b9bbdf', color: 'white' };
        case 'incomplete':
            return { backgroundColor: '#FFC107', color: 'white' };
        default:
            return { backgroundColor: '#dbe2ef', color: 'white' };
    }
};

const SubscriptionHistory = ({ history, loading }) => {
    return (
        <div style={{ position: 'relative', marginBottom: '40px' }}>
            <Typography variant="h5" component="h2" sx={{ mb: 2, fontWeight: 'bold' }}>
                Subscription History
            </Typography>

            <Card sx={{ backgroundColor: '#fff', borderRadius: 2, boxShadow: 2 }}>
                <CardContent>
                    {loading && !history.length ? (
                        <Typography>Loading history...</Typography>
                    ) : !history.length ? (
                        <Typography variant="body1" color="text.secondary">
                            You have no subscription history yet.
                        </Typography>
                    ) : (
                        <TableContainer component={Paper} elevation={0}>
                            <Table sx={{ minWidth: 650 }} aria-label="subscription history table">
                                <TableHead>
                                    <TableRow>
                                        <TableCell>Plan</TableCell>
                                        <TableCell>Status</TableCell>
                                        <TableCell>Start Date</TableCell>
                                        <TableCell>End Date</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {history.map((sub) => (
                                        <TableRow key={sub._id}>
                                            <TableCell sx={{ textTransform: 'capitalize' }}>{sub.plan}</TableCell>
                                            <TableCell>
                                                <Chip
                                                    label={sub.status.toUpperCase()}
                                                    size="small"
                                                    sx={getStatusChipColor(sub.status)}
                                                />
                                            </TableCell>
                                            <TableCell>{dayjs(sub.startDate).format('YYYY-MM-DD')}</TableCell>
                                            <TableCell>{sub.endDate ? dayjs(sub.endDate).format('YYYY-MM-DD') : 'N/A'}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default SubscriptionHistory;