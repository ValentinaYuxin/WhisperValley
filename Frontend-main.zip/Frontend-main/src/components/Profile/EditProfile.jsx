import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Avatar,
  Button,
  TextField,
  Stack,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  Tooltip,
  Chip,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Switch,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Check";
import CancelIcon from "@mui/icons-material/Close";
import InfoIcon from "@mui/icons-material/Info";
import { useSelector, useDispatch } from "react-redux";
import { updateUserProfile } from "../../store/slices/userSlice";

const weatherOptions = ["sunny", "cloudy", "rainy", "snowy"];

const EditProfile = () => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user.user);
  const token = useSelector((state) => state.user.tokenData?.token);

  // edit mode and form data
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({
    username: user?.username || "",
    email: user?.email || "",
    avatar: user?.avatar || "",
    petName: user?.petName || "",
    favoriteWeather: user?.favoriteWeather || "",
    isAnonymous: user?.isAnonymous ?? true,
  });
  const [avatarFile, setAvatarFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(user?.avatar || "");

  // dialog state
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("success");
  const [dialogMessage, setDialogMessage] = useState("");

  // email validation state
  const [emailError, setEmailError] = useState(false);
  const [emailErrorMessage, setEmailErrorMessage] = useState("");

  // update form when user changes
  useEffect(() => {
    if (user) {
      setFormData({
        username: user.username || "",
        email: user.email || "",
        avatar: user.avatar || "",
        petName: user.petName || "",
        favoriteWeather: user.favoriteWeather || "",
        isAnonymous: user.isAnonymous ?? true, // sync isAnonymous
      });
      setPreviewUrl(getFullAvatarUrl(user.avatar || ""));
    }
  }, [user]);

  // validate email
  const validateEmail = (value) => {
    const allowedDomains = ["@mytum.de", "@tum.de", "@campus.lmu.de"];
    const hasValidDomain = allowedDomains.some((domain) =>
      value.toLowerCase().endsWith(domain)
    );
    if (!value || !/\S+@\S+\.\S+/.test(value) || !hasValidDomain) {
      setEmailError(true);
      setEmailErrorMessage(
        "Please use your student email (for example: @tum.de, @mytum.de or @campus.lmu.de)."
      );
      return false;
    } else {
      setEmailError(false);
      setEmailErrorMessage("");
      return true;
    }
  };

  // handle field change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (name === "email") validateEmail(value);
  };

  // handle avatar file change
  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAvatarFile(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  // cancel editing
  const handleCancel = () => {
    setEditMode(false);
    setAvatarFile(null);
    setFormData({
      username: user.username || "",
      email: user.email || "",
      avatar: user.avatar || "",
      petName: user.petName || "",
      favoriteWeather: user.favoriteWeather || "",
      isAnonymous: user.isAnonymous ?? true,
    });
    setPreviewUrl(getFullAvatarUrl(user.avatar || ""));
    setEmailError(false);
    setEmailErrorMessage("");
  };

  // check if no changes
  const isUnchanged =
    formData.username === (user?.username || "") &&
    formData.email === (user?.email || "") &&
    formData.petName === (user?.petName || "") &&
    formData.favoriteWeather === (user?.favoriteWeather || "") &&
    !avatarFile;

  // save changes via Redux thunk
  const handleSave = async () => {
    const isValidEmail = validateEmail(formData.email);
    if (!isValidEmail) return;

    const id = user._id || user.id;
    if (!id) {
      setDialogType("error");
      setDialogMessage("User ID is missing. Please log in again.");
      setDialogOpen(true);
      return;
    }

    const isUsernameChanged = formData.username !== user.username;
    const form = new FormData();
    if (formData.username !== user.username)
      form.append("username", formData.username);
    if (formData.email !== user.email) form.append("email", formData.email);
    if (formData.petName !== user.petName)
      form.append("petName", formData.petName);
    if (
      formData.favoriteWeather !== user.favoriteWeather &&
      formData.favoriteWeather !== ""
    )
      form.append("favoriteWeather", formData.favoriteWeather);
    if (avatarFile) form.append("avatar", avatarFile);

    dispatch(
      updateUserProfile({ formData: form, id, token, isUsernameChanged })
    )
      .unwrap()
      .then(() => {
        setDialogType("success");
        setDialogMessage("Profile updated successfully!");
        setDialogOpen(true);
        setEditMode(false);
        setAvatarFile(null);
      })
      .catch((errMsg) => {
        // show reason for failure
        setDialogType("error");
        setDialogMessage(`Update failed: ${errMsg}`);
        setDialogOpen(true);
      });
  };

  // handle dialog close
  const handleDialogClose = () => {
    setDialogOpen(false);
  };

  // get full avatar url
  const getFullAvatarUrl = (avatarPath) => {
    if (!avatarPath) return "";
    if (avatarPath.startsWith("http")) return avatarPath;
    return `http://localhost:8080${avatarPath}`;
  };

  // handle anonymous toggle, instant update without save button
  const handleToggleAnonymous = async (newValue) => {
    setFormData((prev) => ({ ...prev, isAnonymous: newValue }));

    const id = user._id || user.id;
    if (!id) return;

    // build FormData for a single field
    const body = new FormData();
    body.append("isAnonymous", newValue);

    // dispatch immediately, no dialog message
    dispatch(
      updateUserProfile({ formData: body, id, token, isUsernameChanged: false })
    )
      .unwrap()
      .catch(() => {
        // no UI feedback needed
      });
  };

  return (
    <Box sx={{ maxWidth: 600, mx: "auto", px: 2, py: 3 }}>
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mb={3}
      >
        <Typography variant="h5" fontWeight="bold">
          My Profile
        </Typography>
        {!editMode && (
          <Button
            startIcon={<EditIcon />}
            variant="outlined"
            color="secondary"
            onClick={() => setEditMode(true)}
            sx={{ textTransform: "none" }}
          >
            Edit
          </Button>
        )}
      </Stack>

      <Box display="flex" flexDirection="column" alignItems="center" mb={4}>
        <Avatar
          src={previewUrl}
          sx={{
            width: 100,
            height: 100,
            mb: 2,
            boxShadow: 3,
            border: "2px solid #e1d5f5",
          }}
        />
        {editMode && (
          <label>
            <input
              type="file"
              accept="image/*"
              onChange={handleAvatarChange}
              hidden
            />
            <Button
              variant="outlined"
              color="secondary"
              size="small"
              component="span"
            >
              Upload Avatar
            </Button>
          </label>
        )}
      </Box>

      <Stack spacing={3} alignItems="center">
        <Box width="100%" maxWidth={360}>
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
          >
            <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
              Username
            </Typography>
            {editMode && (
              <Tooltip
                title={`Changing your username costs 1 point. You currently have ${
                  user?.point ?? 0
                } point(s).`}
                arrow
              >
                <Chip
                  icon={<InfoIcon />}
                  label={`1 point (you have ${user?.point ?? 0})`}
                  variant="outlined"
                  color="secondary"
                  size="small"
                  sx={{ fontSize: "0.75rem" }}
                />
              </Tooltip>
            )}
          </Stack>
          {editMode ? (
            <TextField
              name="username"
              size="small"
              fullWidth
              value={formData.username}
              onChange={handleChange}
              color="secondary"
            />
          ) : (
            <Typography>{formData.username}</Typography>
          )}
        </Box>

        <Divider flexItem sx={{ my: 1 }} />

        <Box width="100%" maxWidth={360}>
          <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
            Email
          </Typography>
          {editMode ? (
            <TextField
              name="email"
              size="small"
              fullWidth
              value={formData.email}
              onChange={handleChange}
              onBlur={(e) => validateEmail(e.target.value)}
              color="secondary"
              error={emailError}
              helperText={emailError ? emailErrorMessage : ""}
            />
          ) : (
            <Typography>{formData.email}</Typography>
          )}
        </Box>

        <Box width="100%" maxWidth={360}>
          <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
            Pet Name
          </Typography>
          {editMode ? (
            <TextField
              name="petName"
              size="small"
              fullWidth
              value={formData.petName}
              onChange={handleChange}
              placeholder="Enter your pet's name"
              color="secondary"
            />
          ) : (
            <Typography>{formData.petName || "-"}</Typography>
          )}
        </Box>

        <Box width="100%" maxWidth={360}>
          <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
            Favorite Weather
          </Typography>
          {editMode ? (
            <FormControl fullWidth size="small" color="secondary">
              <InputLabel id="favorite-weather-label">Weather</InputLabel>
              <Select
                labelId="favorite-weather-label"
                name="favoriteWeather"
                value={formData.favoriteWeather}
                label="Weather"
                onChange={handleChange}
              >
                {weatherOptions.map((weather) => (
                  <MenuItem key={weather} value={weather}>
                    {weather.charAt(0).toUpperCase() + weather.slice(1)}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          ) : (
            <Typography>
              {formData.favoriteWeather
                ? formData.favoriteWeather.charAt(0).toUpperCase() +
                  formData.favoriteWeather.slice(1)
                : "-"}
            </Typography>
          )}
        </Box>

        {/* Added Anonymous Mode Toggle */}
        <Box width="100%" maxWidth={360}>
          <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
            Anonymous Mode
          </Typography>
          <Stack direction="row" alignItems="center" spacing={2}>
            <Typography>{formData.isAnonymous ? "On" : "Off"}</Typography>
            <Switch
              checked={formData.isAnonymous}
              color="secondary"
              onChange={(e) => handleToggleAnonymous(e.target.checked)}
            />
          </Stack>
        </Box>
      </Stack>

      {editMode && (
        <Stack direction="row" spacing={2} mt={4} justifyContent="center">
          <Button
            variant="contained"
            color="secondary"
            startIcon={<SaveIcon />}
            onClick={handleSave}
            disabled={isUnchanged}
            sx={{ textTransform: "none", px: 3 }}
          >
            Save
          </Button>
          <Button
            variant="outlined"
            color="secondary"
            startIcon={<CancelIcon />}
            onClick={handleCancel}
            sx={{ textTransform: "none", px: 3 }}
          >
            Cancel
          </Button>
        </Stack>
      )}

      <Dialog
        open={dialogOpen}
        onClose={handleDialogClose}
        PaperProps={{
          sx: {
            borderRadius: 4,
            p: 2,
            minWidth: 300,
            backgroundColor: "#f9f4ff",
            border: "2px solid #a259ff",
          },
        }}
      >
        <DialogTitle
          sx={{
            color: dialogType === "success" ? "#6a1b9a" : "#d32f2f",
            fontWeight: "bold",
            fontSize: "1.3rem",
          }}
        >
          {dialogType === "success" ? "Success" : "Error"}
        </DialogTitle>
        <DialogContent sx={{ color: "#4a148c" }}>{dialogMessage}</DialogContent>
        <DialogActions>
          <Button
            onClick={handleDialogClose}
            color="secondary"
            variant="contained"
            sx={{
              backgroundColor: "#a259ff",
              "&:hover": { backgroundColor: "#8e44ff" },
              borderRadius: 2,
              px: 3,
            }}
          >
            OK
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default EditProfile;
