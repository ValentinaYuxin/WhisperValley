import { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  InputAdornment,
  IconButton,
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import SaveIcon from "@mui/icons-material/Check";
import CancelIcon from "@mui/icons-material/Close";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useSelector, useDispatch } from "react-redux";
import { logout, changePassword } from "../../store/slices/userSlice";
import { useNavigate } from "react-router-dom";

const ChangePassword = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const token = useSelector((state) => state.user.tokenData?.token);

  // form inputs
  const [formData, setFormData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  // toggle show/hide password
  const [showPassword, setShowPassword] = useState({
    current: false,
    new: false,
    confirm: false,
  });

  // dialog
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogMessage, setDialogMessage] = useState("");
  const [dialogType, setDialogType] = useState("success"); // success | error

  // handle input changes
  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  // Toggle password visibility
  const handleTogglePassword = (field) => {
    setShowPassword((prev) => ({
      ...prev,
      [field]: !prev[field],
    }));
  };

  // Reset form
  const handleCancel = () => {
    setFormData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    });
  };

  // Show dialog with message and type
  const showDialog = (message, type = "success") => {
    setDialogMessage(message);
    setDialogType(type);
    setDialogOpen(true);
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
    // logout and redirect only when success
    if (dialogType === "success") {
      dispatch(logout());
      navigate("/signin");
    }
  };

  const handleSave = async () => {
    const { currentPassword, newPassword, confirmPassword } = formData;

    // front-end validations
    if (newPassword === currentPassword) {
      showDialog(
        "New password must be different from current password.",
        "error"
      );
      return;
    }
    if (newPassword !== confirmPassword) {
      showDialog("New passwords do not match.", "error");
      return;
    }

    if (newPassword.length < 8) {
      showDialog("New password must be at least 8 characters.", "error");
      return;
    }

    // dispatch thunk
    const resultAction = await dispatch(
      changePassword({ currentPassword, newPassword, token })
    );

    if (changePassword.fulfilled.match(resultAction)) {
      // success
      setFormData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      showDialog(
        "Password updated successfully. Please log in again.",
        "success"
      );
    } else {
      // failed (stay on page)
      if (resultAction.payload === "__TOKEN_EXPIRED__") {
        dispatch(logout());
        navigate("/signin");
      } else {
        showDialog(
          resultAction.payload ||
            "Current password incorrect. Please try again.",
          "error"
        );
      }
    }
  };

  return (
    <Box maxWidth="600px" mx="auto" mt={6}>
      <Typography
        variant="h5"
        align="center"
        gutterBottom
        sx={{ mb: 6, fontWeight: "bold" }}
      >
        Change Password
      </Typography>

      <Stack spacing={3}>
        {/* Current Password */}
        <Box display="flex" alignItems="center" gap={3}>
          <Typography sx={{ width: 150 }}>Current Password:</Typography>
          <TextField
            fullWidth
            size="small"
            color="secondary"
            type={showPassword.current ? "text" : "password"}
            name="currentPassword"
            value={formData.currentPassword}
            onChange={handleChange}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => handleTogglePassword("current")}
                    edge="end"
                  >
                    {showPassword.current ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Box>

        {/* New Password */}
        <Box display="flex" alignItems="center" gap={3}>
          <Typography sx={{ width: 150 }}>New Password:</Typography>
          <TextField
            fullWidth
            size="small"
            color="secondary"
            type={showPassword.new ? "text" : "password"}
            name="newPassword"
            value={formData.newPassword}
            onChange={handleChange}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => handleTogglePassword("new")}
                    edge="end"
                  >
                    {showPassword.new ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Box>

        {/* Confirm Password */}
        <Box display="flex" alignItems="center" gap={3}>
          <Typography sx={{ width: 150 }}>Confirm Password:</Typography>
          <TextField
            fullWidth
            size="small"
            color="secondary"
            type={showPassword.confirm ? "text" : "password"}
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => handleTogglePassword("confirm")}
                    edge="end"
                  >
                    {showPassword.confirm ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Box>

        <Box display="flex" gap={2} mt={3} justifyContent="center">
          <Button
            variant="contained"
            color="secondary"
            startIcon={<SaveIcon />}
            onClick={handleSave}
          >
            Save
          </Button>
          <Button
            variant="outlined"
            color="secondary"
            startIcon={<CancelIcon />}
            onClick={handleCancel}
          >
            Cancel
          </Button>
        </Box>
      </Stack>

      <Dialog
        open={dialogOpen}
        onClose={handleDialogClose}
        PaperProps={{
          sx: {
            borderRadius: 4,
            p: 2,
            minWidth: 300,
            backgroundColor: "#f9f4ff",
            border: "2px solid #a259ff",
          },
        }}
      >
        <DialogTitle
          sx={{
            color: dialogType === "success" ? "#6a1b9a" : "#d32f2f",
            fontWeight: "bold",
            fontSize: "1.3rem",
          }}
        >
          {dialogType === "success" ? "Success" : "Error"}
        </DialogTitle>
        <DialogContent sx={{ color: "#4a148c" }}>{dialogMessage}</DialogContent>
        <DialogActions>
          <Button
            onClick={handleDialogClose}
            color="secondary"
            variant="contained"
            sx={{
              backgroundColor: "#a259ff",
              "&:hover": { backgroundColor: "#8e44ff" },
              borderRadius: 2,
              px: 3,
            }}
          >
            OK
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ChangePassword;
