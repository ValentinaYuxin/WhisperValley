import { Box, Button, Container, Link, Stack, Typography } from "@mui/material";
import EmailIcon from "@mui/icons-material/Email";

export default function Footer() {
  return (
    <Box
      sx={{
        backgroundColor: "#6a1b9a",
        color: "white",
        py: 4,
        mt: 4,
      }}
    >
      <Container maxWidth="md">
        <Stack spacing={4} alignItems="center" textAlign="center">
          {/* Logo */}
          <Box sx={{ mb: 1 }}>
            <img
              src="/logo2.png"
              alt="Whispering Valley Logo"
              style={{ height: "60px", objectFit: "contain" }}
            />
          </Box>

          {/* Email button */}
          <Button
            variant="outlined"
            href="mailto:contact@whisperingvalley.com"
            startIcon={<EmailIcon />}
            sx={{
              borderColor: "white",
              color: "white",
              ":hover": {
                backgroundColor: "rgba(255,255,255,0.1)",
                borderColor: "white",
              },
            }}
          >
            contact@whisperingvalley.com
          </Button>

          {/* Navigation links */}
          <Stack
            direction={{ xs: "column", sm: "row" }}
            spacing={3}
            justifyContent="center"
            mt={2}
          >
            <Link href="#features" underline="hover" sx={{ color: "white" }}>
              Features
            </Link>
            <Link href="pricing" underline="hover" sx={{ color: "white" }}>
              Pricing
            </Link>
            <Link href="#faq" underline="hover" sx={{ color: "white" }}>
              FAQ
            </Link>
            <Link href="contact" underline="hover" sx={{ color: "white" }}>
              Contact
            </Link>
          </Stack>

          {/* Copyright */}
          <Typography
            variant="body2"
            sx={{ opacity: 0.8, mt: 4, fontSize: "0.85rem" }}
          >
            © Copyright 2025 Whispering Valley – All Rights Reserved – Impressum
          </Typography>
        </Stack>
      </Container>
    </Box>
  );
}
