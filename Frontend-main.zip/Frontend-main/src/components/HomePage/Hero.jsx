import React, { useEffect, useRef } from "react";
import { Box, Button } from "@mui/material";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { useSubscription } from "../../hooks/useSubscription.js";

export default function Hero() {
  const bgleftRef = useRef(null);
  const bgrightRef = useRef(null);
  const bgRef = useRef(null);

  const { current: sub } = useSubscription();
  const subPlan = sub ? sub.plan : "free";

  const isLoggedIn = useSelector((state) => !!state.user.user);

  // Apply parallax scrolling effects to background layers and text
  useEffect(() => {
    const handleScroll = () => {
      const value = window.scrollY;

      // Move background elements based on scroll position
      if (bgleftRef.current)
        bgleftRef.current.style.transform = `translateX(${-value * 2}px)`;
      if (bgrightRef.current)
        bgrightRef.current.style.transform = `translateX(${value * 2}px)`;
      if (bgRef.current)
        bgRef.current.style.transform = `translateY(${value * 1}px)`;
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const innerVoiceLink = subPlan === "premium" ? "/journals" : "/pricing";

  return (
    <div>
      <section className="white-section">
        <img src="/bg.png" id="b" ref={bgRef} alt="b" />
        <img src="/bg_m.png" id="bg" alt="bg" />
        <img src="/bg_l.png" id="bgleft" ref={bgleftRef} alt="bgleft" />
        <img src="/bg_r.png" id="bgright" ref={bgrightRef} alt="bgright" />
        <img src="/bg_b.png" id="bottom" alt="bottom" />

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
            zIndex: 10,
            gap: 6,
            transform: "translateY(-5vh)",
          }}
        >
          <Box
            component="span"
            sx={{
              fontSize: {
                xs: "2.5rem",
                sm: "4rem",
                md: "5rem",
                lg: "6rem",
              },
              fontWeight: 800,
              color: "#302062",
              WebkitTextStroke: "0.2vw #ffffff",
              textShadow: "0 0.4vw 1.2vw rgba(255, 255, 255, 0.5)",
              fontFamily: `"M PLUS Rounded 1c", sans-serif`,
              whiteSpace: "nowrap",
              opacity: 0,
              animation: "fadeIn 2s ease-in-out forwards",
              animationDelay: "0.3s",
            }}
          >
            Whispering Valley
          </Box>

          <Box
            sx={{
              fontSize: {
                xs: "1rem",
                sm: "1.5rem",
                md: "2rem",
                lg: "2.3rem",
              },
              fontWeight: 400,
              color: "white",
              textShadow: "0 0.2vw 0.5vw rgba(0, 0, 0, 1)",
              opacity: 0,
              animation: "fadeIn 2s ease-in-out forwards",
              animationDelay: "0.7s",
              textAlign: "center",
              paddingX: 2,
            }}
          >
            Whispering your worries into a peaceful valley that gently echoes
            back.
          </Box>

          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: 8,
            }}
          >
            {isLoggedIn ? (
              <>
                {/* Forum button */}
                <Button
                  component={Link}
                  to="/forum"
                  size="large"
                  sx={{
                    width: "130px",
                    fontSize: "1.25rem",
                    paddingX: 2,
                    paddingY: 1,
                    backgroundColor: "purple",
                    color: "white",
                    borderRadius: "9999px",
                    opacity: 0,
                    animation: "fadeIn 2s ease-in-out forwards",
                    animationDelay: "1s",
                    "&:hover": {
                      backgroundColor: "#f3e8ff",
                      color: "#4a0072",
                    },
                  }}
                >
                  Forum
                </Button>

                {/* Inner Voice button */}
                <Button
                  component={Link}
                  to={innerVoiceLink}
                  size="medium"
                  sx={{
                    height: 48,
                    fontSize: "1.25rem",
                    paddingX: 2.5,
                    paddingY: 1,
                    minWidth: 0,
                    width: "auto",
                    whiteSpace: "nowrap",
                    backgroundColor: "#f3e8ff",
                    color: "#4a0072",
                    borderRadius: "9999px",
                    opacity: 0,
                    animation: "fadeIn 2s ease-in-out forwards",
                    animationDelay: "1s",
                    "&:hover": {
                      backgroundColor: "#6d5b9b",
                      color: "#ffffff",
                    },
                  }}
                >
                  Inner Voice
                </Button>
              </>
            ) : (
              <>
                {/* Log In button */}
                <Button
                  component={Link}
                  to="/signin"
                  size="large"
                  sx={{
                    width: "130px",
                    fontSize: "1.25rem",
                    paddingX: 2,
                    paddingY: 1,
                    backgroundColor: "purple",
                    color: "white",
                    borderRadius: "9999px",
                    opacity: 0,
                    animation: "fadeIn 2s ease-in-out forwards",
                    animationDelay: "1s",
                    "&:hover": {
                      backgroundColor: "#f3e8ff",
                      color: "#4a0072",
                    },
                  }}
                >
                  Log In
                </Button>

                {/* Sign Up button */}
                <Button
                  component={Link}
                  to="/signup"
                  size="large"
                  sx={{
                    width: "130px",
                    fontSize: "1.25rem",
                    paddingX: 2,
                    paddingY: 1,
                    backgroundColor: "#f3e8ff",
                    color: "#4a0072",
                    borderRadius: "9999px",
                    opacity: 0,
                    animation: "fadeIn 2s ease-in-out forwards",
                    animationDelay: "1s",
                    "&:hover": {
                      backgroundColor: "purple",
                      color: "#ffffff",
                    },
                  }}
                >
                  Sign Up
                </Button>
              </>
            )}
          </Box>

          {/* Down arrow and 'Learn More' text with animation */}
          <Box
            sx={{
              position: "absolute",
              bottom: 16,
              left: "50%",
              transform: "translateX(-50%)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              zIndex: 15,
              opacity: 0,
              animation: `
                slideUpOnce 1.5s ease-out 2s forwards,
                floatY 2s ease-in-out 3.5s infinite
              `,
            }}
          >
            <Box
              sx={{
                fontSize: "1.2rem",
                fontWeight: "bold",
                color: "white",
                textShadow: "0 0 10px rgba(74, 0, 114, 0.6)",
                mb: "4px",
              }}
            >
              Learn More
            </Box>
            <Box
              sx={{
                width: 0,
                height: 0,
                borderLeft: "10px solid transparent",
                borderRight: "10px solid transparent",
                borderTop: "10px solid white",
                filter: "drop-shadow(0 0 6px rgba(74, 0, 114, 0.5))",
              }}
            />
          </Box>
        </Box>
      </section>
    </div>
  );
}
