import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Shareicon from "../../assets/share.png";
import Growicon from "../../assets/grow.png";
import Recordicon from "../../assets/record.png";
import Supporticon from "../../assets/support.png";
import Respondicon from "../../assets/respond.png";
import Trackicon from "../../assets/track.png";

const items = [
  {
    icon: (
      <img
        src={Shareicon}
        style={{ display: "block", width: "100%", height: "100%" }}
      />
    ),
    title: "Share",
    description:
      "Open up in a safe, anonymous space and connect through honest stories.",
  },
  {
    icon: (
      <img
        src={Supporticon}
        style={{ display: "block", width: "85%", height: "85%" }}
      />
    ),
    title: "Support",
    description:
      "Receive encouragement and reactions that remind you you're not alone.",
  },
  {
    icon: (
      <img
        src={Recordicon}
        style={{ display: "block", width: "110%", height: "120%" }}
      />
    ),
    title: "Record",
    description:
      "Capture thoughts and emotions as they unfold, without judgment.",
  },
  {
    icon: (
      <img
        src={Trackicon}
        style={{ display: "block", width: "100%", height: "100%" }}
      />
    ),
    title: "Track",
    description: "See how your feelings evolve with visual mood insights.",
  },
  {
    icon: (
      <img
        src={Respondicon}
        style={{ display: "block", width: "85%", height: "85%" }}
      />
    ),
    title: "Respond",
    description:
      "Get personalized reflections and thoughtful feedback from us.",
  },
  {
    icon: (
      <img
        src={Growicon}
        alt="Share"
        style={{ display: "block", width: "85%", height: "85%" }}
      />
    ),
    title: "Grow",
    description:
      "Gain self-awareness through patterns that help you understand yourself.",
  },
];

export default function Overview() {
  const containerRef = React.useRef(null);
  const [showGradient, setShowGradient] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      if (!containerRef.current) return;

      const rect = containerRef.current.getBoundingClientRect(); //position and size of an element relative to the viewport
      const windowHeight = window.innerHeight;

      if (rect.bottom <= windowHeight) {
        setShowGradient(true);
      } else {
        setShowGradient(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll();

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <Box
      id="Overview"
      ref={containerRef}
      sx={{
        pt: { xs: 6, sm: 14 },
        pb: { xs: 10, sm: 20 },
        color: "white",
        bgcolor: "#6d5b9b",
        position: "relative",
      }}
    >
      <Box
        sx={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: "150px",
          background:
            "linear-gradient(to bottom, rgba(255,255,255,0) 0%, rgba(255,255,255,0.7) 38.6%, rgba(255,255,255,0.94) 70.0%, rgba(255,255,255,0.99) 85%, rgba(255,255,255,1) 100%)",
          opacity: showGradient ? 1 : 0,
          transition: "opacity 0.4s ease",
          pointerEvents: "none",
          zIndex: 1,
        }}
      />

      <Container
        sx={{
          position: "relative",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: { xs: 3, sm: 6 },
        }}
      >
        <Box
          sx={{
            width: { sm: "100%", md: "60%" },
            textAlign: { sm: "left", md: "center" },
          }}
        >
          <Typography
            sx={{
              fontSize: 40,
            }}
            component="h1"
            variant="h4"
            gutterBottom
          >
            Welcome to「 Whispering Valley 」
          </Typography>
          <Typography variant="body1" sx={{ color: "white", fontSize: 20 }}>
            This is a warm haven for students in Munich — a place to speak
            freely, reflect deeply, and grow gently. Here, you can do and get…
          </Typography>
        </Box>
        <Grid container spacing={2}>
          {items.map((item, index) => (
            <Grid size={{ xs: 12, sm: 6, md: 4 }} key={index}>
              <Stack
                direction="column"
                component={Card}
                spacing={1}
                useFlexGap //Use CSS Flexbox gap for spacing instead of margins
                sx={{
                  color: "#3D1F6C",
                  p: 2,
                  height: "100%",
                  backgroundColor: "white",
                  borderColor: "hsla(220, 25%, 25%, 0.3)",
                  transition: "all 0.3s ease",
                  "&:hover": {
                    backgroundColor: "#ffeef2",
                    transform: "translateY(-4px)",
                  },
                  "& .icon": {
                    transition: "transform 0.3s ease",
                  },
                  "&:hover .icon": {
                    transform: "scale(0.85)",
                  },
                  "& .text": {
                    transition: "transform 0.3s ease",
                  },
                  "&:hover .text": {
                    transform: "translateY(-4px)",
                  },
                }}
              >
                <Box
                  className="icon"
                  sx={{
                    width: 200,
                    height: 200,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    mx: "auto",
                    transform: "translateY(-10%)",
                  }}
                >
                  {item.icon}
                </Box>
                <div className="text">
                  <Typography
                    gutterBottom
                    sx={{
                      fontWeight: 700,
                      fontSize: "1.375rem",
                    }}
                  >
                    {item.title}
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{
                      fontWeight: 500,
                      fontSize: "1rem",
                    }}
                  >
                    {item.description}
                  </Typography>
                </div>
              </Stack>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
}
