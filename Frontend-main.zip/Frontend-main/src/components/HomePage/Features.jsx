import React from "react";
import PropTypes from "prop-types";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Card from "@mui/material/Card";
import MuiChip from "@mui/material/Chip";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import { styled } from "@mui/material/styles";
import PeopleAltIcon from "@mui/icons-material/PeopleAlt";
import ModeEditOutlineIcon from "@mui/icons-material/ModeEditOutline";
import DashboardIcon from "@mui/icons-material/Dashboard";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import { useNavigate } from "react-router-dom";
import { useUser } from "../../hooks/useRedux";
import { useSubscription } from "../../hooks/useSubscription.js";
import journalImg from "../../../public/journalImg.png";
import dashboardImg from "../../../public/dashboardImg.png";
import forumImg from "../../../public/forumImg.png";

// Items displayed in the feature list
const items = [
  {
    icon: <PeopleAltIcon />,
    title: "Forum",
    description:
      "An anonymous space for open emotional expression, where you can share your thoughts and receive empathy from peers without fear of judgment.",
    //image: `url("https://mui.com/static/images/templates/templates-images/dash-light.png")`,
    image: `url(${forumImg})`,
    link: "/forum",
  },
  {
    icon: <ModeEditOutlineIcon />,
    title: "Daily Journal",
    description:
      "A private, secure journaling tool that helps you track your moods and reflect on your emotions through guided prompts and personalized feedback.",
    image: `url(${journalImg})`,
    link: "/dailyjournal",
  },
  {
    icon: <DashboardIcon />,
    title: "Dashboard",
    description:
      "A personal insights hub that summarizes emotional trends over time, offering gentle progress tracking, wellness tips, and self-care suggestions.",
    image: `url(${dashboardImg})`,
    link: "/dashboard",
  },
];

// Custom styled Chip component for the mobile layout
const Chip = styled(MuiChip)(({ selected }) => ({
  ...(selected && {
    backgroundColor: "hsl(276, 55.2%, 34.1%) !important",
    "& .MuiChip-label": {
      color: "hsl(0, 0%, 100%)",
    },
  }),
}));

/**
 * Mobile layout for small screens
 * Shows a list of selectable Chips and the corresponding feature card
 */
function MobileLayout({
  selectedItemIndex,
  handleItemClick,
  selectedFeature,
  handleEnterClick,
}) {
  if (!items[selectedItemIndex]) return null;

  return (
    <Box
      sx={{
        display: { xs: "flex", sm: "none" },
        flexDirection: "column",
        gap: 2,
      }}
    >
      {/* Horizontal scrollable chips for selecting features */}
      <Box sx={{ display: "flex", gap: 2, overflow: "auto" }}>
        {items.map(({ title }, index) => (
          <Chip
            size="medium"
            key={index}
            label={title}
            onClick={() => handleItemClick(index)}
            selected={selectedItemIndex === index}
          />
        ))}
      </Box>

      {/* Card with image, description, and enter button */}
      <Card variant="outlined" sx={{ position: "relative" }}>
        <Box
          sx={{
            mb: 2,
            backgroundSize: "cover",
            backgroundPosition: "center",
            minHeight: 280,
            backgroundImage: items[selectedItemIndex].image,
          }}
        />
        <Button
          size="small"
          variant="contained"
          endIcon={<ArrowForwardIosIcon />}
          sx={{
            position: "absolute",
            top: 10,
            right: 10,
            zIndex: 2,
            minWidth: 0,
            px: 1.5,
            py: 0.5,
            fontSize: 13,
            borderRadius: 2,
            background: "#6d5b9b",
            color: "#fff",
            textTransform: "none",
            boxShadow: 1,
            fontWeight: 600,
            transition: "all 0.2s",
            whiteSpace: "nowrap",
            "&:hover": {
              background: "#ede7f6",
              color: "#6d5b9b",
            },
          }}
          onClick={() => handleEnterClick(items[selectedItemIndex])}
        >
          Enter
        </Button>
        <Box sx={{ px: 2, pb: 2 }}>
          <Typography
            gutterBottom
            sx={{ color: "#4a0072", fontWeight: "medium" }}
          >
            {selectedFeature.title}
          </Typography>
          <Typography variant="body2" sx={{ color: "#4a0072", mb: 1.5 }}>
            {selectedFeature.description}
          </Typography>
        </Box>
      </Card>
    </Box>
  );
}

MobileLayout.propTypes = {
  handleItemClick: PropTypes.func.isRequired,
  handleEnterClick: PropTypes.func.isRequired,
  selectedFeature: PropTypes.shape({
    description: PropTypes.string.isRequired,
    icon: PropTypes.element,
    image: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
  }).isRequired,
  selectedItemIndex: PropTypes.number.isRequired,
};

export { MobileLayout };

export default function Features() {
  const { user } = useUser();
  const { current: sub } = useSubscription();
  const subPlan = sub ? sub.plan : "free";
  const navigate = useNavigate();

  const [selectedItemIndex, setSelectedItemIndex] = React.useState(0);

  const handleItemClick = (index) => {
    setSelectedItemIndex(index);
  };

  // Handle navigation when clicking "Enter"
  const handleEnterClick = (item) => {
    if (item.title === "Forum") {
      navigate(item.link);
      return;
    }
    if (!user) {
      navigate("/signin");
    } else if (subPlan !== "premium") {
      navigate("/pricing");
    } else {
      navigate(item.link);
    }
  };

  const selectedFeature = items[selectedItemIndex];
  const pcImg = "/pc.png";

  return (
    <Container
      id="features"
      sx={{ pt: { xs: 2, sm: 4 }, pb: { xs: 8, sm: 16 } }}
    >
      <Typography
        gutterBottom
        sx={{
          fontSize: "2.7rem",
          fontWeight: "bold",
          color: "#4a0072",
          textAlign: "center",
          mb: 8,
        }}
      >
        Our Features
      </Typography>

      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row-reverse" },
          gap: 10,
        }}
      >
        <div>
          {/* Feature list for larger screens */}
          <Box
            sx={{
              display: { xs: "none", sm: "flex" },
              flexDirection: "column",
              gap: 2,
              height: "100%",
            }}
          >
            {items.map((item, index) => (
              <Box
                key={index}
                onClick={() => handleItemClick(index)}
                sx={[
                  {
                    p: 2,
                    height: "100%",
                    width: "100%",
                    position: "relative",
                    cursor: "pointer",
                    "&:hover": {
                      backgroundColor: "#ede7f6",
                    },
                  },
                  selectedItemIndex === index && {
                    backgroundColor: "#ede7f6",
                  },
                ]}
              >
                {/* Separate inner Button for navigation */}
                <Button
                  size="small"
                  variant="contained"
                  endIcon={
                    <ArrowForwardIosIcon
                      sx={{ color: "inherit" }}
                      fontSize="small"
                    />
                  }
                  sx={{
                    position: "absolute",
                    top: 10,
                    right: 10,
                    zIndex: 2,
                    minWidth: 0,
                    px: 1.5,
                    py: 0.5,
                    fontSize: 13,
                    borderRadius: 2,
                    background: "#ede7f6",
                    color: "#5e35b1",
                    textTransform: "none",
                    whiteSpace: "nowrap",
                    fontWeight: 600,
                    boxShadow: "0 2px 6px rgba(93, 64, 128, 0.15)",
                    transition: "background 0.3s, color 0.3s, box-shadow 0.3s",
                    "&:hover": {
                      background: "#d8cbe8",
                      color: "#4a148c",
                      boxShadow: "0 4px 8px rgba(93, 64, 128, 0.2)",
                    },
                  }}
                  onClick={(e) => {
                    e.stopPropagation(); // prevent outer click from firing
                    handleEnterClick(item);
                  }}
                >
                  Enter
                </Button>

                {/* Feature description */}
                <Box
                  sx={[
                    {
                      width: "100%",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "left",
                      gap: 1,
                      textAlign: "left",
                      textTransform: "none",
                      color: "#4a0072",
                    },
                    selectedItemIndex === index && {
                      color: "#4a0072",
                    },
                  ]}
                >
                  {item.icon}
                  <Typography
                    variant="h6"
                    sx={{
                      fontSize: "1.4rem",
                      lineHeight: 1.75,
                      color: "#4a0072",
                      fontWeight: "bold",
                    }}
                  >
                    {item.title}
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{
                      fontSize: "1.05rem",
                      lineHeight: 1.75,
                      color: "#4a0072",
                    }}
                  >
                    {item.description}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Box>

          <MobileLayout
            selectedItemIndex={selectedItemIndex}
            handleItemClick={handleItemClick}
            selectedFeature={selectedFeature}
            handleEnterClick={handleEnterClick}
          />
        </div>

        {/* Image area for large screens */}
        <Box
          sx={{
            display: { xs: "none", sm: "flex" },
            width: { xs: "100%", md: "70%" },
            height: "var(--items-image-height)",
          }}
        >
          <Box
            sx={{
              position: "relative",
              width: "100%",
              height: "100%",
              display: { xs: "none", sm: "flex" },
              justifyContent: "center",
              alignItems: "center",
              transform: "translateY(-60px)",
            }}
          >
            <Box
              sx={{
                m: "auto",
                width: 450,
                height: 300,
                backgroundSize: "contain",
                backgroundImage: selectedFeature.image,
                backgroundRepeat: "no-repeat",
                backgroundPosition: "center",
              }}
            />
            <Box
              component="img"
              src={pcImg}
              alt="PC"
              sx={{
                position: "absolute",
                left: "50%",
                top: "62%",
                width: 460,
                height: 460,
                transform: "translate(-50%, -50%)",
                zIndex: 2,
                pointerEvents: "none",
                userSelect: "none",
              }}
            />
          </Box>
        </Box>
      </Box>
    </Container>
  );
}
