import * as React from "react";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Container,
  Link,
  Typography,
  Paper,
  Divider,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

export default function FAQ() {
  const [expanded, setExpanded] = React.useState([]); // an array of panel IDs that are currently expanded

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(
      isExpanded
        ? [...expanded, panel] // creates a new array with all previous items, then panel adds the new one
        : expanded.filter((item) => item !== panel)
    );
  };

  const emotionalFAQs = [
    {
      id: "e1",
      question: "How do I manage overwhelming emotions?",
      answer:
        "Try grounding techniques like deep breathing, journaling, or talking to someone you trust. Whispering Valley offers a space to reflect and process emotions anonymously.",
    },
    {
      id: "e2",
      question: "What should I do when I feel anxious or down?",
      answer:
        "You can track your mood on the platform to gain insight. Regular self-reflection and support from others can also help reduce anxiety.",
    },
  ];

  const platformFAQs = [
    {
      id: "p1",
      question: "How do I post my thoughts on Whispering Valley?",
      answer:
        "Go to the Forum page, then click the Create New Post button in the upper-right corner. Choose an emoji that represents your mood for the day, and you can anonymously share your thoughts and feelings on the forum. You can also add tags to make it easier for like-minded people to discover your post.",
    },
    {
      id: "p2",
      question: "Can I edit or delete my posts later?",
      answer:
        "Yes. Go to the post's detail page and click the three dots in the upper-right corner of the post. From there, you can edit or delete your post at any time.",
    },
  ];

  const renderFAQGroup = (title, faqs, withDivider = false) => (
    <Box sx={{ mb: 8 }}>
      {withDivider && (
        <Divider
          sx={{
            my: 6,
            borderColor: "#e1d5f5",
            borderBottomWidth: "2px",
            width: "100%",
          }}
        />
      )}
      <Typography
        variant="h5"
        sx={{
          fontWeight: "bold",
          mb: 2,
          mt: 4,
          color: "#3D1F6C",
        }}
      >
        {title}
      </Typography>
      <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
        {faqs.map(({ id, question, answer }) => (
          <Paper
            key={id}
            elevation={3}
            sx={{
              borderRadius: "32px",
              px: { xs: 2, sm: 4 },
              py: { xs: 1.5, sm: 2 },
              bgcolor: "#fafafa",
              transition: "box-shadow 0.3s ease",
              "&:hover": {
                boxShadow: 6,
              },
            }}
          >
            <Accordion
              disableGutters // Removes default padding around the accordion content
              expanded={expanded.includes(id)}
              onChange={handleChange(id)}
              elevation={0}
              sx={{
                bgcolor: "transparent",
                boxShadow: "none",
                border: "none",
                "&:before": {
                  display: "none",
                },
              }}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                /* links this summary to the corresponding content panel (AccordionDetails) by ID.
                Helps screen readers know which panel it controls. */
                aria-controls={`${id}-content`}
                id={`${id}-header`}
                sx={{
                  px: 0,
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                }}
              >
                <Typography
                  component="span"
                  variant="subtitle2"
                  sx={{ fontSize: "1.125rem", fontWeight: 600 }}
                >
                  {question}
                </Typography>
              </AccordionSummary>
              <AccordionDetails sx={{ px: 0 }}>
                <Typography
                  variant="body2"
                  sx={{
                    fontSize: "1rem",
                    lineHeight: 1.75,
                    maxWidth: { sm: "100%", md: "80%" },
                  }}
                >
                  {answer}
                </Typography>
              </AccordionDetails>
            </Accordion>
          </Paper>
        ))}
      </Box>
    </Box>
  );

  return (
    <Container
      id="faq"
      sx={{
        pt: { xs: 4, sm: 12 },
        pb: { xs: 8, sm: 16 },
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: { xs: 3, sm: 6 },
      }}
    >
      <Typography
        component="h2"
        variant="h4"
        sx={{
          fontSize: "2.7rem",
          fontWeight: "bold",
          color: "#4a0072",
          width: { sm: "100%", md: "60%" },
          textAlign: { sm: "left", md: "center" },
        }}
      >
        Frequently asked questions
      </Typography>

      <Box sx={{ width: "100%" }}>
        {renderFAQGroup("Emotional Wellbeing", emotionalFAQs)}
        {renderFAQGroup("About Whispering Valley", platformFAQs, true)}
      </Box>

      <Typography
        variant="body1"
        sx={{
          mt: 6,
          mx: "auto",
          maxWidth: "600px",
          textAlign: "center",
          color: "black",
          fontSize: "1rem",
          fontWeight: "bold",
          lineHeight: 1.75,
          px: 2,
        }}
      >
        Got questions or ideas? We'd love to hear from you! <br />
        Feel free to{" "}
        <Link
          href="/contact"
          underline="hover"
          sx={{ color: "#6d5b9b", fontWeight: "bold" }}
        >
          contact us
        </Link>{" "}
        — we're always here for you.
      </Typography>
    </Container>
  );
}
